import { CustomPackageComponent } from './../../modules/dashboard/forms/formslanding/custom-package/custom-package.component';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FormslandingComponent } from '../../modules/dashboard/forms/formslanding/formslanding.component';
import { AppConstants } from '../../app.constants';
import { Component, OnInit, Inject, ViewEncapsulation } from '@angular/core';

export interface DialogData {
  animal: string;
  name: string;
}

@Component({
  selector: 'app-emailsuccess',
  templateUrl: './emailsuccess.component.html',
  styleUrls: ['./emailsuccess.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class EmailsuccessComponent implements OnInit {

  closeIcon = this.app.closeIcon;
  attachment = this.app.attachment;
  tick = this.app.tick;

  isSuccess = false;

  constructor(
    private app: AppConstants,
    public dialogRef: MatDialogRef<FormslandingComponent>,
    public dialogRefCustom: MatDialogRef<CustomPackageComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData,
  ) { }


  ngOnInit() { }


  onNoClick(): void {
    this.dialogRef.close();
  }



}
