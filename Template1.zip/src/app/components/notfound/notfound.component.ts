import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppConstants } from '@app/app.constants';
@Component({
  selector: 'app-notfound',
  templateUrl: './notfound.component.html',
  styleUrls: ['./notfound.component.scss']
})
export class NotfoundComponent implements OnInit {

  constructor(private router: Router, private app: AppConstants) { }
  notfound = this.app.notfound;
  ngOnInit() {
  }

  navigate() {
    this.router.navigate(['/']);
  }

}
