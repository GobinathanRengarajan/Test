import { CustomPackageComponent } from './../../modules/dashboard/forms/formslanding/custom-package/custom-package.component';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Component, OnInit, Inject, ViewEncapsulation, Renderer2, OnDestroy } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FormslandingComponent } from '../../modules/dashboard/forms/formslanding/formslanding.component';
import { AppConstants } from '@app/app.constants';
import { FormsutilityService } from '@app/core/services/formsutility/formsutility.service';
import { ActivatedRoute, Router } from '@angular/router';

export interface DialogData {
  forEach(arg0: (element: any) => void);
  // tslint:disable-next-line: member-ordering
  length: any;
  // tslint:disable-next-line: member-ordering
  animal: string;
  // tslint:disable-next-line: member-ordering
  name: string;
}

@Component({
  selector: 'app-emailforms',
  templateUrl: './emailforms.component.html',
  styleUrls: ['./emailforms.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class EmailformsComponent implements OnInit, OnDestroy {

  emailForm: FormGroup;
  submitted = false;

  closeIcon = this.app.closeIcon;
  attachment = this.app.attachment;
  tick = this.app.tick;

  isSuccess = false;
  emailPattern = '^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$';
  invalidEmail = false;
  selectedLength: any;
  emailApiParams: string;
  constructor(
    private formBuilder: FormBuilder,
    private app: AppConstants,
    private formsPackage: FormsutilityService,
    public dialogRef: MatDialogRef<FormslandingComponent>,
    public dialogRefCustom: MatDialogRef<CustomPackageComponent>,
    @Inject(MAT_DIALOG_DATA) public data,
    private render: Renderer2,
    @Inject(DOCUMENT) private document: Document
  ) { }



  ngOnInit() {
    this.selectedLength = this.data.length;
    this.emailForm = this.formBuilder.group({
      emailID: ['', Validators.required],
      subject: ['', Validators.required],
      textMessage: ['', ]
    });
    this.render.addClass(this.document.body, 'emailforms-body');
  }
  ngOnDestroy(): void {
    this.render.removeClass(this.document.body, 'emailforms-body');
  }

  emailValidator(emailID) {
    // RFC 2822 compliant regex
    // tslint:disable-next-line:max-line-length
    if (emailID.value.match(/[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/)) {
      return null;
    } else {
      return { 'invalidEmailAddress': true };
    }
  }

  // convenience getter for easy access to form fields
  get f() { return this.emailForm.controls; }

  get emailID() { return this.emailForm.get('emailID'); }
  get subject() { return this.emailForm.get('subject'); }
 get textMessage() { return this.emailForm.get('textMessage'); }

  onNoClick(): void {
    this.dialogRef.close();
  }

  sendEmail() {
    this.isSuccess = true;
  }

  emailValidation() {
    // Replacing commas from email address and removing extra spaces at beginning and end of email addresses
    const input = this.emailForm.get('emailID').value;
    if (input !== '') {
      const comma = input.replace('/,/g', ';');
      const spacesemicolon = comma.replace(/ ;/g, ';');
      const semicolonspace = spacesemicolon.replace(/; /g, ';');
      // Splitting the string into an array of separate email addresses on semicolon
      const emailarray = semicolonspace.split(';');
      // Validating each item within the array
      for (let i = 0; i < emailarray.length; i++) {
        const validate = emailarray[i];
        const bademail = validate.search(/[A-Za-z0-9_.-]+@[A-Za-z0-9_.-]+\.[A-Za-z0-9_.-]+/gi);
        if (bademail !== 0) {
          this.invalidEmail = true;
          // tslint:disable-next-line:max-line-length
          // if an invalid email address is entered then the value of bademail will be greater than 1 or -1. return; will then stop the code running
          return;
        } else {
          this.invalidEmail = false;
        }
      }
    }
  }

  onSubmit() {
    this.submitted = true;
    const isEmailNone = this.emailForm.get('emailID').value;
    this.emailValidation();
    if (this.subject.invalid || isEmailNone === '' || this.invalidEmail === true) {
      return;
    } else {
      this.dialogRef.close(this.emailForm.value);
    }
  }

}
