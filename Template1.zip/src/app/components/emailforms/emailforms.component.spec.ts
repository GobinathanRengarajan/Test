import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmailformsComponent } from './emailforms.component';

describe('EmailformsComponent', () => {
  let component: EmailformsComponent;
  let fixture: ComponentFixture<EmailformsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmailformsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmailformsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
