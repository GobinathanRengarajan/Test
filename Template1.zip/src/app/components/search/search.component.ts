import {
  Component, OnInit,
  ViewEncapsulation, ViewChild,
  Renderer2, Inject, ElementRef,
  OnDestroy, AfterViewInit, AfterViewChecked, Input
} from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { InforceService } from '@services/inforce/inforce.service';
import { AppConstants } from '@app/app.constants';
import { SelectionModel } from '@angular/cdk/collections';
import { Router, ActivatedRoute } from '@angular/router';
import { CreatepackageComponent } from '../createpackage/createpackage.component';
import { BirthdayMonth } from '../../shared/models/birthdaymonth';
import { forkJoin } from 'rxjs';
import { NewbusinessService } from '@app/core/services/newbusiness/newbusiness.service';
import * as moment from 'moment';
import { DOCUMENT } from '@angular/common';
import { InforceLandPolicy } from '@app/shared/models/inforce-landing';
import { NBLandPolicy } from '@app/shared/models/newbusiness-landing';
import { MatPaginator, MatSort, MatTableDataSource, PageEvent, MatDialog, matTabsAnimations } from '@angular/material';
import { EmailsuccessComponent } from '@app/components/emailsuccess/emailsuccess.component';
import { EmailformsComponent } from '@app/components/emailforms/emailforms.component';
import { FormsutilityService } from '@services/formsutility/formsutility.service';
import { LaserficheService } from '@app/core/services/laserfiche/laserfiche.service';
import { saveAs } from 'file-saver';
import { ChangeDetectorRef } from '@angular/core';
export interface Element {
  DocumentName: any;
  Document_Name: string;
  Version: string;
  Last_Updated: string;
}

const ELEMENT_DATA: Element[] = [];


@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss'],
  encapsulation: ViewEncapsulation.None
})


export class SearchComponent implements OnInit, OnDestroy, AfterViewInit, AfterViewChecked {

  dataSource: any = [];
  show = false;
  show_list = false;
  txtval: string;
  txtyear: string;
  dropval: string;
  datacount = 0;
  reslutDataCount: any;
  showdrop: string;
  showtext: string;
  centertext = true;
  centertext_list = true;
  highlightpol = false;
  highlightclient = false;
  highlightpremiun = false;
  PolicyNumber: string;
  selected: any;
  ruleValueFields: any;
  evaluationRuleValue: any;
  downloadApiParams: string;
  params = [];
  url = [];
  selectedoption = 'Please Select';
  iscommon = false;
  isclient = false;
  isinsured = false;
  ispremium = false;
  countryName: string;
  displayedColumns_list = ['select', 'Version', 'Last_Updated'];
  data = Object.assign(ELEMENT_DATA);
  data_Source = new MatTableDataSource<Element>(this.data);
  selection = new SelectionModel<Element>(true, []);

  selectedRows = [];
  transferredRows = [];
  getCountry : string;
  userId: string;
  fromDueDate: string;
  touedate: string;

  isLoadingResults: boolean;

  displayedColumns: string[] = [
    'policyNumber',
    'clientName',
    'InsuredDob',
    'Policy_Status',
    'PremiumDueDate',
    'Product_Id'
  ];
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  emailApiParams: string;
  // tslint:disable-next-line: max-line-length
  constructor(private nbService: NewbusinessService,
    private router: Router,
    private http: HttpClient,
    private policysearch: InforceService,
    public dialog: MatDialog,
    private app: AppConstants,
    private route: ActivatedRoute,
    @Inject(DOCUMENT) private document: Document,
    private renderer: Renderer2,
    private formsPackage: FormsutilityService,
    private laserfiche: LaserficheService,
    private cdRef: ChangeDetectorRef,
    private el: ElementRef) { }

  someCondition = true;
  client: string;
  policy: string;
  noResult: boolean;
  month: string;
  clientdisplay = false;
  viewValue: string;
  search = this.app.search;
  searchResult = this.app.searchResult;
  pleaseSelect = this.app.pleaseSelect;
  policyNumber = this.app.policyNumber;
  clientName = this.app.clientName;
  InsuredDOB = this.app.InsuredDOB;
  policyStatus = this.app.policyStatus;
  dueDate = this.app.dueDate;
  premiumDueDate = this.app.premiumDueDate;
  producerId = this.app.producerId;
  sortingImg = this.app.sortingImg;
  downloadIconGrey = this.app.downloadIconGrey;
  printIconGrey = this.app.printIconGrey;
  emailIconGrey = this.app.emailIconGrey;
  saveIcon = this.app.saveIcon;
  saveIconGrey = this.app.saveIconGrey;
  packageIcon = this.app.packageIcon;
  packageIconGrey = this.app.packageIconGrey;
  backArrowImg = this.app.backArrowIcon;
  backArrowMobileImg = this.app.backArrowMobileIcon;
  birthdaymonthselect: string;
  birthdatmnth: string;
  txtvalall: string;
  txtvalfname: string;
  txtvallname: string;
  error_message: boolean;
  error_message_permium: boolean;
  lifepolicy: string;
  liferbro: string;
  country: string;
  packagefile: string;
  productname: string;
  isActive = false;
  filterData: any[] = [];
  filterValue: string;

  get className() {
    return this.someCondition ? 'class1' : 'class2';
  }

  months: BirthdayMonth[] = [
    { value: 'Jan', viewValue: '01' },
    { value: 'Feb', viewValue: '02' },
    { value: 'Mar', viewValue: '03' },
    { value: 'Apr', viewValue: '04' },
    { value: 'May', viewValue: '05' },
    { value: 'Jun', viewValue: '06' },
    { value: 'Jul', viewValue: '07' },
    { value: 'Aug', viewValue: '08' },
    { value: 'Sep', viewValue: '09' },
    { value: 'Oct', viewValue: '10' },
    { value: 'Nov', viewValue: '11' },
    { value: 'Dec', viewValue: '12' },
  ];


  evaluationRuleFields = [
    { value: 'Please Select', name: 'Please Select', valueFieldType: 'Please Select', viewValue: 'Please Select' },
    { value: 'Policy Information', name: 'Policy Information', viewValue: 'Policy Information' },
    { value: 'Policy Number', name: 'Policy Number', valueFieldType: 'Policy Number', viewValue: 'Policy Number' },
    { value: 'Client Name', name: 'Client Name', valueFieldType: 'Client Name', viewValue: 'Client Name' },
    { value: 'Birthday Month', name: 'Birthday Month', valueFieldType: 'Birthday Month', viewValue: 'Birthday Month' },
    { value: 'Premium due month', name: 'Premium due month', valueFieldType: 'Premium due month', viewValue: 'Premium due month' },
    { value: 'Forms', name: 'Forms', viewValue: 'Forms' },
    { value: 'Hong Kong', name: 'Hong Kong', valueFieldType: 'Hong Kong', viewValue: 'Hong Kong' },
    { value: 'Singapore', name: 'Singapore', valueFieldType: 'Singapore', viewValue: 'Singapore' },
    { value: 'Bermuda', name: 'Bermuda', valueFieldType: 'Bermuda', viewValue: 'Bermuda' },

  ];

  ngOnInit() {
    this.onSubmit();
    this.paramsDataCall();
    this.renderer.addClass(this.document.body, 'embedded-body');
  }



  ngOnDestroy(): void {
    this.renderer.removeClass(this.document.body, 'embedded-body');
  }

  ngAfterViewInit() {
  }

  ngAfterViewChecked() {
    this.cdRef.detectChanges();
  }
  /** The label for the checkbox on the passed row */
  checkboxLabel(row?: Element): string {
    if (!row) {
      return `${this.isAllSelected() ? 'select' : 'deselect'} all`;
    }
  }
  emailForms() {
    const dialogRef = this.dialog.open(EmailformsComponent, {
      panelClass: 'email-dialog-modal',
      data: this.selection.selected.length,
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result === undefined) {
        this.isLoadingResults = false;
      } else {
        this.isLoadingResults = true;
        this.isLoadingResults = true;
        let i = 0;
        this.emailApiParams = '';
        this.selection.selected.forEach(element => {
          this.emailApiParams = this.emailApiParams + 'docNames[' + i + ']=' + element.DocumentName + '&';
          i++;
        });
        const str =
          'recipient=' + result.emailID +
          '&Body=' + result.textMessage +
          '&Subject=' + result.subject +
          '&' + this.emailApiParams.slice(0, -1);
        if (this.selectedoption === 'Hong Kong') {
          this.countryName = 'HK';
        }
        if (this.selectedoption === 'Singapore') {
          this.countryName = 'SG';
        }
        if (this.selectedoption === 'Bermuda') {
          this.countryName = 'Bermuda';
        }
        this.formsPackage.emailForms(this.countryName,str).subscribe(res => {
          if (res) {
            this.isLoadingResults = false;
          }
          if (res === 'Email sent successfully') {
            this.successDialog();
          }
        },
          err => {
            console.log(err.error);
          });
      }
    });
  }

  // for dialog open
  successDialog(): void {
    const dialogRef = this.dialog.open(EmailsuccessComponent, {
      panelClass: 'success-dialog-modal',
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('success', this.data_Source);
    });
  }

  onCitySelect(viewValue) {
    this.txtvalall = ' ';
    this.txtval = '';
    this.txtvallname = '';
    this.txtvalfname = '';
    this.selectedoption = viewValue;
  }

  onbirthdayselect(vala) {
    this.birthdaymonthselect = vala;
  }

  onbirthdayselectpremium(val) {
    this.birthdatmnth = val;
  }


  openSaveDialog(): void {
    console.log('dialog open values', this.selection.selected);
    const dialogRef = this.dialog.open(CreatepackageComponent, {
      panelClass: 'search-dialog-modal',
      data: this.selection.selected,

    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed', result);
    });
  }




  paramsDataCall() {
    console.log(this.route.snapshot.paramMap);
    this.dropval = this.route.snapshot.paramMap.get('dropvalue');
    this.txtval = this.route.snapshot.paramMap.get('policy');
    this.txtvallname = this.route.snapshot.paramMap.get('surname');
    this.txtvalfname = this.route.snapshot.paramMap.get('givename');
    this.birthdaymonthselect = this.route.snapshot.paramMap.get('mnth');
    this.userId = this.route.snapshot.paramMap.get('userid');
    this.birthdatmnth = this.route.snapshot.paramMap.get('fromdate');
    this.txtyear = this.route.snapshot.paramMap.get('todate');
    this.txtvalall = this.route.snapshot.paramMap.get('allvalues');
  }

  updateInforceObj(inObj: InforceLandPolicy): any {
    const displayObj: any = {};
    displayObj.policyNumber = inObj.Policy_Number;
    displayObj.clientName = inObj.IO_Last.trim() + ', ' + inObj.IO_Middle.trim() + ' ' + inObj.IO_First.trim();
    displayObj.InsuredDob = inObj.Date_Of_Birth;
    displayObj.Policy_Status = inObj.Contract_Code.trim();
    displayObj.PremiumDueDate = inObj.Billing_Date;
    displayObj.Product_Id = inObj.Agent_Num.trim();
    displayObj.type = 'Inforce';
    return displayObj;
  }

  updateNBObj(inObj: NBLandPolicy): any {
    const displayObj: any = {};
    displayObj.policynumber = inObj.PolicyNumber;
    displayObj.clientName = inObj.LastName.trim() + ', ' + inObj.MiddleName.trim() + ' ' + inObj.FirstName.trim();
    displayObj.InsuredDob = inObj.DateofBirth;
    displayObj.Policy_Status = inObj.Status.trim();
    displayObj.PremiumDueDate = inObj.PremimumDueDate;
    displayObj.Product_Id = inObj.ProducerId.trim();
    displayObj.type = 'NB';
    return displayObj;
  }



  updateDisplayObj(data: any[]): any {
    const objArray = [];
    if ((data[0] !== null)) {
      for (let i = 0; i < data[0].length; i++) {
        objArray.push(this.updateInforceObj(data[0][i]));
      }
    }
    if ((data[1] !== null)) {
      if (data[1] instanceof Array) {
        for (let i = 0; i < data[1].length; i++) {
          objArray.push(this.updateNBObj(data[1][i]));
        }
      } else {
        objArray.push(this.updateNBObj(data[1]));
      }
    }
    return objArray;
  }




  getAll() {
    this.noResult = false;
    this.showdrop = this.selectedoption;
    if (this.selectedoption !== undefined) {
      if (this.selectedoption === 'Please Select') {
        if (this.txtvalall === '' || this.txtvalall == null) {
          this.error_message = true;
          this.error_message_permium = false;
        } else {
          forkJoin(
            this.policysearch.getPolicyInforceAll(this.txtvalall),
            this.policysearch.getPolicyNbAll(this.txtvalall)
          ).subscribe(data => {
            const objArray = this.updateDisplayObj(data);
            this.show = true;
            this.noResult = false;
            this.showtext = this.txtvalall;
            this.highlightpol = true;
            this.highlightclient = false;
            this.highlightpremiun = false;
            this.datacount = this.dataSource.length;
            if (this.datacount >= 1) {
              this.reslutDataCount = ('0' + this.datacount).slice(-2);
            } else {
              this.reslutDataCount = '0';
            }
            this.dataSource = new MatTableDataSource(objArray);
            this.dataSource.sort = this.sort;
            this.dataSource.paginator = this.paginator;
            this.show_list = false;
            this.centertext = false;
            if (this.datacount === 0) {
              this.noResult = true;
              this.show = false;
              this.show_list = false;
              this.centertext = false;
            }
          }, (error: HttpErrorResponse) => {
            this.noResult = true;
            this.show = false;
            this.show_list = false;
            this.centertext = false;
          });
        }
        this.router.navigate(['search'], { queryParams: { dropval: this.selectedoption, allvalues: this.txtvalall } });
      } else if (this.selectedoption === 'Policy Number') {
        // this.userId = '9';
        forkJoin(
          this.policysearch.getInforcePolicysearch(localStorage.getItem('userId'), this.txtval),
          this.nbService.getnbpolicydetails(localStorage.getItem('userId'), this.txtval)
        ).subscribe(data => {
          const objArray = this.updateDisplayObj(data);
          console.log('esdd', objArray);
          this.clientdisplay = true;
          this.showtext = this.txtvallname + this.txtvalfname;
          this.highlightclient = true;
          this.highlightpremiun = false;
          this.highlightpol = false;
          this.show = true;
          this.iscommon = true;
          this.ispremium = false;
          this.isclient = false;
          this.isinsured = false;
          this.noResult = false;
          this.showtext = this.txtval;
          this.highlightpol = true;
          this.highlightclient = false;
          this.highlightpremiun = false;
          this.show_list = false;
          this.centertext = false;
          this.dataSource = new MatTableDataSource(objArray);
          this.dataSource.sort = this.sort;
          this.dataSource.paginator = this.paginator;
          this.datacount = objArray.length;
          if (this.datacount >= 1) {
            this.reslutDataCount = ('0' + this.datacount).slice(-2);
          } else {
            this.reslutDataCount = '0';
          }
          if (this.datacount === 0) {
            this.noResult = true;
            this.show = false;
            this.show_list = false;
            this.centertext = false;
          }
        }, (error: HttpErrorResponse) => {
          this.noResult = true;
          this.show = false;
          this.show_list = false;
          this.centertext = false;
        });
        this.router.navigate(['search'], { queryParams: { dropval: this.selectedoption, policynumber: this.txtval } });
      } else if (this.selectedoption === 'Client Name') {
        console.log('firstname & lastname', this.txtvalfname, this.txtvallname);
        if (this.txtvalfname == null || this.txtvallname == null) {
          this.error_message = true;
          this.error_message_permium = false;
        } else {
          forkJoin(
            this.policysearch.getInforcePolicybyclientname(localStorage.getItem('userId'),
              this.txtvallname.trim(), this.txtvalfname.trim()),
            this.nbService.getnbclientname(localStorage.getItem('userId'),
              this.txtvallname.trim(), this.txtvalfname.trim())
          ).subscribe(data => {
            console.log('client namedata', data);
            console.log('last name', this.txtvallname);
            console.log('fist name', this.txtvalfname);

            const objArray = this.updateDisplayObj(data);
            // if(objArray.clientName.toLowerCase().indexOf(this.txtvalfname.toLowerCase()) >= 0){
            //   console.log(objArray);
            // }
            const testOne = this.txtvallname.trim().toLowerCase() || this.txtvalfname.trim().toLowerCase();
            const getValue = objArray.map(res => res.clientName.indexOf(testOne));
            const getMatchedName = objArray.map(res => res.clientName.trim().toLowerCase());
            console.log('object array', getValue, 'test', getMatchedName);
            this.show = true;
            this.show_list = false;
            this.clientdisplay = true;
            this.isclient = true;
            this.isinsured = false;
            this.iscommon = false;
            this.ispremium = false;
            this.showtext = this.txtvallname + this.txtvalfname;
            this.highlightclient = true;
            this.highlightpremiun = false;
            this.highlightpol = false;
            this.centertext = false;
            this.noResult = false;
            this.datacount = objArray.length;
            if (this.datacount >= 1) {
              this.reslutDataCount = ('0' + this.datacount).slice(-2);
            } else {
              this.reslutDataCount = '0';
            }
            this.dataSource = new MatTableDataSource(objArray);
            console.log(this.dataSource.filteredData);
            // this.dataSource.filteredData.toLowerCase();
            console.log(this.dataSource);
            if (this.datacount === 0) {
              this.noResult = true;
              this.show = false;
              this.show_list = false;
              this.centertext = false;
            }
            this.dataSource.sort = this.sort;
            this.dataSource.paginator = this.paginator;
          }, (error: HttpErrorResponse) => {
            this.noResult = true;
            this.show = false;
            this.show_list = false;
            this.centertext = false;
          });
          this.router.navigate(['search'], {
            queryParams:
              { dropval: this.selectedoption, surname: this.txtvallname, givenname: this.txtvalfname }
          });
        }
      } else if (this.selectedoption === 'Birthday Month') {
        this.policysearch.getpolicyByMonth(localStorage.getItem('userId'), this.birthdaymonthselect).subscribe(res => {
          const objArray = [];
          if (res != null) {
            for (let i = 0; i < res.length; i++) {
              objArray.push(this.updateInforceObj(res[i]));
            }
            this.dataSource = new MatTableDataSource(objArray);
            this.datacount = objArray.length;
            if (this.datacount >= 1) {
              this.reslutDataCount = ('0' + this.datacount).slice(-2);
            } else {
              this.reslutDataCount = '0';
            }
            this.dataSource.sort = this.sort;
            this.dataSource.paginator = this.paginator;
            this.show = true;
            this.isinsured = true;
            this.isclient = false;
            this.ispremium = false;
            // tslint:disable-next-line: radix
            this.showtext = this.months[parseInt(this.birthdaymonthselect) - 1].value;
            this.show_list = false;
            this.centertext = false;
            this.noResult = false;
            if (this.datacount === 0) {
              this.noResult = true;
              this.show = false;
              this.show_list = false;
              this.centertext = false;
            }
          }
        }, (error: HttpErrorResponse) => {
          this.noResult = true;
          this.show = false;
          this.show_list = false;
          this.centertext = false;
        });
        this.router.navigate(['search'], { queryParams: { dropval: this.selectedoption, month: this.birthdaymonthselect } });
      } else if (this.selectedoption === 'Premium due month') {
        if (this.txtyear === '' || this.birthdatmnth == null || this.txtyear === '' || this.birthdatmnth == null) {
          this.error_message_permium = true;
          this.error_message = false;
        } else {
          // tslint:disable-next-line:radix
          let month = parseInt(this.birthdatmnth) - 1;
          if (month === 0) {
            month = 12;
          }
          const startDate = moment(
            // tslint:disable-next-line:radix
            new Date(parseInt(this.txtyear), month, 1)).format('YYYYMMDD');
          // tslint:disable-next-line:radix
          const endDate = moment(new Date(parseInt(this.txtyear), month + 1, 0)).format('YYYYMMDD');
          this.policysearch.getpolicyByPremiumduemonth(localStorage.getItem('userId'), startDate, endDate).subscribe(data => {
            const objArray = [];
            if (data != null) {
              for (let i = 0; i < data.length; i++) {
                objArray.push(this.updateInforceObj(data[i]));
              }
              this.dataSource = new MatTableDataSource(objArray);
              this.datacount = objArray.length;
              if (this.datacount >= 1) {
                this.reslutDataCount = ('0' + this.datacount).slice(-2);
              } else {
                this.reslutDataCount = '0';
              }
              console.log(this.datacount);
              this.highlightpremiun = true;
              this.highlightclient = false;
              this.highlightpol = false;
              this.iscommon = false;
              this.isclient = false;
              this.isinsured = false;
              this.show_list = false;
              this.centertext = false;
              this.noResult = false;
              if (this.datacount === 0) {
                this.noResult = true;
                this.show = false;
              }
            }
          }, (error: HttpErrorResponse) => {
            this.noResult = true;
            this.show = false;
            this.show_list = false;
            this.centertext = false;
          });
          // params
          this.router.navigate(['search'], {
            queryParams: {
              dropval: this.selectedoption,
              birthdaymonth: this.birthdatmnth,
              year: this.txtyear
            }
          });
        }
      } else if (this.selectedoption === 'Hong Kong') {
        this.countryName = 'Hong Kong';
        this.show_list = true;
        this.noResult = false;
        this.centertext_list = false;
        this.centertext = false;
        this.show = false;
        this.lifepolicy = this.txtval;
        this.country = 'HK';
        this.packagefile = 'NO';
        this.laserfiche.searchLaserfiche(this.lifepolicy,
          this.country,
          this.packagefile,
          this.productname).subscribe(data => {
            this.datacount = data.length;
            if (this.datacount === 0) {
              this.noResult = true;
              this.show = false;
            }
            this.data_Source = new MatTableDataSource<Element>(data);
          });
      } else if (this.selectedoption === 'Singapore') {
        this.countryName = 'Singapore';
        this.show_list = true;
        this.noResult = false;
        this.centertext_list = false;
        this.centertext = false;
        this.show = false;
        this.lifepolicy = this.txtval;
        this.country = 'SG';
        this.packagefile = 'NO';
        this.laserfiche.searchLaserfiche(this.lifepolicy,
          this.country,
          this.packagefile,
          this.productname).subscribe(data => {
            this.data_Source = new MatTableDataSource<Element>(data);
            this.datacount = data.length;
            if (this.datacount === 0) {
              this.noResult = true;
              this.show = false;
            }
          });
      } else if (this.selectedoption === 'Bermuda') {
        this.countryName = 'Bermuda';
        this.lifepolicy = this.txtval;
        this.country = 'BN';
        this.packagefile = 'NO';
        this.laserfiche.searchLaserfiche(this.lifepolicy,
          this.country,
          this.packagefile,
          this.productname).subscribe(data => {
            this.noResult = false;
            this.centertext_list = false;
            this.centertext = false;
            this.show = false;
            this.show_list = true;
            this.datacount = data.length;
            if (this.datacount === 0) {
              this.show = false;
              this.show_list = false;
              this.centertext_list = false;
              this.noResult = true;
            }
            this.data_Source = new MatTableDataSource<Element>(data);
          }, (error: HttpErrorResponse) => {
            this.show = false;
            this.show_list = false;
            this.centertext = false;
            this.noResult = true;
          });
      }
    }

  }

  onSubmit() {
    this.getAll();
  }
  syncPrimaryPaginator(event: PageEvent) {
    this.paginator.pageIndex = event.pageIndex;
    this.paginator.pageSize = event.pageSize;
    this.paginator.page.emit(event);
  }

  /*
  const numSelected = this.selection.selected.length;
    // console.log('current selected', numSelected);
    const numRows = this.Default_Package.data.length;
    if (numSelected !== 0) {
      this.isSaveActive = true;
      this.emailIconGrey = this.app.emailIconColor;
      this.downloadIconGrey = this.app.downloadIconColor;
    } else if (numSelected === 0) {
      this.isSaveActive = false;
      this.emailIconGrey = this.app.emailIconGrey;
      this.downloadIconGrey = this.app.downloadIconGrey;
    }
    return numSelected === numRows;
    */

  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.data_Source.data.length;
    if (numSelected !== 0) {
      this.isActive = true;
      this.emailIconGrey = this.app.emailIconColor;
      this.saveIconGrey = this.app.saveIcon;

      this.downloadIconGrey = this.app.downloadIconColor;
    } else if (numSelected === 0) {
      this.isActive = false;
      this.emailIconGrey = this.app.emailIconGrey;
      this.downloadIconGrey = this.app.downloadIconGrey;
      this.saveIconGrey = this.app.saveIconGrey;
    }
    return numSelected === numRows;
  }



  masterToggle() {
    this.isAllSelected() ?
      this.selection.clear() :
      this.data_Source.data.forEach(row => this.selection.select(row));
    console.log(this.data);
  }

  downloadIndividualForms(documentName) {
    this.isLoadingResults = true;
    let pdfName = '';
    if (this.selectedoption === 'Hong Kong') {
      this.getCountry = 'HK';
    } else if (this.selectedoption === 'Singapore') {
      this.getCountry = 'SG';
    } else if (this.selectedoption === 'Bermuda') {
      this.getCountry = 'BM';
    }
    this.formsPackage.extractFormbyDoc(this.getCountry,documentName).subscribe(res => {
      this.isLoadingResults = false;
      pdfName = documentName + '.pdf';
      saveAs(res, pdfName);
    },
      error => {
        console.log('No distributor guide detail found');
      }
    );
  }

  downloadForms() {
    this.isLoadingResults = true;
    /* Downloading as PDF IF one item is seleted */
    if (this.selectedoption === 'Hong Kong') {
      this.getCountry = 'HK';
    } else if (this.selectedoption === 'Singapore') {
      this.getCountry = 'SG';
    } else if (this.selectedoption === 'Bermuda') {
      this.getCountry = 'BM';
    }
    if (this.selection.selected.length === 1) {
      let pdfName = '';
      this.formsPackage.extractFormbyDoc(this.getCountry,this.selection.selected[0].DocumentName).subscribe(res => {
        if (res) {
          this.isLoadingResults = false;
        }
        pdfName = this.selection.selected[0].DocumentName + '.pdf';
        saveAs(res, pdfName);
      }, error => {
        console.log('No distributor guide detail found');
      }
      );
    } else {
      this.downloadApiParams = '';
      let i = 0;
      this.selection.selected.forEach(element => {
        this.downloadApiParams = this.downloadApiParams + 'docNames[' + i + ']=' + element.DocumentName + '&';
        i++;
      });
      this.formsPackage.searchDownloadForms(this.getCountry,this.downloadApiParams.slice(0, -1)).subscribe(res => {
        this.isLoadingResults = false;
        const pdfObj = new Blob([res], { type: '	application/zip' });
        saveAs(res, 'package.zip');
      },
        err => {
          console.log(err);
        }
      );
    }
  }
}







