import { Component, OnInit } from '@angular/core';
import { AppConstants } from '@app/app.constants';

@Component({
  selector: 'app-my-profile',
  templateUrl: './my-profile.component.html',
  styleUrls: ['./my-profile.component.scss']
})
export class MyProfileComponent implements OnInit {

  profileIcon = this.app.profileIcon;
  infoIcon = this.app.infoIcon;
  isChangePassword = false;
  changeTextPassword = 'Change';
  ctaArrowWhiteIcon = this.app.ctaArrowWhiteIcon;
  username = '';
  email = '';
  producerID = '';

  constructor(private app: AppConstants) { }

  ngOnInit() {
    this.username = localStorage.getItem('FirstName') + ' ' + localStorage.getItem('LastName');
    this.email = localStorage.getItem('EmailID');
    if (localStorage.getItem('ProducerID') !== 'null') {
      this.producerID = localStorage.getItem('ProducerID');
    }

  }
  changePassword() {
    this.isChangePassword = !this.isChangePassword;
    if (this.isChangePassword) {
      this.changeTextPassword = '';
    } else {
      this.changeTextPassword = 'Change';
    }
  }

  cancelChange() {
    this.isChangePassword = !this.isChangePassword;
    this.changeTextPassword = 'Change';
  }


}
