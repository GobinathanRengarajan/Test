import { Component, OnInit, Input } from '@angular/core';
// import { Router } from '@angular/router';
import { AppConstants } from '@app/app.constants';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-noresultsfound',
  templateUrl: './noresultsfound.component.html',
  styleUrls: ['./noresultsfound.component.scss']
})
export class NoresultsfoundComponent implements OnInit {

  findValue: string;
  firstname: string;
  months: string;
  birth: string;

  constructor(private app: AppConstants, private route: ActivatedRoute) { }

  noresultsfound = this.app.noresultsfound;
  ngOnInit() {
    this.route.queryParams.subscribe(data => {
      this.findValue = data.policynumber;
      this.firstname = data.surname + data.givenname;
      this.months = data.month;
      this.birth = data.birthdaymonth + data.year;
    });
  }
}
