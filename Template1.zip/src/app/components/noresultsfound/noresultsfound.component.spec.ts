import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NoresultsfoundComponent } from './noresultsfound.component';
// import { Router } from '@angular/router';
import { AppConstants } from '@app/app.constants';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { AuthService } from '@app/core/authentication/auth.service';
describe('NoresultsfoundComponent', () => {
  let component: NoresultsfoundComponent;
  let fixture: ComponentFixture<NoresultsfoundComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NoresultsfoundComponent ],
      imports: [ BrowserAnimationsModule, BrowserDynamicTestingModule, RouterTestingModule, HttpClientTestingModule],
      providers: [AuthService, AppConstants],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NoresultsfoundComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
