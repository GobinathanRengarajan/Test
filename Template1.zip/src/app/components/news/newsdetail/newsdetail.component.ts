import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { AppConstants } from '@app/app.constants';
import { ActivatedRoute, Router } from '@angular/router';
import * as moment from 'moment';
import { NewserviceService } from '@app/core/services/newservice/newservice.service';
@Component({
  selector: 'app-newsdetail',
  templateUrl: './newsdetail.component.html',
  styleUrls: ['./newsdetail.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class NewsdetailComponent implements OnInit {
  slider = this.app.slider;
  newsthumb_1 = this.app.newsthumb_1;
  prevarrow = this.app.prevarrow;
  nextarrow = this.app.nextarrow;
  Image1FileURL: string;
  Image2FileURL: string;
  Image3FileURL: string;
  Image4FileURL: string;
  Image5FileURL: string;
  newsID: string;
  height: any;
  news: any;
  title: string;
  author: string;
  description: string;
  recordCreated_Date: any;
  imageSources: any;
  moreDetails: any = [];
  detaillist: any = [];
  imageUrlArray: Array<string>;
  moreNewDetailsArray = [];
  defaultBG = this.app.defaultimage;
  isDataAvailable = true;
  constructor(private app: AppConstants, private newserviceService: NewserviceService,
    private activatedRoute: ActivatedRoute, private router: Router, ) {

  }
  ngOnInit() {
    this.getallnewsdetail();
    this.getmorenewsdetails();
    this.imageUrlArray = [];
    this.router.routeReuseStrategy.shouldReuseRoute = () => false;
  }
  getID(ID) {
    this.router.navigate(['newsbulletin/newsdetail', ID]);
    this.newsID = ID;
    // this.getallnewsdetail()
    console.log('this.newsID', this.newsID);
  }
  getallnewsdetail() {
    this.newsID = this.activatedRoute.snapshot.paramMap.get('newsid');
    this.newserviceService.getnewsdetail(this.newsID).subscribe(data => {
      if (data) {
        this.isDataAvailable = false;
      }
      this.news = data;
      this.title = data['Title'];
      this.recordCreated_Date = moment(data['recordCreated_Date']);
      this.description = data['Description'];
      this.author = data['Author'];
      if (this.news.Images.Image1FileURL != null) {
        this.imageUrlArray.push(this.news.Images.Image1FileURL);
      }
      if (this.news.Images.Image2FileURL != null) {
        this.imageUrlArray.push(this.news.Images.Image2FileURL);
      }
      if (this.news.Images.Image3FileURL != null) {
        this.imageUrlArray.push(this.news.Images.Image3FileURL);
      }
      if (this.news.Images.Image4FileURL != null) {
        this.imageUrlArray.push(this.news.Images.Image4FileURL);
      }
      if (this.news.Images.Image5FileURL != null) {
        this.imageUrlArray.push(this.news.Images.Image5FileURL);
      }
    }, error => {
      this.router.navigate(['notfound']);
    });
  }

  getmorenewsdetails() {
    this.newsID = this.activatedRoute.snapshot.paramMap.get('newsid');
    this.newserviceService.getmorenewsdetails(this.newsID).subscribe(data => {
      console.log(data);
      const dataarray = [];

      for (let i = 0; i < data.length; i++) {
        if (data[i].publishStatus === 1) {
          dataarray.push(data[i]);
        }
      }
      console.log('dataarray', dataarray);
      // this.moreDetails = dataarray;
      for (let i = 0; i < dataarray.length; i++) {
        this.moreNewDetailsArray.push({
          newsID: dataarray[i].ID, title: dataarray[i].Title,
          imageurl: dataarray[i].defaultImageURL
        });
      }

    });
  }

}
