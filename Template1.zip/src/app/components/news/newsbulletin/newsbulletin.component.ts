import { Component, OnInit, ViewChild } from '@angular/core';
import { AppConstants } from '@app/app.constants';
import { PageEvent, MatPaginator } from '@angular/material';
import { NewsandbulletinsService } from '@app/core/services/Newsandbulletins/newsandbulletins.service';
import { trigger, transition, animate, style } from '@angular/animations';
import { PagerService } from '@app/core/services/pagination';
import { Router } from '@angular/router';

@Component({
  selector: 'app-newsbulletin',
  templateUrl: './newsbulletin.component.html',
  styleUrls: ['./newsbulletin.component.scss'],
  providers: [PagerService],
  animations: [
    trigger('fade', [
      transition('void => *', [style({ opacity: 0 }), animate('600ms', style({ opacity: 1 }))]),
      transition('* => void', [style({ opacity: 1 }), animate('600ms', style({ opacity: 0 }))]),
    ])
  ]
})
export class NewsbulletinComponent implements OnInit {
  medium_1 = this.app.medium_1;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  getnewsandbulletinsData: any;
  getbulletinsData = [];
  getnewsData: string[] = [];
  getnewsDataDic = [];
  defaultBG = this.app.defaultimage;
  isDataAvailable = true;

  // pagination
  private allItems: any[];
  pager: any = {};
  pagedItems: any[];


  // text slider
  current = 0;
  textList = [
    'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptate, a? - 1',
    'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptate, a? - 2',
    'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptate, a? - 3',
  ];

  constructor(
    private app: AppConstants,
    private newsandbulletinsService: NewsandbulletinsService,
    private pagerService: PagerService,
    private router: Router) { }

  ngOnInit() {
    this.getNewsBulletins();
  }

  // text slider prev next
  next() {
    this.current = ++this.current % this.textList.length;
  }
  prev() {
    this.current = --this.current + this.textList.length % this.textList.length;
    if (this.current < 0) {
      this.current = this.textList.length - 1;
    }
  }

  syncPrimaryPaginator(event: PageEvent) {
    this.paginator.pageIndex = event.pageIndex;
    this.paginator.pageSize = event.pageSize;
    this.paginator.page.emit(event);
  }

  getNewsBulletins() {
    this.newsandbulletinsService.getNewsAndBulletins().subscribe((data => {
      console.log('data checking', data);
      if (data) {
        this.isDataAvailable = false;
      }
      this.getnewsandbulletinsData = data;
      for (let i = 0; i < this.getnewsandbulletinsData.length; i++) {
        if (this.getnewsandbulletinsData[i].publishStatus === 1) {
          if (this.getnewsandbulletinsData[i].Description != null) {
            this.getnewsDataDic.push({
              newsID: this.getnewsandbulletinsData[i].ID,
              imageurl: this.getnewsandbulletinsData[i].defaultImageURL ? this.getnewsandbulletinsData[i].defaultImageURL : this.defaultBG,
              newsTitle: this.getnewsandbulletinsData[i].Title
            });
            this.setPage(1);
          } else {
            this.getbulletinsData.push({ bulletinTitle: this.getnewsandbulletinsData[i].Title });
          }
        }
      }
    }));
  }


  // pagination function
  setPage(page: number) {
    if (page < 1 || page > this.pager.totalPages) {
      return;
    }
    // get pager object from service
    this.pager = this.pagerService.getPager(this.getnewsDataDic.length, page);
    // get current page of items
    this.pagedItems = this.getnewsDataDic.slice(this.pager.startIndex, this.pager.endIndex + 1);
  }
}
