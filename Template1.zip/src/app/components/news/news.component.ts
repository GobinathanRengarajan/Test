import { Component, OnInit } from '@angular/core';
import { AppConstants } from '@app/app.constants';
import { NewsandbulletinsService } from '@app/core/services/Newsandbulletins/newsandbulletins.service';
import * as moment from 'moment';
@Component({
  selector: 'app-news',
  templateUrl: './news.component.html',
  styleUrls: ['./news.component.scss']
})
export class NewsComponent implements OnInit {

  title = this.app.newsTitle;
  thumbImage_1 = this.app.thumbImage_1;
  thumbImage_2 = this.app.thumbImage_2;
  defaultBG = this.app.defaultimage;
  getnewsandbulletinsData: any;
  getbulletinsData: string[] = [];
  getnewsData: string[] = [];
  getnewsDataDic = [];
  getetnewsData = [];
  constructor(private app: AppConstants, private newsandbulletinsService: NewsandbulletinsService) { }

  ngOnInit() {
    this.getNewsBulletins();
  }
  getNewsBulletins() {
    this.newsandbulletinsService.getNewsAndBulletins().subscribe(data => {
      this.getnewsandbulletinsData = data;
      for (let i = 0; i < this.getnewsandbulletinsData.length; i++) {
        if (this.getnewsandbulletinsData[i].publishStatus === 1 && this.getnewsandbulletinsData[i].Description != null) {
          this.getetnewsData.push({
            newsID: this.getnewsandbulletinsData[i].ID,
            imageurl: this.getnewsandbulletinsData[i].defaultImageURL,
            newsTitle: this.getnewsandbulletinsData[i].Title,
            recordCreated_Date: moment(this.getnewsandbulletinsData[i].RecordCreated_Date)
          });

        }
      }
      this.getnewsDataDic.push(this.getetnewsData[0], this.getetnewsData[1]);
    });
  }
}
