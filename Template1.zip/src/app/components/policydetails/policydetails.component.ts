import { Component, OnInit, ViewEncapsulation, ViewChild, ElementRef, Renderer2, Inject, OnDestroy } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { InforceService } from '@services/inforce/inforce.service';
import { ActivatedRoute, Router } from '@angular/router';
import { AppConstants } from '@app/app.constants';
import { NewbusinessService } from '@app/core/services/newbusiness/newbusiness.service';
import jsPDF from 'app/jspdf/jspdf.min.js';
import { DomSanitizer } from '@angular/platform-browser';
import * as $ from 'jquery';
import * as moment from 'moment';
var jsPDF = require('jspdf');
require('jspdf-autotable');

@Component({
  selector: 'app-policydetails',
  templateUrl: './policydetails.component.html',
  styleUrls: ['./policydetails.component.scss'],
  encapsulation: ViewEncapsulation.None,
  providers: [InforceService
  ],
})
export class PolicydetailsComponent implements OnInit {
  fileUrl;
  panelOpenState = true;
  tabsVertical = true;
  flexboxifiedContent = false;
  additionalTabHeads: any[];
  detailslist: any = [];
  policynumber: string;
  policyeffectdate: string;
  policyissuedate: string;
  status: string;
  issuestate: string;
  policytype: string;
  prodname: string;
  riskclass: string;
  ratedpolicy: string;
  serviceoffice: string;
  servicingagent: string;
  ownername: string;
  ownergender: string;
  ownerdob: string;
  usperson: string;
  insuredname: string;
  insgender: string;
  insureddob: string;
  issueage: string;
  joinedInsuredName: string;
  joinedgender: string;
  joinedidob: string;
  joinediiage: string;
  Showtxt: string;
  pageFrom: string;
  userId: string;
  UserID: string;
  policyNo: string;
  xpandStatus = true;
  xpandStatusone = false;
  xpandStatusonerider = false;
  xpandStatustwo = false;
  xpandStatusthree = false;
  xpandStatusfour = false;
  xpandStatusfive = false;
  enableDownloadbtn = true;
  AccountValue: string;
  SurrenderCharge: string;
  SurrenderValue: string;
  MonthlyDeduction: string;
  CurrentCrediting: string;
  CurrentAssumed: string;
  NonForfeiture: string;
  Outstanding: string;
  MaximumAvailable: string;
  LoanInterestca: string;
  LoanInterestcb: string;
  TotalWithdrawals: string;
  WithdrawalsYTD: string;
  prdetailslist: any = [];
  detailslistfinance: any = [];
  detailslistreltionship: any = [];
  detailslistpremium: any = [];
  detailslistinfo: any = [];
  dataSource: any = [];
  coveragedataSource: any = [];
  befeficiarysdataSource: any = [];
  addressdataSource: any = [];
  inforiderdataSource: any = [];
  showhoneymoon = false;
  ownernameheading: string;
  relationshipPayorName: string;
  benificaryCount: any;
  inforAsofDate: any;
  cashValue: any;
  dividendOption: any;
  deposit: any;
  annualPremiumNext: any;
  paymentDate: any;
  printId = 'policyInformation';
  email: string;
  phonenum: string;
  @ViewChild('caputures') caputures: ElementRef;
  @ViewChild('myInput') myInput: ElementRef;
  @ViewChild('focuss') focuss: ElementRef;
  selectedValue: string;
  selectedYear = 'Select Year';
  annualfileDetails: any = [];
  annualfileYears: any = [];
  selected: string;
  selectedYears: any = [
    // { "value" : "2016" , "viewValue" : "2016-2017" },
    // { "value" : "2017" , "viewValue" : "2017-2018" },
    // { "value" : "2018" , "viewValue" : "2018-2019" },
  ];
  // loading
  isLoadingResults: boolean;
  labelText: any;
  constructor(
    private inforceService: InforceService,
    private nbService: NewbusinessService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private app: AppConstants,
    private renderer: Renderer2,
    private content: ElementRef,
    private sanitizer: DomSanitizer,
    @Inject(DOCUMENT) private document: Document,
  ) {
    const tr = localStorage.setItem('xpandStatusone', 'false');
  }
  emailIconGrey = this.app.emailIconGrey;
  downloadIconGrey = this.app.downloadIconGrey;
  printIcon = this.app.printIcon;
  addressTLBColumns: string[] = ['roles', 'name', 'CorrespondenceAddress', 'ContactNumber', 'email'];
  covTLBColumns: string[] = ['benefittype', 'sumassured', 'effectiveDate', 'annualCovPremium', 'issueAge'];
  befeficiaryTLBColumns: string[] = ['Name', 'Relationship', 'percentage'];

  // Non-UL table columns
  InforRiderTLBColumns: string[] = ['Plan',
    'TableRating', 'SumAssured', 'PolicyDate',
    'MaturityDate', 'AnnualCoveragePremium',
    'InsuredGender', 'IssueAge'];
  lifeProClientId: string[] =
    ['HK HNM DEF SURR', 'HK HONEYMOON', 'HONEYM DEF SURR', 'HONEYMOON',
      'HNYM DEF SURR 3', 'PREM FIN HNYM 3', 'HONEYMOON 3', 'PRFI HNYM DFS 3',
      'HNYM DEF SURR 5', 'PREM FIN HNYM 5', 'HONEYMOON 5', 'PRFI HNYM DFS 5',
      'HNYM DEFSURR5 2', 'PREM FIN HNYM5 2', 'HONEYMOON5 2', 'PRFI HNYM DFS5 2',
      'HNYM DEF SURR 3', 'PREM FIN HNYM 3', 'HONEYMOON 3', 'PRFI HNYM DFS 3'];

  ngOnInit() {
    this.additionalTabHeads = [];
    this.policynumber = this.activatedRoute.snapshot.paramMap.get('policyNumber');
    this.getdetails();
    this.getfinancedetails();
    this.getreltionshipdetails();
    this.getpremiumdetails();
    // this.getinfodetails();
    this.activatedRoute.queryParams.subscribe(params => {
      this.pageFrom = params.from;
    });
    this.inforAsofDate = moment(new Date());
    this.ExtractAnnualfileDetailsbyPolicynum();
    this.renderer.addClass(this.document.body, 'policy-body');
  }

  // tslint:disable-next-line: no-shadowed-variable
  setfocus = (element, offsetParam?, speedParam?) => {
    const toElement = $(element);
    const focusElement = $(element);
    const offset = offsetParam * 1 || 200;
    const speed = speedParam * 1 || 500;
    $('html, body').animate({
      scrollTop: toElement.offset().top + offset
    }, speed);
    if (focusElement) {
      $(focusElement).focus();
    }
    this.xpandStatusone = this.xpandStatusone ? false : true;
  }

  // tslint:disable-next-line: no-shadowed-variable
  setfocusfinancial = (element, offsetParam?, speedParam?) => {
    const toElement = $(element);
    const focusElement = $(element);
    const offset = offsetParam * 1 || 200;
    const speed = speedParam * 1 || 500;
    $('html, body').animate({
      scrollTop: toElement.offset().top + offset
    }, speed);
    if (focusElement) {
      $(focusElement).focus();
    }
    this.xpandStatustwo = this.xpandStatustwo ? false : true;
  }

  // tslint:disable-next-line: no-shadowed-variable
  setplaninfo = (element, offsetParam?, speedParam?) => {
    const toElement = $(element);
    const focusElement = $(element);
    const offset = offsetParam * 1 || 200;
    const speed = speedParam * 1 || 500;
    $('html, body').animate({
      scrollTop: toElement.offset().top + offset
    }, speed);
    if (focusElement) {
      $(focusElement).focus();
    }
    this.xpandStatusonerider = this.xpandStatusonerider ? false : true;
  }

  // tslint:disable-next-line: no-shadowed-variable
  setpremium = (element, offsetParam?, speedParam?) => {
    const toElement = $(element);
    const focusElement = $(element);
    const offset = offsetParam * 1 || 200;
    const speed = speedParam * 1 || 500;
    $('html, body').animate({
      scrollTop: toElement.offset().top + offset
    }, speed);
    if (focusElement) {
      $(focusElement).focus();
    }
    this.xpandStatusthree = this.xpandStatusthree ? false : true;
  }


  // tslint:disable-next-line: no-shadowed-variable
  setrelation = (element, offsetParam?, speedParam?) => {
    const toElement = $(element);
    const focusElement = $(element);
    const offset = offsetParam * 1 || 200;
    const speed = speedParam * 1 || 500;
    $('html, body').animate({
      scrollTop: toElement.offset().top + offset
    }, speed);
    if (focusElement) {
      $(focusElement).focus();
    }
    this.xpandStatusfour = this.xpandStatusfour ? false : true;
  }


  // tslint:disable-next-line: no-shadowed-variable
  setaddress = (element, offsetParam?, speedParam?) => {
    const toElement = $(element);
    const focusElement = $(element);
    const offset = offsetParam * 1 || 200;
    const speed = speedParam * 1 || 500;
    $('html, body').animate({
      scrollTop: toElement.offset().top + offset
    }, speed);
    if (focusElement) {
      $(focusElement).focus();
    }
    this.xpandStatusfive = this.xpandStatusfive ? false : true;
  }


  // tslint:disable-next-line: no-shadowed-variable
  setpolicy = (element, offsetParam?, speedParam?) => {
    const toElement = $(element);
    const focusElement = $(element);
    const offset = offsetParam * 1 || 200;
    const speed = speedParam * 1 || 500;
    $('html, body').animate({
      scrollTop: toElement.offset().top + offset
    }, speed);
    if (focusElement) {
      $(focusElement).focus();
    }
    this.xpandStatus = this.xpandStatus ? false : true;
  }

  allPanelOpenClose() {
    this.xpandStatus = true;
    this.xpandStatusone = true;
    this.xpandStatusonerider = true;
    this.xpandStatustwo = true;
    this.xpandStatusthree = true;
    this.xpandStatusfour = true;
    this.xpandStatusfive = true;

    setTimeout(() => {
      this.xpandStatus = true;
      this.xpandStatusone = false;
      this.xpandStatusonerider = false;
      this.xpandStatustwo = false;
      this.xpandStatusthree = false;
      this.xpandStatusfour = false;
      this.xpandStatusfive = false;
    }, 50000);
  }

  // tslint:disable-next-line: use-life-cycle-interface
  ngOnDestroy(): void {
    this.renderer.removeClass(this.document.body, 'policy-body');
  }
  getSelectValue() {
    this.router.navigate(['/inforce', 'View Complete List', 'all']);
  }


  // Policy  details Info
  getdetails() {
    this.inforceService.getinforcepolicydetails((localStorage.getItem('userId')), this.policynumber)
      .subscribe((data => {
        const objArray = [];
        if (data != null) {
          const displayobj: any = {};
          // console.log("Full data ",data);
          const ownerNameObj = data.filter(res => res.Relate_Code === 'PO').map(res => {
            const returnObj = {
              Owner_Last: res.IO_Last.trim(),
              Owner_First: res.IO_First.trim(),
              Owner_Middle: res.IO_Middle.trim(),
              Owner_Name: res.IO_Last.trim() + ', ' + res.IO_Middle.trim() + ' ' + res.IO_First.trim(),

            };
            if (res.Address != null) {
              ownerNameObj.Owner_Address = res.Address.trim();
            }
            if (res.Email != null) {
              ownerNameObj.Owner_Email = res.Email.trim();
            }
            if (res.Contact_Number != null) {
              ownerNameObj.Owner_Contact = res.Contact_Number.trim();
            }
            return returnObj;
          });
          const insuredObj = data.filter(res => res.Relate_Code === 'IN').map(res => {
            const returnObj = {
              Insured_Last: res.IO_Last.trim(),
              Insured_First: res.IO_First.trim(),
              Insured_Middle: res.IO_Middle.trim(),
              Insured_Name: res.IO_Last.trim() + ', ' + res.IO_Middle.trim() + ' ' + res.IO_First.trim(),
            };
            if (res.Address != null) {
              insuredObj.Insured_Address = res.Address.trim();
            }
            if (res.Email != null) {
              insuredObj.Insured_Email = res.Email.trim();
            }
            if (res.Contact_Number != null) {
              insuredObj.Insured_Contact = res.Contact_Number.trim();
            }
            return returnObj;
          });
          const joinInsuredObj = data.filter(res => res.Relate_Code === 'JI').map(res => {
            const returnObj = {
              JoinInsured_Last: res.IO_Last.trim(),
              JoinInsured_First: res.IO_First.trim(),
              JoinInsured_Middle: res.IO_Middle.trim(),
              JoinInsured_Name: res.IO_Last.trim() + ', ' + res.IO_Middle.trim() + ' ' + res.IO_First.trim(),
            };
            if (res.Address != null) {
              joinInsuredObj.jointInsured_Address = res.Address.trim();
            }
            if (res.Email != null) {
              joinInsuredObj.JoinInsured_Email = res.Email.trim();
            }
            if (res.Contact_Number != null) {
              joinInsuredObj.JoinInsured_Contact = res.Contact_Number.trim();
            }
            return returnObj;
          });
          const payorObj = data.filter(res => res.Relate_Code === 'PA').map(res => {
            const returnObj = {
              Payor_Last: res.IO_Last.trim(),
              Payor_First: res.IO_First.trim(),
              Payor_Middle: res.IO_Middle.trim(),
              Payor_Name: res.IO_Last.trim() + ', ' + res.IO_Middle.trim() + ' ' + res.IO_First.trim(),
            };
            if (res.Address != null) {
              payorObj.Payor_Address = res.Address.trim();

            }
            if (res.Email != null) {
              payorObj.Payor_Email = res.Email.trim();
            }
            if (res.Contact_Number != null) {
              payorObj.Payor_Contract = res.Contact_Number.trim();
            }
            return returnObj;
          });

          if (data[0].Res_State === 'US') {
            this.usperson = 'Yes';
          } else {
            this.usperson = 'No';
          }
          if ((data[0].LINE_OF_BUSINESS === 'L') || (data[0].LINE_OF_BUSINESS == null)) {
            this.policytype = 'Non-UL';
          } else {
            this.policytype = 'UL';
          }
          displayobj.policyNumber = data[0].Policy_Number;
          displayobj.policyeffectdate = moment(data[0].Billing_Date);
          displayobj.policyissuedate = moment(data[0].Issue_Date);
          displayobj.status = data[0].Contract_Code;
          displayobj.issuestate = data[0].Issue_State;
          displayobj.policytype = this.policytype; // LINE_OF_BUSINESS ('L'  None UL, 'U' UL)
          displayobj.prodname = data[0].Market_Name;
          displayobj.riskclass = data[0].UnderWriting_Code;
          displayobj.ratedpolicy = data[0].Rated_Policy;
          displayobj.serviceoffice = data[0].Servicing_Office;
          displayobj.servicingagent = data[0].Servicing_Agency;

          if (ownerNameObj.length > 0) { // If Relate_code='PO', IO_Last+IO_Middle+IO_First
            displayobj.ownername = ownerNameObj[0].Owner_Name;
            this.ownernameheading = ownerNameObj[0].Owner_Name;
            displayobj.ownercontact = ownerNameObj[0].Owner_Contact;
            displayobj.owneremail = ownerNameObj[0].Owner_Email;
            displayobj.owneraddress = ownerNameObj[0].Owner_Address;
          }
          displayobj.ownergender = data[0].Sex_Code;
          displayobj.ownerdob = moment(data[0].Date_Of_Birth);

          displayobj.usperson = this.usperson;  // If Res_State = 'US' Then Yes, otherwise No

          if (insuredObj.length > 0) {  // If Relate_code='IN', IO_Last+IO_Middle+IO_First
            displayobj.insuredname = insuredObj[0].Insured_Name;
            displayobj.insuredcontact = insuredObj[0].Insured_Contact;
            displayobj.insuredemail = insuredObj[0].Insured_Email;
            displayobj.insuredaddress = insuredObj[0].Insured_Address;
          }
          displayobj.insgender = data[0].Sex_Code;
          displayobj.insureddob = moment(data[0].Date_Of_Birth);
          displayobj.issueage = data[0].Issue_Age;
          if (joinInsuredObj.length > 0) { // If Relate_code='JI', IO_Last+IO_Middle+IO_First
            displayobj.joininsuredname = joinInsuredObj[0].JoinInsured_Name;
            displayobj.joininsuredcontact = joinInsuredObj[0].JoinInsured_Contact;
            displayobj.joininsuredemail = joinInsuredObj[0].JoinInsured_Email;
            displayobj.joininsuredaddress = joinInsuredObj[0].JoinInsured_Address;
          }
          displayobj.joinedgender = data[0].Sex_Code;
          displayobj.joinedidob = moment(data[0].Date_Of_Birth);
          displayobj.joinediiage = data[0].Issue_Age;
          // finance information
          this.cashValue = data[0].Cash_Value ? '$' + data[0].Cash_Value : '$0.00';
          this.dividendOption = data[0].Dividend_Option;
          this.deposit = data[0].Deposit;

          // premium billing information
          this.annualPremiumNext = data[0].Annual_Premium_Next;
          this.paymentDate = data[0].Payment_Date;
          // Coverage Information
          displayobj.coverages = [];
          // tslint:disable-next-line: no-shadowed-variable
          data.forEach(element => {
            const singleObj: any = {};
            singleObj.benefittype = element.Benefit_Type;
            singleObj.sumassured = element.Sum_Assured;
            singleObj.effectiveDate = moment(element.Contract_Date);
            singleObj.maturityDate = moment(element.Mature_Expire_Date);
            singleObj.annualCovPremium = element.Annual_Premium;
            singleObj.issueAge = element.Issue_Age;
            displayobj.coverages.push(singleObj);
          });

          // Address
          displayobj.Address = [];
          // Relate_code='PO'
          if (ownerNameObj.length > 0) {
            const singleObj: any = {};
            singleObj.roles = 'Owner';
            singleObj.names = ownerNameObj[0].Owner_Name;
            singleObj.corresspondenceAddress = ownerNameObj[0].Owner_Address;
            singleObj.contactNumber = ownerNameObj[0].Owner_Contact;
            singleObj.email = ownerNameObj[0].Owner_Email;
            displayobj.Address.push(singleObj);
          }
          // Relate_code='IN'

          if (insuredObj.length > 0) {
            const singleObj: any = {};
            singleObj.roles = 'Insured';
            singleObj.names = insuredObj[0].Insured_Name;
            singleObj.corresspondenceAddress = insuredObj[0].Insured_Address;
            singleObj.contactNumber = insuredObj[0].Insured_Contact;
            singleObj.email = insuredObj[0].Insured_Email;
            displayobj.Address.push(singleObj);
          }
          // Relate_code='JI'
          if (joinInsuredObj.length > 0) {
            const singleObj: any = {};
            singleObj.roles = 'Joint Insured';
            singleObj.names = joinInsuredObj[0].JoinInsured_Name;
            singleObj.corresspondenceAddress = joinInsuredObj[0].JoinInsured_Address;
            singleObj.contactNumber = joinInsuredObj[0].JoinInsured_Contact;
            singleObj.email = joinInsuredObj[0].JoinInsured_Email;
            displayobj.Address.push(singleObj);
          }
          // Relate_code='PA'
          if (payorObj.length > 0) {
            const singleObj: any = {};
            singleObj.roles = 'Payor';
            singleObj.names = payorObj[0].Payor_Name;
            singleObj.corresspondenceAddress = payorObj[0].Payor_Address;
            singleObj.contactNumber = payorObj[0].Payor_Contact;
            singleObj.email = payorObj[0].Payor_Email;
            displayobj.Address.push(singleObj);
          }
          if (payorObj.length > 0) {  // If Relate_code='PA', IO_Last+IO_Middle+IO_First
            displayobj.payor = payorObj[0].Payor_Name;
            this.relationshipPayorName = payorObj[0].Payor_Name;
            displayobj.insuredcontact = payorObj[0].Payor_Contact;
            displayobj.insuredemail = payorObj[0].Payor_Email;
            displayobj.insuredaddress = payorObj[0].Payor_Address;
          }

          objArray.push(displayobj);
        }
        this.detailslist = objArray;
        // prepare coverage table data
        const coverage_data: any = [];
        // tslint:disable-next-line: no-shadowed-variable
        this.detailslist[0].coverages.forEach(element => {
          const singleObj: any = {};
          singleObj.benefittype = element.benefittype;
          singleObj.sumassured = element.sumassured ? '$' + element.sumassured : '$0.00';
          singleObj.effectiveDate = moment(element.effectiveDate);
          singleObj.annualCovPremium = element.annualCovPremium ? '$' + element.annualCovPremium : '$0.00';
          singleObj.issueAge = element.issueAge;
          coverage_data.push(singleObj);
        });
        this.coveragedataSource = coverage_data;
        // prepare address table data
        const address_data: any = [];
        // tslint:disable-next-line: no-shadowed-variable
        this.detailslist[0].Address.forEach(element => {
          const singleObj: any = {};
          singleObj.roles = element.roles;
          singleObj.name = element.names;
          singleObj.CorrespondenceAddress = element.CorrespondenceAddress;
          singleObj.ContactNumber = element.ContactNumber;
          singleObj.email = element.email;
          address_data.push(singleObj);
        });
        this.addressdataSource = address_data;
        // prepare info-rider table data
        const inforRider_data: any = [];
        const infoRiderObj: any = {};
        infoRiderObj.Plan = data[0].Plan_Code;
        infoRiderObj.TableRating = data[0].Table_Rating;
        infoRiderObj.SumAssured = data[0].Sum_Assured ? '$' + data[0].Sum_Assured : '$0.00';
        infoRiderObj.PolicyDate = moment(data[0].Issue_Date);
        infoRiderObj.MaturityDate = data[0].Mature_Expire_Date;
        infoRiderObj.AnnualCoveragePremium = data[0].Annual_Premium ? '$' + data[0].Annual_Premium : '$0.00';
        infoRiderObj.InsuredGender = data[0].Sex_Code;
        infoRiderObj.IssueAge = data[0].Issue_Age;
        inforRider_data.push(infoRiderObj);
        this.inforiderdataSource = inforRider_data;
        this.Showtxt = this.policynumber;
        console.log('Policy details - info', this.detailslist);
        localStorage.setItem('policyDetails', JSON.stringify(this.detailslist));
      }));
  }

  // Policy Details Finance
  getfinancedetails() {
    this.inforceService.getfinance((localStorage.getItem('userId')), this.policynumber)
      .subscribe(data => {
        const objArray = [];
        const displayobj: any = {};
        displayobj.cashValue = data[0] ? '$' + data[0].Cash_Value : '$0.00';
        displayobj.accountValue = data[0] ? '$' + data[0].Curr_Int_Amount : '$0.00';
        displayobj.surrenderCharge = data[0] ? '$' + data[0].Surr_Chg_Excl_Mva : '$0.00';
        displayobj.surrenderValue = data[0] ? '$' + data[0].Bf_Curr_Surr_Load : '$0.00';
        displayobj.monthlyDeductionAmount = data[0] ? '$' + data[0].Deduction_Amount : '$0.00';
        displayobj.currentCreditingInterestRate = data[0] ? data[0].Curr_Int_Rate : '';
        displayobj.currentAssuredCreditingInterestRate = data[0] ? data[0].Accrued_Int_Amt : '';
        displayobj.nonForfeitureOption = data[0] ? data[0].Non_Forfeiture : '';
        displayobj.outstandingLoanamount = data[0] ? '$' + data[0].Loan_Balance : '$0.00';
        displayobj.maximumAvailableLoanAmount = data[0] ? '$' + data[0].Loan_Amount : '$0.00';
        displayobj.loanInterestRateClassA = data[0] ? data[0].Interest_Rate : '';
        displayobj.loanInterestRateClassB = data[0] ? data[0].Spec_Cls_Int_Rate : '';
        displayobj.totalWidthdrawal = data[0] ? data[0].Gross_Withdrawal : '';
        displayobj.widthdrawalYTD = data[0] ? data[0].Net_Withdrwl_Rpmnt : '';
        if ((data[0]) && (this.lifeProClientId.includes(data[0].Client_Id))) {  // if Client_Id in the list( Attached)
          this.showhoneymoon = true;
        }
        objArray.push(displayobj);

        this.detailslistfinance = objArray;
        console.log('Policy details - Finance', this.detailslistfinance);
      });
  }
  // Policy Details Premium billing
  getpremiumdetails() {
    this.inforceService.getpremiumbilling((localStorage.getItem('userId')), this.policynumber)
      .subscribe(data => {
        // console.log('Policy details - premium billing',data);
        const objArray = [];

        const displayobj: any = {};
        displayobj.originalRequiredAnnualPremiumAmount = data[0] ? '$' + data[0].Annual_Premium : '$0.00';
        displayobj.currentRequiredAnnualPremiumAmount = data[0] ? '$' + data[0].Annual_Amount : '$0.00';
        displayobj.requiredAnnualPremiumPreiod = data[0] ? data[0].Xbil_Sequence : '';
        displayobj.paymentFrequency = data[0] ? data[0].Billing_Mode : '';
        displayobj.bankNumber = data[0] ? data[0].Bank_Number : '';
        displayobj.accountNumber = data[0] ? data[0].Account_Number : '';
        displayobj.accountHolderName = data[0] ? data[0].Account_Holder_Name : '';
        displayobj.lastPremiumPaymentDate = moment(data[0] ? data[0].Paid_To_Date : '');
        displayobj.lastPremiumEffectiveDate = moment(data[0] ? data[0].New_Eff_Date : '');
        displayobj.lastPremiumPaymentAmount = data[0] ? '$' + data[0].Payment_Amount : '$0.00';
        displayobj.totalPremiumDeposits = data[0] ? '$' + data[0].Total_Premium_Deposits : '$0.00';
        displayobj.premiumDepositYTD = data[0] ? '$' + data[0].Premium_Deposits_YTD : '$0.00';
        displayobj.modalPremiumAmount = data[0] ? '$' + data[0].Emplr_Modal_Prem : '$0.00';
        displayobj.plannedPremiumPaymentTerm = data[0] ? data[0].Plan_Premium_Payment_Term : '';
        displayobj.paidToDate = data[0] ? data[0].Paid_To_Date : '';
        objArray.push(displayobj);

        this.detailslistpremium = objArray;
        console.log('Policy details - premium billing', this.detailslistpremium);
      });
  }
  // Policy Details Relationship/Info
  getreltionshipdetails() {
    this.inforceService.getrelationship((localStorage.getItem('userId')), this.policynumber)
      .subscribe(data => {
        console.log('Policy details - relationship', data);
        const objArray = [];
        if (data != null) {
          const displayobj: any = {};
          displayobj.assignee = data.Assignee;
          displayobj.beneficiary = [];
          // tslint:disable-next-line: no-shadowed-variable
          data.Befeficiarys.forEach(element => {
            const singleObj: any = {};
            singleObj.name = element.Name;
            singleObj.relationship = element.RelationShip;
            singleObj.percentage = element.Percentage;
            displayobj.beneficiary.push(singleObj);
          });
          displayobj.benificaryCount = displayobj.beneficiary.length;
          this.benificaryCount = displayobj.beneficiary.length;
          objArray.push(displayobj);
        }
        this.detailslistreltionship = objArray;
        // prepare Befeficiarys table data
        const befeficiarys_data: any = [];
        // tslint:disable-next-line: no-shadowed-variable
        this.detailslistreltionship[0].beneficiary.forEach(element => {
          const singleObj: any = {};
          singleObj.Name = element.Name;
          singleObj.Relationship = element.Relationship;
          singleObj.percentage = element.percentage;

          befeficiarys_data.push(singleObj);
        });
        this.befeficiarysdataSource = befeficiarys_data;

        console.log('Policy details - relationship', this.detailslistreltionship);
      });
  }

  ExtractAnnualfileDetailsbyPolicynum() {
    this.inforceService.extractAnnualfileDetails(this.policynumber)
      .subscribe(data => {
        console.log(data);
        if (data != null) {
          this.annualfileDetails = JSON.parse(data);
          this.annualfileYears = this.annualfileDetails.AnnualFileDetails;
          // tslint:disable-next-line: no-shadowed-variable
          this.annualfileYears.forEach(element => {
            const yearsObj: any = {};
            console.log(element);
            yearsObj.value = element.Name + '_' + moment(element.CreateDate, 'M/D/YYYY h:mm:ss a').format('YYYYMMDDkkmmss');
            console.log('annual statement file', yearsObj.value);
            yearsObj.viewValue = element.CreateDate.split('/')[2].substring(0, 4);
            this.selectedYears.push(yearsObj);
          });
        }
        console.log('selectedyear', this.selectedYears)
      });
  }

  onSelect() {
    console.log(this.selected);
    this.enableDownloadbtn = false;
  }


  // dropdown value change on select
  downloadAnnualStatement() {
    this.isLoadingResults = true;
    const filename = this.selected;
    this.inforceService.downloadAnnualstatement(filename, this.policynumber)
      .subscribe(res => {
        // let pdfFile = 'Annual Statement_' + this.policynumber + '.pdf';
        // saveAs(res, pdfFile);
        if (res) {
          this.isLoadingResults = false;
        }

        if (window.navigator && window.navigator.msSaveOrOpenBlob) {
          window.navigator.msSaveOrOpenBlob(res, 'Annual Statement.pdf');
        } else {
          const pdfObj = new Blob([res], { type: 'application/pdf' });
          const fileURL = URL.createObjectURL(pdfObj);
          window.open(fileURL);
        }
      });

  }
  printMode() {
    this.xpandStatus = true;
    this.xpandStatusone = true;
    this.xpandStatusonerider = true;
    this.xpandStatustwo = true;
    this.xpandStatusthree = true;
    this.xpandStatusfour = true;
    this.xpandStatusfive = true;

    setTimeout(() => {
      this.xpandStatus = true;
      this.xpandStatusone = false;
      this.xpandStatusonerider = false;
      this.xpandStatustwo = false;
      this.xpandStatusthree = false;
      this.xpandStatusfour = false;
      this.xpandStatusfive = false;
    }, 50000);
    setTimeout(() => {
      const printContents = document.getElementById('caputures').innerHTML;
      const popupWin =
        window.open('', '_blank', 'width=1200,scrollbars=yes,menubar=no,toolbar=no,location=no,status=no,titlebar=no,top=150');
      popupWin.window.focus();
      popupWin.document.open();
      popupWin.document.write('<!DOCTYPE html><html><head><title> Policy Summary' + this.policynumber + '</title>'
        + '<link rel="stylesheet" href="../assets/scss/print.css">'
        + '</head><body><div class="main_body"><div class="header"><img src="../assets/images/pdf/header.png"></div>'
        + '<div class="policynum">  <h6> Policy Summary <span>' + this.policynumber + '</span> </h6> </div>'
        + printContents + '<div class="footer">IMPORTANT NOTE: The data presented on this site may not be'
        + 'relied upon to verify the status of or benefits payable under any policy.'
        + 'Please contact our Customer Services Team by phone at (65) 6212 0620 or by'
        + 'e-mail at customerservicesg@transamerica.com for information relating to this policy. </div></div></body></html>');
      popupWin.document.close();
      setTimeout(() => {
        popupWin.window.print();
      }, 1000);
    }, 2000);
  }


  captureScreen() {
    const doc1 = new jsPDF('p', 'mm', 'a4');
    doc1.setFont('HelveticaNeue');
    const dataimg = this.app.dataimg;
    const total_pdf_pages = doc1.internal.pages;
    doc1.addImage(dataimg, 'png', 0, 0, 207, 28);
    // doc1.setFillColor(217, 217, 217);
    // doc1.rect(0, 25, 80, 12, 'F');
    // doc1.setTextColor(4, 4, 4);
    // doc1.setFontSize(12);
    // doc1.text(5, 33, 'Policy Summary' + ' ' + this.policynumber);
    doc1.setFontSize(12);
    // doc1.setFillColor(217, 217, 217);
    // doc1.rect(5, 42, 191, 12, 'F');
    doc1.text('Policy Information', 80, 33);


    // *************** ______________ Policy Information first NON UL Table _____________*****************//


    const poliycolumn = [
      { title: 'Policy Number', dataKey: 'PolicyNumber' },
      { title: 'Policy Date', dataKey: 'PolicyDate' },
      { title: 'Status', dataKey: 'Stats' },
      { title: 'Issue State', dataKey: 'IssueState' },
      { title: 'Policy Type', dataKey: 'PolicyType' },
      { title: 'Product Name', dataKey: 'ProductName' },
      { title: 'Risk Class', dataKey: 'RiskClass' },
      { title: 'Rated Policy', dataKey: 'RatedPolicy' }
    ];


    const col = [
      { title: ' ' },
      { title: '' },
    ];

    const policyrow = this.detailslist;
    const policyrowsarr = [];


    // tslint:disable-next-line: no-shadowed-variable
    policyrow.forEach(element => {


      if (element.policyNumber === undefined || element.policyNumber === null) {
        element.policyNumber = 'N/A';
      }
      if (element.policyissuedate === undefined || element.policyissuedate === null) {
        element.policyissuedate = 'N/A';
      }
      if (element.status === undefined || element.status === null) {
        element.status = 'N/A';
      }
      if (element.issuestate === undefined || element.issuestate === null) {
        element.issuestate = 'N/A';
      }
      if (element.policytype === undefined || element.policytype === null) {
        element.policytype = 'N/A';
      }
      if (element.prodname === undefined || element.prodname === null) {
        element.prodname = 'N/A';
      }
      if (element.riskclass === undefined || element.riskclass === null) {
        element.riskclass = 'N/A';
      }
      if (element.ratedpolicy === undefined || element.ratedpolicy === null) {
        element.ratedpolicy = 'N/A';
      }
      if (element.insuredname === undefined || element.insuredname === null) {
        element.insuredname = 'N/A';
      }


      const policynum = { id: 'Policy Number', values: element.policyNumber };
      const policydat = { id: 'Policy Date', values: moment(element.policyissuedate).format('DD-MM-YYYY') };
      const stat = { id: 'Stats', values: element.status };
      const issuestate = { id: 'Issue State', values: element.issuestate };
      const policytype = { id: 'Policy Type', values: element.policytype };
      const prodname = { id: 'Product Name', values: element.prodname };
      const riskclas = { id: 'Risk Class', values: element.riskclass };
      const ratepolicy = { id: 'Rated Policy', values: element.ratedpolicy };
      const insuname = { id: 'Insured Name', values: element.insuredname };


      const merge = [policynum, policydat, stat, issuestate, policytype, prodname, riskclas,
        ratepolicy, insuname];


      merge.forEach(res => {
        const sec = [res.id, res.values];
        policyrowsarr.push(sec);
      });

      if (this.policytype === 'Non-UL') {
        doc1.autoTable(col, policyrowsarr, {
          theme: 'plain',
          tableWidth: 95,
          startY: 35.5,
          showHead: 'firstPage',
          margin: { left: 10 },
          bodyStyles: { fillColor: 255, textColor: 36, valign: 'top', lineWidth: 0.3, lineColor: [225, 225, 225] },
          avoidPageSplit: true,
          headerStyles: { fillColor: 255, textColor: 36, halign: 'left', lineWidth: 0, lineColor: [225, 225, 225] },
          styles: { overflow: 'linebreak', overflowColumns: false, fontSize: 9, lineWidth: 0.1, lineColor: [225, 225, 225] },
          columnWidth: 'wrap',
          columnStyles: {
            0: { fontStyle: 'bold', columnWidth: 40, },
            1: { fillColor: 246, columnWidth: 55 }
          }

        });
      }
    });



    // *************__________ Policy Information second NON UL Table ____________***********//




    const poliyseccolumnlist = [
      { title: ' ' },
      { title: ' ' },
    ];

    const poliyseccolumn = [
      { title: 'Servicing Office', dataKey: 'ServicingOffice' },
      { title: 'Servicing Agent', dataKey: 'ServicingAgent' },
      { title: 'Owner Name', dataKey: 'ownername' },
      { title: 'Owner Gender', dataKey: 'ownergender' },
      { title: 'Owner DOB', dataKey: 'ownerdob' },
      { title: 'US Person', dataKey: 'usperson' }
    ];



    const policysecrownonul = this.detailslist;
    const policysecrowsarr = [];


    // tslint:disable-next-line: no-shadowed-variable

    policysecrownonul.forEach(element => {

      if (element.serviceoffice === undefined || element.serviceoffice === null) {
        element.serviceoffice = 'N/A';
      }
      if (element.servicingagent === undefined || element.servicingagent === null) {
        element.servicingagent = 'N/A';
      }

      if (element.ownername === undefined || element.ownername === null) {
        element.ownername = 'N/A';
      }
      if (element.ownergender === undefined || element.ownergender === null) {
        element.ownergender = 'N/A';
      }
      if (element.ownerdob === undefined || element.ownerdob === null) {
        element.ownerdob = 'N/A';
      }
      if (element.usperson === undefined || element.usperson === null) {
        element.usperson = 'N/A';
      }
      if (element.insureddob === undefined || element.insureddob === null) {
        element.insureddob = 'N/A';
      }
      if (element.issueage === undefined || element.issueage === null) {
        element.issueage = 'N/A';
      }
      if (element.insgender === undefined || element.insgender === null) {
        element.insgender = 'N/A';
      }



      const ServicingOffice = { id: 'Servicing Office', values: element.serviceoffice };
      const ServicingAgent = { id: 'Servicing Agent', values: element.servicingagent };
      const ownerna = { id: 'Owner name', values: element.ownername };
      const ownergen = { id: 'Owner Gender', values: element.ownergender };
      const ownerDob = { id: 'Owner Dob', values: moment(element.ownerdob).format('DD-MM-YYYY') };
      const usper = { id: 'Us Person', values: element.usperson };
      const indob = { id: 'Insured Dob', values: moment(element.insureddob).format('DD-MM-YYYY') };
      const isage = { id: 'Issue Age', values: element.issueage };
      const insgen = { id: 'Insured Gender', values: element.insgender };
      const merge = [ServicingOffice, ServicingAgent, ownerna, ownergen, ownerDob, usper, indob, isage, insgen];

      merge.forEach(res => {
        const result = [res.id, res.values];
        policysecrowsarr.push(result);
      });

      // console.log(policysecrowsarr);

      // policysecrowsarr.push(merge);

      if (this.policytype === 'Non-UL') {
        doc1.autoTable(poliyseccolumnlist, policysecrowsarr, {
          theme: 'plain',
          // didParseCell: function(cell, data) {
          //   if (data.row.index === 0 || data.row.index === 2) {
          //     cell.styles.fontStyle = 'bold';
          //   }
          // },
          tableWidth: 95,
          startY: 35.5,
          showHead: 'firstPage',
          margin: { left: 105 },
          bodyStyles: { fillColor: 255, textColor: 36, valign: 'top', lineWidth: 0.3, lineColor: [225, 225, 225] },
          avoidPageSplit: true,
          headerStyles: { fillColor: 255, textColor: 36, halign: 'left', lineWidth: 0, lineColor: [225, 225, 225] },
          styles: { overflow: 'linebreak', overflowColumns: false, fontSize: 9, lineWidth: 0.1, lineColor: [225, 225, 225] },
          columnWidth: 'wrap',
          columnStyles: {
            0: { fontStyle: 'bold', columnWidth: 40 },
            1: { fillColor: 246, columnWidth: 55 }
          }

        });
      }
    });





    // Policy Information third row NON UL
    // const poliythirdcolumn = [
    //   { title: 'Insured Name', dataKey: 'insuredname' },
    //   { title: 'Insured Gender', dataKey: 'insgender' },
    //   { title: 'Insured DOB', dataKey: 'insureddob' },
    //   { title: 'Issue Age', dataKey: 'issueage' }
    // ];
    // const policythirdrownonul = this.detailslist;
    // const policythirdrowsarr = [];

    // policythirdrownonul.forEach( element => {
    //   if (element.insuredname === undefined || element.insuredname === null) {
    //     element.insuredname = ' ';
    //   }
    //   if (element.insgender === undefined || element.insgender === null) {
    //     element.insgender = ' ';
    //   }
    //   if (element.insureddob === undefined || element.insureddob === null) {
    //     element.insureddob = ' ';
    //   }
    //   if (element.issueage === undefined || element.issueage === null) {
    //     element.issueage = ' ';
    //   }

    //   const insuname = { 'insuredname': element.insuredname };
    //   const insgen = { 'insgender': element.insgender };
    //   const indob = { 'insureddob': moment(element.insureddob).format('DD-MM-YYYY') };
    //   const isage = { 'issueage': element.issueage };

    //   const merge = Object.assign( insuname, insgen, indob, isage);
    //   policythirdrowsarr.push(merge);
    //       if (this.policytype == 'Non-UL') {
    //         doc1.autoTable(poliythirdcolumn, policythirdrowsarr, {
    //           theme: 'plain',
    //           tableWidth: 'auto',
    //           margin: { top: 58, left: 5 },
    //           bodyStyles: { fillColor: 255, textColor: 36, valign: 'top', lineWidth: 0.3, lineColor: [225,225,225] },
    //           pagesplit: true,
    //           headerStyles: { fillColor: 244, textColor: 36, halign: 'left',  lineWidth: 0.1, lineColor: [225,225,225] },
    //           styles: { overflow: 'linebreak', overflowColumns: false, fontSize: 9, lineWidth: 0.1, lineColor: [225,225,225] },
    //           columnWidth: 'wrap',
    //           columnStyles: {
    //             // insuredname : { columnWidth: 18 },
    //            // insgender : { columnWidth : 12 },
    //            // issueage : { columnWidth : 12 }
    //           }

    //         });
    //  }

    // });







    // ************___________ Policy Information first UL Table_____________************//






    // doc1.setFillColor(217, 217, 217);
    // doc1.rect(5, 50, 190, 12, 'F');
    // doc1.text('Policy Information', 5, 55);


    const poliycolumnul = [
      { title: 'Policy Number', dataKey: 'PolicyNumber' },
      { title: 'Policy Effective Date', dataKey: 'PolicyeffDate' },
      { title: 'Policy Issue Date', dataKey: 'PolicyissDate' },
      { title: 'Status', dataKey: 'stats' },
      { title: 'Issue State', dataKey: 'IssueState' },
      { title: 'Policy Type', dataKey: 'PolicyType' },
      { title: 'Product Name', dataKey: 'ProductName' },
      { title: 'Risk Class', dataKey: 'RiskClass' }
    ];


    const colul = [
      { title: ' ' },
      { title: ' ' },
    ];

    const policyulrow = this.detailslist;
    const policyulrowsarr = [];

    // tslint:disable-next-line: no-shadowed-variable
    policyulrow.forEach(element => {

      if (element.policyNumber === undefined || element.policyNumber === null) {
        element.policyNumber = 'N/A';
      }
      if (element.policyeffectdate === undefined || element.policyeffectdate === null) {
        element.policyeffectdate = 'N/A';
      }
      if (element.policyissuedate === undefined || element.policyissuedate === null) {
        element.policyissuedate = 'N/A';
      }
      if (element.status === undefined || element.status === null) {
        element.status = 'N/A';
      }
      if (element.issuestate === undefined || element.issuestate === null) {
        element.issuestate = 'N/A';
      }
      if (element.policytype === undefined || element.policytype === null) {
        element.policytype = 'N/A';
      }
      if (element.prodname === undefined || element.prodname === null) {
        element.prodname = 'N/A';
      }
      if (element.riskclass === undefined || element.riskclass === null) {
        element.riskclass = 'N/A';
      }
      if (element.insgender === undefined || element.insgender === null) {
        element.insgender = 'N/A';
      }
      if (element.insureddob === undefined || element.insureddob === null) {
        element.insureddob = 'N/A';
      }
      if (element.issueage === undefined || element.issueage === null) {
        element.issueage = 'N/A';
      }


      const policynum = { id: 'Policy Number', values: element.policyNumber };
      const policyeffdat = { id: 'Policy Effective Date', values: moment(element.policyissuedate).format('DD-MM-YYYY') };
      const policyissdat = { id: 'Policy Issue Date', values: moment(element.policyissuedate).format('DD-MM-YYYY') };
      const stat = { id: 'Stats', values: element.status };
      const issuestate = { id: 'Issue State', values: element.issuestate };
      const policytype = { id: 'Policy Type', values: element.policytype };
      const prodname = { id: 'Product Name', values: element.prodname };
      const riskclas = { id: 'RiskClass', values: element.riskclass };
      const insgen = { id: 'Insured Gender', values: element.insgender };
      const indob = { id: 'Insured Dob', values: moment(element.insureddob).format('DD-MM-YYYY') };
      const isage = { id: 'Issue Age', values: element.issueage };
      const emptyrow = { id: '', values: '' };
      const merge = [policynum, policyeffdat, policyissdat, stat, issuestate, policytype, prodname, riskclas,
        insgen, indob, isage, emptyrow];

      merge.forEach(res => {
        const result = [res.id, res.values];
        policyulrowsarr.push(result);
      });


      if (this.policytype === 'UL') {
        doc1.autoTable(colul, policyulrowsarr, {
          theme: 'plain',
          tableWidth: 95,
          startY: 38.5,
          showHead: 'firstPage',
          margin: { left: 10 },
          bodyStyles: { fillColor: 255, textColor: 36, valign: 'top', lineWidth: 0.1, lineColor: [225, 225, 225] },
          avoidPageSplit: true,
          headerStyles: { fillColor: 255, textColor: 36, halign: 'left', lineWidth: 0, lineColor: [225, 225, 225] },
          styles: { overflow: 'linebreak', overflowColumns: false, fontSize: 9, lineWidth: 0.1, lineColor: [225, 225, 225] },
          columnWidth: 'wrap',
          columnStyles: {
            0: { fontStyle: 'bold', columnWidth: 40 },
            1: { fillColor: 246, columnWidth: 55 }
          }

        });
      }
    });


    // *******  ____________ Policy Information second UL Table _____________****//



    const poliyseculcolumn = [
      { title: 'Rated Policy', dataKey: 'RatedPolicy' },
      { title: 'Servicing Office', dataKey: 'ServicingOffice' },
      { title: 'Servicing Agent', dataKey: 'ServicingAgent' },
      { title: 'Owner Name', dataKey: 'ownername' },
      { title: 'Owner Gender', dataKey: 'ownergender' },
      { title: 'Owner DOB', dataKey: 'ownerdob' },
      { title: 'US Person', dataKey: 'usperson' },
      { title: 'Insured Name', dataKey: 'insuredname' }
    ];

    const colulsec = [
      { title: ' ' },
      { title: ' ' },
    ];

    const policyulrowsecul = this.detailslist;
    const policyseculrowsarr = [];

    // tslint:disable-next-line: no-shadowed-variable
    policyulrowsecul.forEach(element => {

      if (element.ratedpolicy === undefined || element.ratedpolicy === null) {
        element.ratedpolicy = 'N/A';
      }
      if (element.serviceoffice === undefined || element.serviceoffice === null) {
        element.serviceoffice = 'N/A';
      }
      if (element.servicingagent === undefined || element.servicingagent === null) {
        element.servicingagent = 'N/A';
      }
      if (element.ownername === undefined || element.ownername === null) {
        element.ownername = 'N/A';
      }
      if (element.ownergender === undefined || element.ownergender === null) {
        element.ownergender = 'N/A';
      }
      if (element.ownerdob === undefined || element.ownerdob === null) {
        element.ownerdob = 'N/A';
      }
      if (element.usperson === undefined || element.usperson === null) {
        element.usperson = 'N/A';
      }
      if (element.insuredname === undefined || element.insuredname === null) {
        element.insuredname = 'N/A';
      }

      if (element.joinedInsuredName === undefined || element.joinedInsuredName === null) {
        element.joinedInsuredName = 'N/A';
      }

      if (element.joinedgender === undefined || element.joinedgender === null) {
        element.joinedgender = 'N/A';
      }

      if (element.joinedidob === undefined || element.joinedidob === null) {
        element.joinedidob = 'N/A';
      }

      if (element.joinediiage === undefined || element.joinediiage === null) {
        element.joinediiage = 'N/A';
      }


      const ratepolicy = { id: 'Rated Policy', values: element.ratedpolicy };
      const ServicingOffice = { id: 'Servicing Office', values: element.serviceoffice };
      const ServicingAgent = { id: 'Servicing Agent', values: element.servicingagent };
      const ownerna = { id: 'Owner Name', values: element.ownername };
      const ownergen = { id: 'Owner Gender', values: element.ownergender };
      const ownerDob = { id: 'Owner Dob', values: moment(element.ownerdob).format('DD-MM-YYYY') };
      const usper = { id: 'Us Person', values: element.usperson };
      const insuname = { id: 'Insured Name', values: element.insuredname };
      const joininname = { id: 'Joined Insured Name', values: element.joinedInsuredName };
      const joingen = { id: 'Joined Insured Gender', values: element.joinedgender };
      const joindob = { id: 'Joined Insured Dob', values: moment(element.joinedidob).format('DD-MM-YYYY') };
      const joinage = { id: 'Joined Insured Issue Age', values: element.joinediiage };

      const merge = [ratepolicy, ServicingOffice, ServicingAgent, ownerna, ownergen, ownerDob, usper, insuname,
        joininname, joingen, joindob, joinage];

      merge.forEach(res => {
        const result = [res.id, res.values];
        policyseculrowsarr.push(result);
      });

      if (this.policytype === 'UL') {
        doc1.autoTable(colulsec, policyseculrowsarr, {
          theme: 'plain',
          tableWidth: 95,
          startY: 38.5,
          showHead: 'firstPage',
          margin: { left: 105 },
          bodyStyles: { fillColor: 255, textColor: 36, valign: 'top', lineWidth: 0.3, lineColor: [225, 225, 225] },
          avoidPageSplit: true,
          headerStyles: { fillColor: 255, textColor: 36, halign: 'left', lineWidth: 0, lineColor: [225, 225, 225] },
          styles: { overflow: 'linebreak', overflowColumns: false, fontSize: 9, lineWidth: 0.1, lineColor: [225, 225, 225] },
          columnWidth: 'wrap',
          columnStyles: {
            0: { fontStyle: 'bold', columnWidth: 40 },
            1: { fillColor: 246, columnWidth: 55 }
          }

        });
      }
    });




    //Policy Information third row UL

    // const poliythirdulcolumn = [
    //   { title: 'Insured Gender', dataKey: 'insgender' },
    //   { title: 'Insured DOB', dataKey: 'insureddob' },
    //   { title: 'Issue Age', dataKey: 'issueage' },
    //   { title: 'Joined Insured Name', dataKey: 'joininsnam' },
    //   { title: 'Joined Insured Gender', dataKey: 'joiningen' },
    //   { title: 'Joined Insured Date of Birth', dataKey: 'joinindob' },
    //   { title: 'Joined Insured Issue Age', dataKey: 'joininsissage' }
    // ];

    // const policyulrowthirdul = this.detailslist;
    // const policythirdulrowsarr = [];

    // policyulrowthirdul.forEach(element => {

    //   if (element.insgender === undefined || element.insgender === null) {
    //     element.insgender = ' ';
    //   }
    //   if (element.insureddob === undefined || element.insureddob === null) {
    //     element.insureddob = ' ';
    //   }
    //   if (element.issueage === undefined || element.issueage === null) {
    //     element.issueage = ' ';
    //   }
    //   if (element.joinedInsuredName === undefined || element.joinedInsuredName === null) {
    //     element.joinedInsuredName = ' ';
    //   }
    //   if (element.joinedgender === undefined || element.joinedgender === null) {
    //     element.joinedgender = ' ';
    //   }
    //   if (element.joinedidob === undefined || element.joinedidob === null) {
    //     element.joinedidob = ' ';
    //   }
    //   if (element.joinediiage === undefined || element.joinediiage === null) {
    //     element.joinediiage = ' ';
    //   }

    //   const insgen = { 'insgender': element.insgender };
    //   const indob = { 'insureddob': moment(element.insureddob).format('DD-MM-YYYY') };
    //   const isage = { 'issueage': element.issueage };
    //   const joininname = { 'joininsnam': element.joinedInsuredName };
    //   const joingen = { 'joiningen': element.joinedgender };
    //   const joindob = { 'joinindob': moment(element.joinedidob).format('DD-MM-YYYY') };
    //   const joinage = { 'joininsissage': element.joinediiage };
    //   const merge = Object.assign(insgen, indob, isage, joininname, joingen, joindob, joinage);
    //   policythirdulrowsarr.push(merge);
    //   if (this.policytype == 'UL') {
    //     doc1.autoTable(poliythirdulcolumn, policythirdulrowsarr, {
    //       theme: 'plain',
    //       tableWidth: 'auto',
    //       margin: { top: 58, left: 5 },
    //       bodyStyles: { fillColor: 255, textColor: 36, valign: 'top', lineWidth: 0.3, lineColor: [225,225,225] },
    //       pagesplit: true,
    //       headerStyles: { fillColor: 244, textColor: 36, halign: 'left',  lineWidth: 0.1, lineColor: [225,225,225] },
    //       styles: { overflow: 'linebreak', overflowColumns: false, fontSize: 9, lineWidth: 0.1, lineColor: [225,225,225] },
    //       columnWidth: 'wrap',
    //       columnStyles: {
    //       }

    //     });
    //   }

    // });






    // *****************________Plan Informatin Table________***************//

    const columns = [
      { title: 'Plan', dataKey: 'plan' },
      { title: 'Table Rating', dataKey: 'tableRating' },
      { title: 'Sum Assured', dataKey: 'sumAssured' },
      { title: 'Policy Date', dataKey: 'policyDate' },
      { title: 'Maturity Date', dataKey: 'maturityDate' },
      { title: 'Annual Coverage Premium', dataKey: 'annualCoveragePremium' },
      { title: 'Insured Gender', dataKey: 'insuredGender' },
      { title: 'Issue Age', dataKey: 'issueAge' }
    ];


    const row = this.inforiderdataSource;
    const rowsarr = [];

    // tslint:disable-next-line: no-shadowed-variable
    row.forEach(element => {
      if (element.Plan === undefined || element.Plan === null) {
        element.Plan = 'N/A';
      }
      if (element.TableRating === undefined || element.TableRating === null) {
        element.TableRating = 'N/A';
      }
      if (element.AnnualCoveragePremium === undefined || element.AnnualCoveragePremium === null) {
        element.AnnualCoveragePremium = 'N/A';
      }
      if (element.SumAssured === undefined || element.SumAssured === null) {
        element.SumAssured = 'N/A';
      }
      if (element.PolicyDate === undefined || element.PolicyDate === null) {
        element.PolicyDate = 'N/A';
      }
      if (element.MaturityDate === undefined || element.MaturityDate === null) {
        element.MaturityDate = 'N/A';
      }
      if (element.InsuredGender === undefined || element.InsuredGender === null) {
        element.InsuredGender = 'N/A';
      }
      if (element.IssueAge === undefined || element.IssueAge === null) {
        element.IssueAge = 'N/A';
      }


      const plan = { 'plan': element.Plan };
      const annual = { 'annualCoveragePremium': element.AnnualCoveragePremium };
      const tablerating = { 'tableRating': element.TableRating };
      const sumAssured = { 'sumAssured': element.SumAssured };
      const policyDate = { 'policyDate': moment(element.PolicyDate).format('DD-MM-YYYY') };
      const maturityDate = { 'maturityDate': element.MaturityDate };
      const insuredGender = { 'insuredGender': element.InsuredGender };
      const issueAge = { 'issueAge': element.IssueAge };

      const merge = Object.assign(plan, annual, tablerating, sumAssured, policyDate, maturityDate, insuredGender, issueAge);
      rowsarr.push(merge);
      console.log(rowsarr);
    });
    // doc1.setFillColor(217, 217, 217);
    // doc1.rect(5, doc1.autoTable.previous.finalY + 20, 191, 12, 'F');
    if (this.policytype === 'Non-UL') {
      doc1.text('Plan Information', 80, doc1.autoTable.previous.finalY + 25);
      doc1.autoTable(columns, rowsarr, {
        startY: doc1.autoTable.previous.finalY + 33,
        theme: 'plain',
        tableWidth: 'auto',
        margin: { top: 5, left: 10 },
        bodyStyles: { fillColor: 255, textColor: 36, valign: 'top', lineWidth: 0.3, lineColor: [225, 225, 225] },
        pagesplit: true,
        headerStyles: { fillColor: 247, textColor: 36, halign: 'left', lineWidth: 0.1, lineColor: [225, 225, 225] },
        styles: { overflow: 'linebreak', overflowColumns: false, fontSize: 9, lineWidth: 0.1, lineColor: [225, 225, 225] },
        columnWidth: 'wrap',
        columnStyles: {
          // policyDate: { columnWidth: 30 }
        }
      });
    }







    // ******************____________ coverage Information________________************//

    const coveragecolumn = [
      { title: 'Benifit Type', dataKey: 'beniftype' },
      { title: 'Sum Assured', dataKey: 'sumAss' },
      { title: 'Effective Date', dataKey: 'effdat' },
      { title: 'Annual Coverage Premium', dataKey: 'anncovpr' },
      { title: 'Issue Age', dataKey: 'issag' }
    ];

    const coveragerow = this.coveragedataSource;
    const coveragearr = [];
    console.log(coveragerow);
    coveragerow.forEach(elements => {
      if (elements.benefittype === undefined || elements.benefittype === null) {
        elements.benefittype = 'N/A';
      }
      if (elements.sumassured === undefined || elements.sumassured === null) {
        elements.sumassured = 'N/A';
      }
      if (elements.effectiveDate === undefined || elements.effectiveDate === null) {
        elements.effectiveDate = 'N/A';
      }
      if (elements.annualCovPremium === undefined || elements.annualCovPremium === null) {
        elements.annualCovPremium = 'N/A';
      }
      if (elements.issueAge === undefined || elements.issueAge === null) {
        elements.issueAge = 'N/A';
      }
      const benifiType = { 'beniftype': elements.benefittype };
      const sumasSured = { 'sumAss': elements.sumassured };
      const effdate = { 'effdat': moment(elements.effectiveDate).format('DD-MM-YYYY') };
      const anncovpre = { 'anncovpr': elements.annualCovPremium };
      const issuage = { 'issag': elements.issueAge };

      const merge = Object.assign(benifiType, sumasSured, effdate, anncovpre, issuage);
      coveragearr.push(merge);
    });
    if (this.policytype === 'UL') {
      doc1.text('Coverage Information', 80, doc1.autoTable.previous.finalY + 20);
      doc1.autoTable(coveragecolumn, coveragearr, {
        startY: doc1.autoTable.previous.finalY + 33,
        theme: 'plain',
        tableWidth: 'auto',
        margin: { top: 5, left: 10 },
        bodyStyles: { fillColor: 255, textColor: 36, valign: 'top', lineWidth: 0.3, lineColor: [225, 225, 225] },
        pagesplit: true,
        headerStyles: { fillColor: 247, textColor: 36, halign: 'left', lineWidth: 0.1, lineColor: [225, 225, 225] },
        styles: { overflow: 'linebreak', overflowColumns: false, fontSize: 9, lineWidth: 0.1, lineColor: [225, 225, 225] },
        columnWidth: 'wrap',
        columnStyles: {
          // policyDate: { columnWidth: 30 }
        }
      });
    }













    // **********________________ Financial Details UL first row ____________************* //



    const financialcolumn = [
      { title: 'Account Value', dataKey: 'accval' },
      { title: 'Surrender Value', dataKey: 'surrval' },
      { title: 'Surrender Charge', dataKey: 'surrchr' },
      { title: 'NonForfeiture Option', dataKey: 'nonopt' },
      { title: 'Monthly Deduction Amount', dataKey: 'mondetamt' },
      { title: 'Current Crediting Interest Rate', dataKey: 'curcrerat' },
      { title: 'Current Assumed Crediting Interest Rate', dataKey: 'currcrerat' }
    ];

    const financol = [
      { title: '' },
      { title: '' }
    ];

    const finanrow = this.detailslistfinance;
    const finanrowsarr = [];

    // tslint:disable-next-line: no-shadowed-variable
    finanrow.forEach(element => {
      if (element.accountValue === undefined || element.accountValue === null) {
        element.accountValue = 'N/A';
      }
      if (element.surrenderCharge === undefined || element.surrenderCharge === null) {
        element.surrenderCharge = 'N/A';
      }
      if (element.surrenderValue === undefined || element.surrenderValue === null) {
        element.surrenderValue = 'N/A';
      }
      if (element.monthlyDeductionAmount === undefined || element.monthlyDeductionAmount === null) {
        element.monthlyDeductionAmount = 'N/A';
      }
      if (element.currentCreditingInterestRate === undefined || element.currentCreditingInterestRate === null) {
        element.currentCreditingInterestRate = 'N/A';
      }
      if (element.currentAssuredCreditingInterestRate === undefined || element.currentAssuredCreditingInterestRate === null) {
        element.currentAssuredCreditingInterestRate = 'N/A';
      }
      if (element.nonForfeitureOption === undefined || element.nonForfeitureOption === null || element.nonForfeitureOption === '') {
        element.nonForfeitureOption = 'N/A';
      }
      const accvall = { id: 'Account Value', values: element.accountValue };
      const surrvall = { id: 'Surrender Value', values: element.surrenderValue };
      const surrchar = { id: 'Surrender Charge', values: element.surrenderCharge };
      const nonforopt = { id: 'NonForfeiture Option', values: element.nonForfeitureOption };
      const mondetamtt = { id: 'Monthly Deduction Amount', values: element.monthlyDeductionAmount };
      const currcrerate = { id: 'Current Crediting Interest Rate', values: element.currentCreditingInterestRate };
      const currassintrate = { id: 'Current Assumed Crediting Interest Rate', values: element.currentAssuredCreditingInterestRate };

      const merge = [accvall, surrvall, surrchar, nonforopt, mondetamtt, currcrerate, currassintrate];
      merge.forEach(res => {
        const result = [res.id, res.values];
        finanrowsarr.push(result);
      });

      if (this.policytype === 'UL') {
        doc1.text('Financial Information', 80, doc1.autoTable.previous.finalY + 20);
        doc1.autoTable(financol, finanrowsarr, {
          startY: doc1.autoTable.previous.finalY + 40,
          theme: 'plain',
          tableWidth: 95,
          showHead: 'SecondPage',
          margin: { left: 10 },
          bodyStyles: { fillColor: 255, textColor: 36, valign: 'top', lineWidth: 0.3, lineColor: [225, 225, 225] },
          pagesplit: true,
          headerStyles: { fillColor: 255, textColor: 36, halign: 'left', lineWidth: 0, lineColor: [225, 225, 225] },
          styles: { overflow: 'linebreak', overflowColumns: false, fontSize: 9, lineWidth: 0.1, lineColor: [225, 225, 225] },
          columnWidth: 'wrap',
          columnStyles: {
            0: { fontStyle: 'bold', columnWidth: 40 },
            1: { fillColor: 246, columnWidth: 55 }
          }
        });
      }
    });











    // Financial Details UL second row

    const financialulcolumn = [
      { title: 'Outstanding Loan Amount', dataKey: 'outloanamt' },
      { title: 'Maximum Available Loan Amount', dataKey: 'maxavaloanamt' },
      { title: 'Loan Interest Rate - Class A', dataKey: 'loanintratea' },
      { title: 'Loan Interest Rate - Class B', dataKey: 'loanintrateb' },
      { title: 'Total Withdrawals', dataKey: 'totalwithdraws' },
      { title: 'Withdrawals YTD', dataKey: 'withdrwalytd' }
    ];

    const finanuseclcol = [
      { title: '' },
      { title: '' }
    ];

    const finanulrow = this.detailslistfinance;
    const finanulrowsarr = [];
    // tslint:disable-next-line: no-shadowed-variable
    finanulrow.forEach(element => {
      if (element.outstandingLoanamount === undefined || element.outstandingLoanamount === null) {
        element.outstandingLoanamount = 'N/A';
      }
      if (element.maximumAvailableLoanAmount === undefined || element.maximumAvailableLoanAmount === null) {
        element.maximumAvailableLoanAmount = 'N/A';
      }
      if (element.loanInterestRateClassA === undefined || element.loanInterestRateClassA === null) {
        element.loanInterestRateClassA = 'N/A';
      }
      if (element.loanInterestRateClassB === undefined || element.loanInterestRateClassB === null) {
        element.loanInterestRateClassB = 'N/A';
      }
      if (element.totalWidthdrawal === undefined || element.totalWidthdrawal === null) {
        element.totalWidthdrawal = 'N/A';
      }
      if (element.widthdrawalYTD === undefined || element.widthdrawalYTD === null) {
        element.widthdrawalYTD = 'N/A';
      }
      const outloamt = { id: 'Outstanding Loan Amount', values: element.outstandingLoanamount };
      const MaxValoan = { id: 'Maximum Available Loan Amount', values: element.maximumAvailableLoanAmount };
      const LoanInRate = { id: 'Loan Interest Rate - Class A', values: element.loanInterestRateClassA };
      const LoanInrateb = { id: 'Loan Interest Rate - Class B', values: element.loanInterestRateClassB };
      const TotalwiDraws = { id: 'Total Withdrawals', values: element.totalWidthdrawal };
      const WidhDrawYtd = { id: 'Withdrawals YTD', values: element.widthdrawalYTD };
      const emptyrow = { id: '', values: '' };
      const merge = [outloamt, MaxValoan, LoanInRate, LoanInrateb,
        TotalwiDraws, WidhDrawYtd, emptyrow];

      merge.forEach(res => {
        const result = [res.id, res.values];
        finanulrowsarr.push(result);
      });


      if (this.policytype === 'UL') {
        doc1.autoTable(finanuseclcol, finanulrowsarr, {
          startY: doc1.autoTable.previous.finalY - 50.2,
          theme: 'plain',
          tableWidth: 95,
          showHead: 'SecondPage',
          margin: { left: 105 },
          bodyStyles: { fillColor: 255, textColor: 36, valign: 'top', lineWidth: 0.3, lineColor: [225, 225, 225] },
          pagesplit: true,
          headerStyles: { fillColor: 255, textColor: 36, halign: 'left', lineWidth: 0, lineColor: [225, 225, 225] },
          styles: { overflow: 'linebreak', overflowColumns: false, fontSize: 9, lineWidth: 0.1, lineColor: [225, 225, 225] },
          columnWidth: 'wrap',
          columnStyles: {
            0: { fontStyle: 'bold', columnWidth: 47 },
            1: { fillColor: 246, columnWidth: 48 }
          }
        });
      }
    });







    // ************____________ */ Financial Details NONUL first row *********________//




    const financialnonulcolumn = [
      { title: 'Cash Value', dataKey: 'cashval' },
      { title: 'Surrender Value', dataKey: 'surrval' },
      { title: 'Dividend Option', dataKey: 'divopt' },
      { title: 'NonForfeiture Option', dataKey: 'nonopt' },
    ];

    const colfinanonul = [
      { title: '' },
      { title: '' },
    ];

    const finannonulrow = this.detailslistfinance;
    const finannonulrowsarr = [];


    // tslint:disable-next-line: no-shadowed-variable

    finannonulrow.forEach(element => {
      if (this.cashValue === undefined || this.cashValue === null) {
        this.cashValue = 'N/A';
      }
      if (this.dividendOption === undefined || this.dividendOption === null) {
        this.dividendOption = 'N/A';
      }
      if (element.surrenderValue === undefined || element.surrenderValue === null) {
        element.surrenderValue = 'N/A';
      }
      if (element.nonForfeitureOption === undefined || element.nonForfeitureOption === null) {
        element.nonForfeitureOption = 'N/A';
      }
      const cashval = { id: 'Cash Value', values: this.cashValue };
      const divopt = { id: 'Dividend Option', values: this.dividendOption };
      const surrval = { id: 'Surrender Value', values: element.surrenderValue };
      const nonforopt = { id: 'Non Forniture Option', values: element.nonForfeitureOption };

      const merge = [cashval, divopt, surrval, nonforopt];

      merge.forEach(res => {
        const result = [res.id, res.values];
        finannonulrowsarr.push(result);
      });

      if (this.policytype === 'Non-UL') {

        // doc1.setFillColor(217, 217, 217);
        // doc1.rect(5, doc1.autoTable.previous.finalY + 15, 191, 12, 'F');
        doc1.text('Financial Information', 80, doc1.autoTable.previous.finalY + 22);



        doc1.autoTable(colfinanonul, finannonulrowsarr, {
          startY: doc1.autoTable.previous.finalY + 28,
          theme: 'plain',
          tableWidth: 95,
          showHead: 'secondPage',
          margin: { left: 10 },
          bodyStyles: { fillColor: 255, textColor: 36, valign: 'top', lineWidth: 0.3, lineColor: [225, 225, 225] },
          pagesplit: true,
          headerStyles: { fillColor: 255, textColor: 36, halign: 'left', lineWidth: 0, lineColor: [225, 225, 225] },
          styles: { overflow: 'linebreak', overflowColumns: false, fontSize: 9, lineWidth: 0.1, lineColor: [225, 225, 225] },
          columnWidth: 'wrap',
          columnStyles: {
            0: { fontStyle: 'bold', columnWidth: 47 },
            1: { fillColor: 246, columnWidth: 48 }
          }
        });
      }
    });





    // **************___________ Financial Details NONUL second row***********//


    const financialnonulseccolumn = [
      { title: 'Outstanding Loan Amt', dataKey: 'outloanamt' },
      { title: 'Maximum Available Loan Amt', dataKey: 'maxavaloanamt' },
      { title: 'Premium Deposit Fund', dataKey: 'loanintratea' },
      { title: 'Loan Interest Rate', dataKey: 'loanintrarate' }
    ];

    const finanonulcol = [
      { title: '' },
      { title: '' },
    ];

    const finannonulsecrow = this.detailslistfinance;
    const finannonulsecrowsarr = [];
    // tslint:disable-next-line: no-shadowed-variable
    finannonulsecrow.forEach(element => {
      console.log(element);
      if (element.outstandingLoanamount === undefined || element.outstandingLoanamount === null) {
        element.outstandingLoanamount = 'N/A';
      }
      if (element.maximumAvailableLoanAmount === undefined || element.maximumAvailableLoanAmount === null) {
        element.maximumAvailableLoanAmount = 'N/A';
      }
      if (this.deposit === undefined || this.deposit === null) {
        this.deposit = 'N/A';
      }
      if (element.Interest_Rate === undefined || element.Interest_Rate === null) {
        element.Interest_Rate = 'N/A';
      }
      const outloamt = { id: 'Outstanding Loan Amt', values: element.outstandingLoanamount };
      const MaxValoan = { id: 'Maximum Available Loan Amt', values: element.maximumAvailableLoanAmount };
      const LoanInRate = { id: 'Loan Interest Rate - Class A', values: this.deposit };
      const LoanInrateb = { id: 'Loan Interest Rate - Class B', values: element.Interest_Rate };

      const merge = [outloamt, MaxValoan, LoanInRate, LoanInrateb];

      merge.forEach(res => {
        const result = [res.id, res.values];
        finannonulsecrowsarr.push(result);
      });

      if (this.policytype === 'Non-UL') {
        doc1.autoTable(finanonulcol, finannonulsecrowsarr, {
          startY: doc1.autoTable.previous.finalY - 28.7,
          theme: 'plain',
          tableWidth: 95,
          showHead: 'secondPage',
          margin: { left: 105 },
          bodyStyles: { fillColor: 255, textColor: 36, valign: 'top', lineWidth: 0.3, lineColor: [225, 225, 225] },
          pagesplit: true,
          headerStyles: { fillColor: 255, textColor: 36, halign: 'left', lineWidth: 0, lineColor: [225, 225, 225] },
          styles: { overflow: 'linebreak', overflowColumns: false, fontSize: 9, lineWidth: 0.1, lineColor: [225, 225, 225] },
          columnWidth: 'wrap',
          columnStyles: {
            0: { fontStyle: 'bold', columnWidth: 50 },
            1: { fillColor: 246, columnWidth: 45 }
          }
        });
      }
    });










    // ***************________________ Premium BIlling ul_____________**************//

    const premiumbillcolumn = [
      { title: 'Original Required Annual Premium Amount', dataKey: 'orgreqamt' },
      { title: 'Current Required Annual Premium Amount', dataKey: 'currannpreamt' },
      { title: 'Required Annual Premium Preiod', dataKey: 'currcrerat' },
      { title: 'Last Premium Payment Date', dataKey: 'lastpaydat' },
      { title: 'Last Premium Effective Date', dataKey: 'lasteffdat' },
      { title: 'Last Premium Payment Amt', dataKey: 'lastpredat' },
      { title: 'Total Premium Deposits', dataKey: 'totpredep' },
      { title: 'Premium Deposit YTD', dataKey: 'predepytd' }
    ];

    const prembillulcol = [
      { title: '' },
      { title: '' }
    ];

    const prebillrow = this.detailslistpremium;
    const prebillrowsarr = [];

    // tslint:disable-next-line: no-shadowed-variable
    prebillrow.forEach(element => {
      if (element.originalRequiredAnnualPremiumAmount === undefined || element.originalRequiredAnnualPremiumAmount === null) {
        element.originalRequiredAnnualPremiumAmount = 'N/A';
      }
      if (element.currentRequiredAnnualPremiumAmount === undefined || element.currentRequiredAnnualPremiumAmount === null) {
        element.currentRequiredAnnualPremiumAmount = 'N/A';
      }
      if (element.requiredAnnualPremiumPreiod === undefined || element.requiredAnnualPremiumPreiod === null) {
        element.requiredAnnualPremiumPreiod = 'N/A';
      }
      if (element.lastPremiumPaymentDate === undefined || element.lastPremiumPaymentDate === null) {
        element.lastPremiumPaymentDate = 'N/A';
      }
      if (element.lastPremiumEffectiveDate === undefined || element.lastPremiumEffectiveDate === null) {
        element.lastPremiumEffectiveDate = 'N/A';
      }
      if (element.lastPremiumPaymentAmount === undefined || element.lastPremiumPaymentAmount === null) {
        element.lastPremiumPaymentAmount = 'N/A';
      }
      if (element.totalPremiumDeposits === undefined || element.totalPremiumDeposits === null) {
        element.totalPremiumDeposits = 'N/A';
      }
      if (element.premiumDepositYTD === undefined || element.premiumDepositYTD === null) {
        element.premiumDepositYTD = 'N/A';
      }


      console.log(element.lastPremiumPaymentDate);

      const orgreqamtt = { id: 'Original Required Annual Premium Amount', values: element.originalRequiredAnnualPremiumAmount };
      const currannpreamtt = { id: 'Current Required Annual Premium Amount', values: element.currentRequiredAnnualPremiumAmount };
      const currcreratt = { id: 'Required Annual Premium Preiod', values: element.requiredAnnualPremiumPreiod };
      const lastpaydatt = { id: 'Last Premium Payment Date', 
      values: moment(element.lastPremiumPaymentDate).format('DD-MM-YYYY') };
      const lasteffdatt = { id: 'Last Premium Effective Date', 
      values: moment(element.lastPremiumEffectiveDate).format('DD-MM-YYYY') };
      const lastpredatt = { id: 'Last Premium Payment Amt', values: element.lastPremiumPaymentAmount };
      const totpredept = { id: 'Total Premium Deposits', values: element.totalPremiumDeposits };
      const predepytdt = { id: 'Premium Deposit YTD', values: element.premiumDepositYTD };
      const merge = [orgreqamtt, currannpreamtt, currcreratt, lastpaydatt, lastpredatt,
        lasteffdatt, totpredept, predepytdt];

      merge.forEach(res => {
        const result = [res.id, res.values];
        prebillrowsarr.push(result);
      });


      if (this.policytype === 'UL') {
        doc1.text('Premium Billing', 80, doc1.autoTable.previous.finalY + 50);
        doc1.autoTable(prembillulcol, prebillrowsarr, {
          startY: doc1.autoTable.previous.finalY + 60,
          theme: 'plain',
          tableWidth: 95,
          showHead: 'thirdPage',
          margin: { left: 10 },
          bodyStyles: { fillColor: 255, textColor: 36, valign: 'top', lineWidth: 0.3, lineColor: [225, 225, 225] },
          pagesplit: true,
          headerStyles: { fillColor: 255, textColor: 36, halign: 'left', lineWidth: 0, lineColor: [225, 225, 225] },
          styles: { overflow: 'linebreak', overflowColumns: false, fontSize: 9, lineWidth: 0.1, lineColor: [225, 225, 225] },
          columnWidth: 'wrap',
          columnStyles: {
            0: { fontStyle: 'bold'},
            1: { fillColor: 246 }
          }
        });
      }
    });



    // *****************__________ premium billing ul __________***************//

    const premiumbillnonulcolumn = [
      { title: 'Payment Frequency', dataKey: 'patfreq' },
      { title: 'Payment Method', dataKey: 'paymethod' },
      { title: 'Bank Number', dataKey: 'banknum' },
      { title: 'Account Number', dataKey: 'accnum' },
      { title: 'Account Holder Name', dataKey: 'accholname' },
      { title: 'Modal Premium Amount', dataKey: 'modalpreamt' },
      { title: 'Planned Premium Payment Term', dataKey: 'planprepayterm' }
    ];

    const prebillulcol = [
      { title: '' },
      { title: '' }
    ];

    const prebillnonulrow = this.detailslistpremium;
    const prebillnonrowsarr = [];

    prebillnonulrow.forEach(ele => {
      if (ele.paymentFrequency === undefined || ele.paymentFrequency === null) {
        ele.paymentFrequency = 'N/A';
      }
      if (ele.PaymentMethod === undefined || ele.PaymentMethod === null) {
        ele.PaymentMethod = 'N/A';
      }
      if (ele.bankNumber === undefined || ele.bankNumber === null) {
        ele.bankNumber = 'N/A';
      }
      if (ele.accountNumber === undefined || ele.accountNumber === null) {
        ele.accountNumber = 'N/A';
      }
      if (ele.accountHolderName === undefined || ele.accountHolderName === null) {
        ele.accountHolderName = 'N/A';
      }
      if (ele.modalPremiumAmount === undefined || ele.modalPremiumAmount === null) {
        ele.modalPremiumAmount = 'N/A';
      }
      if (ele.plannedPremiumPaymentTerm === undefined || ele.plannedPremiumPaymentTerm === null) {
        ele.plannedPremiumPaymentTerm = 'N/A';
      }

      const patfreqq = { id: 'Payment Frequency', values: ele.paymentFrequency };
      const paymethodq = { id: 'Payment Method', values: ele.PaymentMethod };
      const banknumq = { id: 'Bank Number', values: ele.bankNumber };
      const accnumq = { id: 'Account Number', values: ele.accountNumber };
      const accholnameq = { id: 'Account Holder Name', values: ele.accountHolderName };
      const modalpreamtq = { id: 'Modal Premium Amount', values: ele.modalPremiumAmount };
      const planprepaytermq = { id: 'Planned Premium Payment Term', values: ele.plannedPremiumPaymentTerm };
      const emptyrow = { id: '', values: '' };
      const merge = [patfreqq, paymethodq, banknumq, accnumq, accholnameq, modalpreamtq, planprepaytermq, emptyrow];

      merge.forEach(res => {
        const result = [res.id, res.values];
        prebillnonrowsarr.push(result);
      });

      if (this.policytype === 'UL') {
        doc1.autoTable(prebillulcol, prebillnonrowsarr, {
          startY: doc1.autoTable.previous.finalY - 57.4,
          theme: 'plain',
          tableWidth: 95,
          showHead: 'thirdPage',
          margin: { left: 105 },
          bodyStyles: { fillColor: 255, textColor: 36, valign: 'top', lineWidth: 0.3, lineColor: [225, 225, 225] },
          pagesplit: true,
          headerStyles: { fillColor: 255, textColor: 36, halign: 'left', lineWidth: 0, lineColor: [225, 225, 225] },
          styles: { overflow: 'linebreak', overflowColumns: false, fontSize: 9, lineWidth: 0.1, lineColor: [225, 225, 225] },
          columnWidth: 'wrap',
          columnStyles: {
            0: { fontStyle: 'bold' },
            1: { fillColor: 246 }
          }
        });
      }
    });





    // *******************___________________premium billing Non_ul_Table________________****************** //

    const premiumbillnulcolumn = [
      { title: 'Modal Premium Amount', dataKey: 'modalpreamt' },
      { title: 'Annual Premium', dataKey: 'annpre' },
      { title: 'Last Premium Payment Date', dataKey: 'lastpaydat' },
      { title: 'Last Premium Payment Amt', dataKey: 'lastpredat' }
    ];


    const premiumbillnulcol = [
      { title: '' },
      { title: '' }
    ];

    const prebillnonrow = this.detailslistpremium;
    const prebillnonarr = [];

    prebillnonrow.forEach(res => {
      if (res.modalPremiumAmount === undefined || res.modalPremiumAmount === null) {
        res.modalPremiumAmount = 'N/A';
      }

      if (res.annualPremiumNext === undefined || res.annualPremiumNext === null) {
        res.annualPremiumNext = 'N/A';
      }

      if (res.lastPremiumPaymentDate === undefined || res.lastPremiumPaymentDate === null) {
        res.lastPremiumPaymentDate = 'N/A';
      }

      if (res.lastPremiumPaymentAmount === undefined || res.lastPremiumPaymentAmount === null) {
        res.lastPremiumPaymentAmount = 'N/A';
      }



      const modalpreamta = { id: 'Modal Premium Amount', values: res.modalPremiumAmount };
      const annprea = { id: 'Annual Premium', values: res.annualPremiumNext };
      const lastpaydata = { id: 'Last Premium Payment Date', values: moment(res.lastPremiumPaymentDate).format('DD-MM-YYYY') };
      const lastpredata = { id: 'Last Premium Payment Amt', values: res.lastPremiumPaymentAmount };


      const merge = [modalpreamta, annprea, lastpaydata, lastpredata];

      merge.forEach(response => {
        const result = [response.id, response.values];
        prebillnonarr.push(result);
      });

      if (this.policytype === 'Non-UL') {

        // doc1.setFillColor(217, 217, 217);
        // doc1.rect(5, doc1.autoTable.previous.finalY + 15, 191, 12, 'F');
        doc1.text('Premium Billing', 80, doc1.autoTable.previous.finalY + 22);

        doc1.autoTable(premiumbillnulcol, prebillnonarr, {
          startY: doc1.autoTable.previous.finalY + 28,
          theme: 'plain',
          tableWidth: 95,
          showHead: 'ThirdPage',
          margin: { left: 10 },
          bodyStyles: { fillColor: 255, textColor: 36, valign: 'top', lineWidth: 0.3, lineColor: [225, 225, 225] },
          pagesplit: true,
          headerStyles: { fillColor: 255, textColor: 36, halign: 'left', lineWidth: 0, lineColor: [225, 225, 225] },
          styles: { overflow: 'linebreak', overflowColumns: false, fontSize: 9, lineWidth: 0.1, lineColor: [225, 225, 225] },
          columnWidth: 'wrap',
          columnStyles: {
            0: { fontStyle: 'bold', columnWidth: 46, },
            1: { fillColor: 246, columnWidth: 48  }
          }
        });
      }
    });


    // ***********************_________________Premium billing non_ul table******************______________________//


    const premiumbillnulseccol = [
      { title: '' },
      { title: '' }
    ];

    const prebillnonsecrow = this.detailslistpremium;
    const prebillnonsecarr = [];

    prebillnonsecrow.forEach(res => {
      if (res.paidToDate === undefined || res.paidToDate === null) {
        res.paidToDate = 'N/A';
      }

      if (res.paymentFrequency === undefined || res.paymentFrequency === null) {
        res.paymentFrequency = 'N/A';
      }

      if (res.PaymentMethod === undefined || res.PaymentMethod === null) {
        res.PaymentMethod = 'N/A';
      }

      if (res.accountNumber === undefined || res.accountNumber === null) {
        res.accountNumber = 'N/A';
      }


      const paiddata = { id: 'Paid To Date', values: moment(res.paidToDate).format('DD-MM-YYYY') };
      const patfreqa = { id: 'Payment Frequency', values: res.paymentFrequency };
      const paymethoda = { id: 'Payment Method', values: res.PaymentMethod };
      const accnumta = { id: 'Account Number', values: res.accountNumber };

      const merge = [paiddata, patfreqa, paymethoda, accnumta];

      merge.forEach(response => {
        const result = [response.id, response.values];
        prebillnonsecarr.push(result);
      });

      if (this.policytype === 'Non-UL') {

        // doc1.setFillColor(217, 217, 217);
        // doc1.rect(5, doc1.autoTable.previous.finalY + 15, 191, 12, 'F');
        doc1.autoTable(premiumbillnulseccol, prebillnonsecarr, {
          startY: doc1.autoTable.previous.finalY - 28.7,
          theme: 'plain',
          tableWidth: 95,
          showHead: 'ThirdPage',
          margin: { left: 105 },
          bodyStyles: { fillColor: 255, textColor: 36, valign: 'top', lineWidth: 0.3, lineColor: [225, 225, 225] },
          pagesplit: true,
          headerStyles: { fillColor: 255, textColor: 36, halign: 'left', lineWidth: 0, lineColor: [225, 225, 225] },
          styles: { overflow: 'linebreak', overflowColumns: false, fontSize: 9, lineWidth: 0.1, lineColor: [225, 225, 225] },
          columnWidth: 'wrap',
          columnStyles: {
            0: { fontStyle: 'bold', columnWidth : 46},
            1: { fillColor: 246, columnWidth: 48}
          }
        });
      }
    });











    // relation section

    const relationcolumn = [
      { title: 'Owner', dataKey: 'own' },
      { title: 'Insured', dataKey: 'insu' },
      { title: 'Joint Insured', dataKey: 'joinins' }
    ];


    const relationulrow = this.detailslist;
    const relationularrrows = [];


    relationulrow.forEach(data => {
      if (data.ownername === undefined || data.ownername === null) {
        data.ownername = 'N/A';
      }
      if (data.insuredname === undefined || data.insuredname === null) {
        data.insuredname = 'N/A';
      }
      if (data.joininsuredname === undefined || data.joininsuredname === null) {
        data.joininsuredname = 'N/A';
      }
      const own = { 'own': data.ownername };
      const insu = { 'insu': data.insuredname };
      const joinins = { 'joinins': data.joininsuredname };
      const merge = Object.assign(own, insu, joinins);
      relationularrrows.push(merge);
    });


    // doc1.setFillColor(217, 217, 217);
    // doc1.rect(5, doc1.autoTable.previous.finalY + 15, 191, 12, 'F');
    doc1.text('Relationships', 80, doc1.autoTable.previous.finalY + 22);
    doc1.autoTable(relationcolumn, relationularrrows, {
      startY: doc1.autoTable.previous.finalY + 28,
      theme: 'plain',
      tableWidth: 'auto',
      margin: { top: 5, left: 10 },
      bodyStyles: { fillColor: 255, textColor: 36, valign: 'top', lineWidth: 0.3, lineColor: [225, 225, 225] },
      pagesplit: true,
      headerStyles: { fillColor: 247, textColor: 36, halign: 'left', lineWidth: 0.1, lineColor: [225, 225, 225] },
      styles: { overflow: 'linebreak', overflowColumns: false, fontSize: 9, lineWidth: 0.1, lineColor: [225, 225, 225] },
      columnWidth: 'wrap',
      columnStyles: {
        accval: { columnWidth: 25 },
        cashval: { columnWidth: 25 },
        surrval: { columnWidth: 25 },
      }
    });


    const relationcolumn1 = [
      { title: 'Assignee', dataKey: 'ass' },
      { title: 'Payor', dataKey: 'pay' },
      { title: 'Beneficiary (ies)', dataKey: 'benies' }
    ];

    const relationulrow1 = this.detailslistreltionship;
    const relationularrrows1 = [];

    relationulrow1.forEach(datares => {
      console.log(datares);
      if (datares.assignee === undefined || datares.assignee === null) {
        datares.assignee = 'N/A';
      }
      if (datares.relationshipPayorName === undefined || datares.relationshipPayorName === null) {
        datares.relationshipPayorName = 'N/A';
      }
      if (datares.benificaryCount === undefined || datares.benificaryCount === null) {
        datares.benificaryCount = 'N/A';
      }
      const ass = { 'ass': datares.assignee };
      const pay = { 'pay': datares.relationshipPayorName };
      const benies = { 'benies': datares.benificaryCount };
      const merge = Object.assign(ass, pay, benies);
      relationularrrows1.push(merge);

      if (this.policytype === 'UL') {

        doc1.autoTable(relationcolumn1, relationularrrows1, {
          theme: 'plain',
          tableWidth: 'auto',
          margin: { top: 5, left: 10 },
          bodyStyles: { fillColor: 255, textColor: 36, valign: 'top', lineWidth: 0.3, lineColor: [225, 225, 225] },
          pagesplit: true,
          headerStyles: { fillColor: 247, textColor: 36, halign: 'left', lineWidth: 0.1, lineColor: [225, 225, 225] },
          styles: { overflow: 'linebreak', overflowColumns: false, fontSize: 9, lineWidth: 0.1, lineColor: [225, 225, 225] },
          columnWidth: 'wrap',
          columnStyles: {

          }
        });
      }
    });


    const relationcolumn2 = [
      { title: 'Beneficiary Name', dataKey: 'NaMe' },
      { title: 'Relationship', dataKey: 'RelaTionShip' },
      { title: 'Percentage', dataKey: 'PercenTage' }
    ];

    const relationultable = this.befeficiarysdataSource;
    const relationularrrows2 = [];

    relationultable.forEach(res => {
      if (res.Name === undefined || res.Name === null) {
        res.Name = 'N/A';
      }
      if (res.Relationship === undefined || res.Relationship === null) {
        res.Relationship = 'N/A';
      }
      if (res.percentage === undefined || res.percentage === null) {
        res.percentage = 'N/A';
      }
      const NaMe = { 'NaMe': res.Name };
      const RelaTionShip = { 'RelaTionShip': res.Relationship };
      const PercenTage = { 'PercenTage': res.percentage };
      const merge = Object.assign(NaMe, RelaTionShip, PercenTage);
      relationularrrows2.push(merge);
    });

    doc1.autoTable(relationcolumn2, relationularrrows2, {
      theme: 'plain',
      tableWidth: 'auto',
      margin: { top: 5, left: 10 },
      bodyStyles: { fillColor: 255, textColor: 36, valign: 'top', lineWidth: 0.3, lineColor: [225, 225, 225] },
      pagesplit: true,
      headerStyles: { fillColor: 247, textColor: 36, halign: 'left', lineWidth: 0.1, lineColor: [225, 225, 225] },
      styles: { overflow: 'linebreak', overflowColumns: false, fontSize: 9, lineWidth: 0.1, lineColor: [225, 225, 225] },
      columnWidth: 'wrap',
      columnStyles: {
      }
    });


    // relationship nonul



    const relationcolumnnonul = [
      { title: 'Assignee', dataKey: 'ass' },
      { title: 'Payor', dataKey: 'pay' }
    ];

    const relationulrownonul = this.detailslistreltionship;
    const relationularrrowsnonul = [];

    relationulrownonul.forEach(datares => {
      console.log(datares);
      if (datares.assignee === undefined || datares.assignee === null) {
        datares.assignee = 'N/A';
      }
      if (datares.relationshipPayorName === undefined || datares.relationshipPayorName === null) {
        datares.relationshipPayorName = 'N/A';
      }

      const ass = { 'ass': datares.assignee };
      const pay = { 'pay': datares.relationshipPayorName };
      const merge = Object.assign(ass, pay);
      relationularrrowsnonul.push(merge);
      if (this.policytype === 'Non-UL') {
        // doc1.rect(5, doc1.autoTable.previous.finalY + 15, 191, 12, 'F');
        doc1.text('Relationships', 80, doc1.autoTable.previous.finalY + 22);
        // doc1.text('RelationShip', 5, doc1.autoTable.previous.finalY + 9);
        doc1.autoTable(relationcolumnnonul, relationularrrowsnonul, {
          startY: doc1.autoTable.previous.finalY + 28,
          theme: 'plain',
          tableWidth: 'auto',
          margin: { top: 5, left: 10 },
          bodyStyles: { fillColor: 255, textColor: 36, valign: 'top', lineWidth: 0.3, lineColor: [225, 225, 225] },
          pagesplit: true,
          headerStyles: { fillColor: 247, textColor: 36, halign: 'left', lineWidth: 0.1, lineColor: [225, 225, 225] },
          styles: { overflow: 'linebreak', overflowColumns: false, fontSize: 9, lineWidth: 0.1, lineColor: [225, 225, 225] },
          columnWidth: 'wrap',
          columnStyles: {
          }
        });
      }
    });




    // Address
    const addresscolumn = [
      { title: 'Roles', dataKey: 'RoLes' },
      { title: 'Name', dataKey: 'NaMe' },
      { title: 'Correspondence Address', dataKey: 'CorAdd' },
      { title: 'Contact Number', dataKey: 'ConNum' },
      { title: 'Email', dataKey: 'EmAil' }
    ];

    const addressrow = this.addressdataSource;
    const addressarr = [];

    addressrow.forEach(res => {
      if (res.roles === undefined || res.roles === null) {
        res.roles = 'N/A';
      }
      if (res.name === undefined || res.name === null) {
        res.name = 'N/A';
      }
      if (res.CorrespondenceAddress === undefined || res.CorrespondenceAddress === null) {
        res.CorrespondenceAddress = 'N/A';
      }
      if (res.ContactNumber === undefined || res.ContactNumber === null) {
        res.ContactNumber = 'N/A';
      }
      if (res.email === undefined || res.email === null) {
        res.email = 'N/A';
      }
      const RoLes = { 'RoLes': res.roles };
      const NaMe = { 'NaMe': res.name };
      const CorAdd = { 'CorAdd': res.CorrespondenceAddress };
      const ConNum = { 'ConNum': res.ContactNumber };
      const EmAil = { 'EmAil': res.email };
      const merge = Object.assign(RoLes, NaMe, CorAdd, ConNum, EmAil);
      addressarr.push(merge);
    });
    // doc1.setFillColor(217, 217, 217);
    // doc1.rect(5, doc1.autoTable.previous.finalY + 15, 191, 12, 'F');
    doc1.text('Address', 80, doc1.autoTable.previous.finalY + 22);
    doc1.autoTable(addresscolumn, addressarr, {
      startY: doc1.autoTable.previous.finalY + 28,
      theme: 'plain',
      tableWidth: 'auto',
      margin: { top: 5, left: 10 },
      bodyStyles: { fillColor: 255, textColor: 36, valign: 'top', lineWidth: 0.3, lineColor: [225, 225, 225] },
      pagesplit: true,
      headerStyles: { fillColor: 247, textColor: 36, halign: 'left', lineWidth: 0.1, lineColor: [225, 225, 225] },
      styles: { overflow: 'linebreak', overflowColumns: false, fontSize: 9, lineWidth: 0.1, lineColor: [225, 225, 225] },
      columnWidth: 'wrap',
      columnStyles: {
        RoLes: { columnWidth: 13 },
        NaMe: { columnWidth: 28 },
        CorAdd: { columnWidth: 10 },
        ConNum: { columnWidth: 20 },
        EmAil: { columnWidth: 40 },
      }
    });

    const detailsList = JSON.parse(localStorage.getItem('policyDetails'));
    if (detailsList[0].issuestate === 'HK') {
      this.email = 'customerservicehk@transamerica.com';
      this.phonenum = '(852) 2506 0311';
    } else if (detailsList[0].issuestate === 'SG') {
      this.email = 'customerservicesg@transamerica.com';
      this.phonenum = '(65) 6212 0620';
    } else if (detailsList[0].issuestate === 'BM') {
      this.email = 'customerservicebm@transamerica.com';
      this.phonenum = '(441) 278 8557';
    }

    const pageHeight = doc1.internal.pageSize.height || doc1.internal.pageSize.getHeight();
    const pageWidth = doc1.internal.pageSize.width || doc1.internal.pageSize.getWidth();

    const myFooter = doc1.splitTextToSize(`IMPORTANT NOTE:` + `The data presented on this site may not be relied upon to verify` +
      // tslint:disable-next-line: max-line-length
      `the status of or benefits payable under any policy. Please contact our Customer Services Team (by phone at ` + this.phonenum + ` or by e-mail at ` + this.email + `) ` +
      `for information relating to this policy`, 245);
    for (let i = 1; i < total_pdf_pages.length; i++) {
      doc1.setPage(i);
      doc1.setFontSize(9);
      doc1.setTextColor(111, 111, 111);
      const st = 'Page' + '-' + i;
      doc1.setFontSize(9.5);
      doc1.text(198, 282, st);
      if (i === total_pdf_pages.length - 1) {
        // doc1.setFillColor(231, 233, 234);
        // doc1.rect(0, 280, 320, 18, 'F');
        doc1.text(pageWidth / 2, pageHeight - 10, myFooter, 'center');
      }
    }
    doc1.save('Policy_Summary_' + this.policynumber + '.pdf');
  }

  arrPush(arr: any[]) {
    arr.push(arr[arr.length - 1]);
  }

  arrPop(arr: any[]) {
    arr.pop();
  }

}
