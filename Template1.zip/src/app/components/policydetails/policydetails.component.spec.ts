import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PolicydetailsComponent } from './policydetails.component';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule } from '@angular/forms';
import { AppConstants } from '@app/app.constants';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('PolicydetailsComponent', () => {
  let component: PolicydetailsComponent;
  let fixture: ComponentFixture<PolicydetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PolicydetailsComponent ],
      imports: [ BrowserDynamicTestingModule, RouterTestingModule, BrowserAnimationsModule,
        FormsModule, HttpClientTestingModule],
      providers: [AppConstants],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PolicydetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
