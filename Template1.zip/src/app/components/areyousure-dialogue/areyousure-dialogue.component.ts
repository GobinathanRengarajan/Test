import { AppConstants } from './../../app.constants';
import { DialogData } from './../../modules/dashboard/new-business/nbfilter-dialog/nbfilter-dialog.component';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { CustomPackageComponent } from './../../modules/dashboard/forms/formslanding/custom-package/custom-package.component';
import { Component, OnInit, Inject, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-areyousure-dialogue',
  templateUrl: './areyousure-dialogue.component.html',
  styleUrls: ['./areyousure-dialogue.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class AreyousureDialogueComponent implements OnInit {

  confirmationText: any;
  confirmationResult = true;

  alertIcon = this.app.alertIcon;
  closeIcon = this.app.close_model;

  constructor(
    public dialogRef: MatDialogRef<CustomPackageComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData,
    private app: AppConstants
  ) { }

  ngOnInit() { }

  onNoClick(): void {
    this.dialogRef.close();
  }

}
