import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AreyousureDialogueComponent } from './areyousure-dialogue.component';

describe('AreyousureDialogueComponent', () => {
  let component: AreyousureDialogueComponent;
  let fixture: ComponentFixture<AreyousureDialogueComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AreyousureDialogueComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AreyousureDialogueComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
