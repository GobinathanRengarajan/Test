import { Component, OnInit, ViewEncapsulation, Input } from '@angular/core';
import { AppConstants } from '@app/app.constants';
import { ProductService } from '@app/core/services/product/product.service';
import { Router, ActivatedRoute } from '@angular/router';
import { LaserficheService } from '@app/core/services/laserfiche/laserfiche.service';
import { parse } from 'url';

@Component({
  selector: 'app-productdetail',
  templateUrl: './productdetail.component.html',
  styleUrls: ['./productdetail.component.scss'],
  encapsulation: ViewEncapsulation.None,
  providers: [ProductService]
})
export class ProductdetailComponent implements OnInit {

  SubProduct_ID: string;
  prdetailslist: any = [];
  relatedLinks: any = [];
  insurer: string;
  Policy_Currency: string;
  Insurer_Age: string;
  Maturity_Date: string;
  premiummode: string;
  Unscheduled: string;
  Minimum_Sum: string;
  Death_Benefit: string;
  Crediting_Interest: string;
  Guaranteed_Interest: string;
  Lock_In_Interest: string;
  selected: string;
  message: string;
  distributor_guide_details_list: any = [];
  DistributorGuideFileName: string;
  location: string;
  countryLocation: string;
  otherProductDetailslist: any = [];
  displaylinks: any = [];
  showdrop: string;
  isOtherProductavailable = false;
  // loading
  isLoadingResults: boolean;
  constructor(
    private app: AppConstants,
    private prservice: ProductService,
    private router: Router,
    private route: ActivatedRoute,
    private laserficheservice: LaserficheService
  ) {
    this.SubProduct_ID = this.route.snapshot.params.SubProduct_ID;
  }
  downloadIconGrey = this.app.downloadIconGrey;
  emailIconGrey = this.app.emailIconGrey;
  printIconGrey = this.app.printIconGrey;
  panelOpenState = false;




  ngOnInit() {
    this.getproddetails();
    //  this.selected = this.route.snapshot.paramMap.get('dropdownValue');
    const dpValue = this.route.queryParams.subscribe(data => {
      this.selected = data.dropdownValue;
      if (this.selected === 'Hong Kong') {
        this.location = 'HK';
        this.DistributorGuideFileName = 'Distributor Guide - HK';
      } else if (this.selected === 'Singapore') {
        this.location = 'SG';
        this.DistributorGuideFileName = 'Distributor Guide - SG';
      } else if (this.selected === 'Bermuda') {
        this.location = 'BM';
        this.DistributorGuideFileName = 'Distributor Guide - BM';
      }
    });
    this.getDistributorGuideDetails();
    this.getCorporateBrochureDetails();
    this.GetOtherCMSProducts();
    this.showdrop = this.selected;
    this.router.routeReuseStrategy.shouldReuseRoute = () => false;
  }
  getID(ID) {
    this.router.navigate(['/productdetail', ID], { queryParams: { dropdownValue: this.showdrop } });
    this.getproddetails();
  }

  getproddetails() {
    this.prservice.getproductdetails(this.SubProduct_ID).subscribe(data => {
      console.log(data);
      const objArray = [];
      objArray.push(data);
      this.prdetailslist = objArray;
      this.relatedLinks = objArray[0].RL;
      this.displaylinks = [];

      if (this.relatedLinks.Link1Title != null) {
        this.displaylinks.push({ 'linksTitle': this.relatedLinks.Link1Title, 'linksURL': this.relatedLinks.Link1URL });
      }
      if (this.relatedLinks.Link2Title != null) {
        this.displaylinks.push({ 'linksTitle': this.relatedLinks.Link2Title, 'linksURL': this.relatedLinks.Link2URL });
      }
      if (this.relatedLinks.Link3Title != null) {
        this.displaylinks.push({ 'linksTitle': this.relatedLinks.Link3Title, 'linksURL': this.relatedLinks.Link3URL });
      }
      if (this.relatedLinks.Link4Title != null) {
        this.displaylinks.push({ 'linksTitle': this.relatedLinks.Link4Title, 'linksURL': this.relatedLinks.Link4URL });
      }
      if (this.relatedLinks.Link5Title != null) {
        this.displaylinks.push({ 'linksTitle': this.relatedLinks.Link5Title, 'linksURL': this.relatedLinks.Link5URL });
      }
      if (this.relatedLinks.Link6Title != null) {
        this.displaylinks.push({ 'linksTitle': this.relatedLinks.Link6Title, 'linksURL': this.relatedLinks.Link6URL });
      }
      if (this.relatedLinks.Link7Title != null) {
        this.displaylinks.push({ 'linksTitle': this.relatedLinks.Link7Title, 'linksURL': this.relatedLinks.Link7URL });
      }
      if (this.relatedLinks.Link8Title != null) {
        this.displaylinks.push({ 'linksTitle': this.relatedLinks.Link8Title, 'linksURL': this.relatedLinks.Link8URL });
      }
      if (this.relatedLinks.Link9Title != null) {
        this.displaylinks.push({ 'linksTitle': this.relatedLinks.Link9Title, 'linksURL': this.relatedLinks.Link9URL });
      }
      if (this.relatedLinks.Link10Title != null) {
        this.displaylinks.push({ 'linksTitle': this.relatedLinks.Link10Title, 'linksURL': this.relatedLinks.Link10URL });
      }
    },
      error => {
        this.router.navigate(['notfound']);
      }
    );
  }
  GetOtherCMSProducts() {
    this.prservice.getOtherCMSProducts(this.SubProduct_ID).subscribe(data => {
      const objArray = [];
      for (let i = 0; i < data.length; i++) {
        {
          objArray.push(data[i]);
        }
      }
      console.log('objArray-otherProductDetailslist', objArray);
      for (let i = 0; i < objArray.length; i++) {
        this.otherProductDetailslist.push({
          ID: objArray[i].SubProduct_ID,
          heading: objArray[i].HEADING
        });
      }
    },
      error => {
        this.router.navigate(['notfound']);
      }
    );
  }
  getDistributorGuideDetails() {
    this.countryLocation = this.location;
    this.laserficheservice.extractDistributorGuideDetails()
      .subscribe(data => {
        console.log('distributor_guide', data);
      },
        error => {
          console.log('No distributor guide detail found');
        });
  }
  getCorporateBrochureDetails() {
    this.countryLocation = this.location;
    this.laserficheservice.extractCorporateBrochureDetails()
      .subscribe(data => {
        console.log('corporate_brochure', data);
      },
        error => {
          console.log('No distributor guide detail found');
        }
      );
  }

  downloadDistributorGuide() {
    this.isLoadingResults = true;
    const filename = this.DistributorGuideFileName;
    this.laserficheservice.downloadDistributorGuide(filename).subscribe(res => {
      if (res) {
        this.isLoadingResults = false;
      }
      if (window.navigator && window.navigator.msSaveOrOpenBlob) {
        window.navigator.msSaveOrOpenBlob(res, 'Distributor Guide.pdf');
      } else {
        const pdfObj = new Blob([res], { type: 'application/pdf' });
        const fileURL = URL.createObjectURL(pdfObj);
        window.open(fileURL, 'Distributor Guide.pdf');
      }
    },
      error => {
        alert('No file found');
        this.isLoadingResults = false;
      }
    );
  }

  downloadCorporateBrochure(filename) {
    this.isLoadingResults = true;
    this.laserficheservice.downloadCorpBrochure(filename).subscribe(res => {
      if (res) {
        this.isLoadingResults = false;
      }
      if (window.navigator && window.navigator.msSaveOrOpenBlob) {
        window.navigator.msSaveOrOpenBlob(res, filename + '.pdf');
      } else {
        const pdfObj = new Blob([res], { type: 'application/pdf' });
        const fileURL = URL.createObjectURL(pdfObj);
        window.open(fileURL, 'Corporate Brochure.pdf');
      }
    },
      error => {
        alert('No file found');
        this.isLoadingResults = false;
      });
  }

  opened() {
    this.panelOpenState = true;
  }
  closed() {
    this.panelOpenState = false;
  }


}
