import { Component, OnInit } from '@angular/core';
import { AppConstants } from '@app/app.constants';

@Component({
  selector: 'app-contact-us',
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.scss']
})
export class ContactUsComponent implements OnInit {

  constructor(private app: AppConstants) { }

  callContact = this.app.callContact;
  faxIcon = this.app.faxIcon;
  emailContact = this.app.emailContact;

  ngOnInit() {
  }

}
