import { Component, OnInit } from '@angular/core';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { AppConstants } from '@app/app.constants';
import { AppConfig } from '@app/app.config';

@Component({
  selector: 'app-ifis',
  templateUrl: './ifis.component.html',
  styleUrls: ['./ifis.component.scss']
})
export class IfisComponent implements OnInit {

  urlSafe: SafeResourceUrl;

  constructor(public sanitizer: DomSanitizer,
    private config: AppConfig,
  ) { }

  ngOnInit() {
    this.urlSafe = this.sanitizer.bypassSecurityTrustResourceUrl('./assets/ifis/ifis.html');
    // this.urlSafe = this.sanitizer.bypassSecurityTrustResourceUrl('/embeddedifis');
  }

}
