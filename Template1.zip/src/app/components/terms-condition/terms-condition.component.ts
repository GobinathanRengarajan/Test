import { Component, OnInit } from '@angular/core';
import { AppConstants } from '@app/app.constants';
import { Router } from '@angular/router';

@Component({
  selector: 'app-terms-condition',
  templateUrl: './terms-condition.component.html',
  styleUrls: ['./terms-condition.component.scss']
})
export class TermsConditionComponent implements OnInit {
  loginBG = this.app.loginBG;
  logo_320 = this.app.logo_320;
  logo_mobile = this.app.logo_mobile;
  footerText = this.app.footerText;
  ctaArrowWhiteIcon = this.app.ctaArrowWhiteIcon;


  constructor(
    private app: AppConstants,
    private router: Router,
  ) { }

  ngOnInit() {
  }

  iAgree() {
    localStorage.setItem('isAgreed', 'true');
    this.router.navigate(['/']);
  }
  cancel() {
    localStorage.clear();
    this.router.navigate(['/login']);
  }

}
