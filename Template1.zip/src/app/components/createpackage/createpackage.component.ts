import { FormsutilityService } from './../../core/services/formsutility/formsutility.service';
import { FormGroup, FormControl, RequiredValidator, Validators, FormBuilder } from '@angular/forms';
import { Component, OnInit, Renderer2, Inject, OnDestroy, ViewEncapsulation } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { AppConstants } from '@app/app.constants';
import { SearchComponent } from '../search/search.component';

@Component({
  selector: 'app-createpackage',
  templateUrl: './createpackage.component.html',
  styleUrls: ['./createpackage.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class CreatepackageComponent implements OnInit, OnDestroy {

  selectedRows: any = [];
  selectedLength = 0;
  createPackage: FormGroup;
  // submitted = false;

  defaultPackages = [];
  sendPackageData = [];

  close_model = this.app.close_model;
  close_model_mobile = this.app.close_model_mobile;

  constructor(
    private app: AppConstants,
    private formBuilder: FormBuilder,
    private formsService: FormsutilityService,
    public dialogRef: MatDialogRef<SearchComponent>,
    @Inject(MAT_DIALOG_DATA) public data,
    private render: Renderer2,
    @Inject(DOCUMENT) private document: Document,
  ) { }



  onNoClick(): void {
    this.dialogRef.close();
  }

  ngOnInit() {
    this.selectedLength = this.data.length;
    console.log('thi selected', this.selectedLength);
    this.createPackage = this.formBuilder.group({
      packageName: ['', Validators.required]
    });
    this.getCustomPackage();
    this.render.addClass(this.document.body, 'custompack-body');
  }
  ngOnDestroy(): void {
    this.render.removeClass(this.document.body, 'custompack-body');
  }


  // get all form package
  getCustomPackage() {
    console.log('test');
    this.formsService.getAllFormsPackages(localStorage.getItem('userId')).subscribe(data => {
      this.defaultPackages = data;
    });
  }

  removeSelectedRows(event) {
    this.data.splice(this.data.indexOf(event), 1);
    this.selectedLength = this.data.length;
  }

  // convenience getter for easy access to form fields
  get f() { return this.createPackage.controls; }

  addPackage() {
    // this.submitted = true;
    const formListData = [];
    this.data.map(res => {
      const formName = { Form_Name: res.DocumentName };
      formListData.push(formName);
    });
    const packagData = {
      Package_Name: this.createPackage.get('packageName').value,
      CreatedBy: localStorage.getItem('userId'),
      FormsList: formListData
    };
    const sendStringify = JSON.stringify(packagData);
    this.sendPackageData.push(sendStringify);

    this.formsService.addCustomPackages(sendStringify).subscribe(data => {
    });
  }


  updatePackage(update) {
    const formListData = [];
    this.data.map(res => {
      const formName = { Form_Name: res.DocumentName };
      formListData.push(formName);
    });
    const packagData = {
      PackageID: update.PackageID,
      Package_Name: update.Package_Name,
      FormsList: formListData
    };
    const updateStringify = JSON.stringify(packagData);
    this.sendPackageData.push(updateStringify);
    this.formsService.updateCustomPackages(updateStringify, update.PackageID).subscribe(data => {
      console.log('update ', data);
    });
    this.dialogRef.close();
  }

}
