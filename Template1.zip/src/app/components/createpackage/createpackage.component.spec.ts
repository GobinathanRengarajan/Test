import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CreatepackageComponent } from './createpackage.component';
import { AppConstants } from '@app/app.constants';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { MatDialogModule, MatDialog, MatButtonModule, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { MatFormFieldModule, MatInputModule } from '@angular/material';
import { MaterialModule } from '@app/modules/material/material.module';
describe('CreatepackageComponent', () => {
  let component: CreatepackageComponent;
  let fixture: ComponentFixture<CreatepackageComponent>;
  const fakeMatDialogRef = {
    snapshot: { data: {} }
  };
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreatepackageComponent ],
      imports: [ BrowserDynamicTestingModule, RouterTestingModule, BrowserModule,
        MatFormFieldModule, MaterialModule, MatInputModule, BrowserAnimationsModule,
        FormsModule, HttpClientModule, MatDialogModule, MatButtonModule],
      providers: [
        AppConstants,
        MatDialog,
        {provide: MatDialogRef, useValue: fakeMatDialogRef},
        { provide: MAT_DIALOG_DATA, useValue: [] }, ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA]
    })
    .compileComponents();
  }));
  beforeEach(() => {
    fixture = TestBed.createComponent(CreatepackageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
