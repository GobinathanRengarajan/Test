import { Component, OnInit, Renderer2, Inject, OnDestroy, ViewEncapsulation } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { AppConstants } from '@app/app.constants';
import { Router } from '@angular/router';
import { ProductService } from '@core/services/product/product.service';
import { Subscription } from 'rxjs';
import { LaserficheService } from '@app/core/services/laserfiche/laserfiche.service';
import { saveAs } from 'file-saver';





@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ProductComponent implements OnInit, OnDestroy {


  states: string[];
  selected: string;
  dropval: string;
  hong_kong = true;
  singapore = false;
  bermuda = false;
  noproduct = false;
  showdrop: string;
  location: string;
  prdetailslistsg: any = [];
  prdetailslisthk: any = [];
  prdetailslistbr: any = [];
  distributor_guide_details_list: any = [];
  DistributorGuideFileName: string;
  CorporateBrochureFileName: string;
  countryLocation: string;

  // loading
  isLoadingResults: boolean;

  constructor(private app: AppConstants,
    private router: Router,
    private render: Renderer2,
    private prservice: ProductService,
    private laserficheservice: LaserficheService,
    @Inject(DOCUMENT) private document: Document,
  ) { }

  insuranceicon = this.app.insuranceicon;
  ctaarrow = this.app.ctaArrowIcon;

  onCitySelect(value) {
    this.dropval = value;
    this.getDropdownValue();
  }

  getDropdownValue() {

    this.states = [];
    /*-------
     For pushing into States Array that means drop down value
     ------
     */
    if (localStorage.getItem('IsInHongKong') === 'true') {
      this.states.push('Hong Kong');
    }
    if (localStorage.getItem('IsInBermuda') === 'true') {
      this.states.push('Bermuda');
    }
    if (localStorage.getItem('IsInSingapore') === 'true') {
      this.states.push('Singapore');
    }
    /*------- */
    /* Condition for choosing first value in Drop down */
    if (localStorage.getItem('IsInHongKong') === 'true') {
      this.selected = 'Hong Kong';
    } else if (localStorage.getItem('IsInBermuda') === 'true') {
      this.selected = 'Bermuda';
    } else if (localStorage.getItem('IsInSingapore') === 'true') {
      this.selected = 'Singapore';
    }
    /*------- */
    this.showdrop = this.selected;
    console.log(this.showdrop);
    localStorage.setItem('showdropvalue', this.showdrop);
    if (this.selected === 'Hong Kong') {
      this.location = 'HK';
      this.DistributorGuideFileName = 'Distributor Guide - HK';
      this.prservice.getlocationdetails(this.location).subscribe(data => {
        console.log('Gobinathan', data);
        // for (let i = 0; i < data.length; i++) {
        //   if(data[i].publishStatus ==  1)
        //   {
        //     this.prdetailslisthk = data[i];
        //     console.log('test',this.prdetailslisthk)
        //     this.noproduct = false;
        //   } else {
        //     this.noproduct = true;
        //   }
        // }
        const productList = data.filter(res => res.publishStatus === 1).map(res => {
          return {
            // just to count the total list
            Description: res.Description,
            Heading: res.Heading,
            SPList: res.SPList,
          };
        });
        this.prdetailslisthk = productList;
      });
      this.hong_kong = true;
      this.singapore = false;
      this.bermuda = false;
    } else if (this.selected === 'Singapore') {
      this.location = 'SG';
      this.DistributorGuideFileName = 'Distributor Guide - SG';
      this.prservice.getlocationdetails(this.location).subscribe(data => {
        // for (let i = 0; i < data.length; i++) {
        //   if(data[i].publishStatus ==  1)
        //   {
        //     this.prdetailslistsg = data;
        //     this.noproduct = false;
        //   } else {
        //     this.noproduct = true;
        //   }
        // }
        const productList = data.filter(res => res.publishStatus === 1).map(res => {
          return {
            // just to count the total list
            Description: res.Description,
            Heading: res.Heading,
            SPList: res.SPList,
          };
        });
        this.prdetailslisthk = productList;

      });

      this.singapore = true;
      this.hong_kong = false;
      this.bermuda = false;
    } else if (this.selected === 'Bermuda') {
      this.location = 'BM';
      this.DistributorGuideFileName = 'Distributor Guide - BM';
      this.prservice.getlocationdetails(this.location).subscribe(data => {
        // for (let i = 0; i < data.length; i++) {
        //   if(data[i].publishStatus ==  1)
        //   {
        //     this.prdetailslistbr = data;
        //     this.noproduct = false;
        //   } else {
        //     this.noproduct = true;
        //   }
        // }
        const productList = data.filter(res => res.publishStatus === 1).map(res => {
          return {
            // just to count the total list
            Description: res.Description,
            Heading: res.Heading,
            SPList: res.SPList,
          };
        });
        this.prdetailslisthk = productList;
      });
      this.bermuda = true;
      this.hong_kong = false;
      this.singapore = false;
    }
  }

  ngOnInit() {
    this.render.addClass(this.document.body, 'product-body');
    this.getDropdownValue();
    this.getDistributorGuideDetails();
    this.getCorporateBrochureDetails();
  }

  ngOnDestroy(): void {
    this.render.removeClass(this.document.body, 'product-body');
  }
  getDistributorGuideDetails() {
    this.countryLocation = this.location;
    this.laserficheservice.extractDistributorGuideDetails()
      .subscribe(data => {
        console.log('distributor_guide', data);
      },
        error => {
          alert('No file found');
          this.isLoadingResults = false;
        });
  }
  getCorporateBrochureDetails() {
    this.countryLocation = this.location;
    this.laserficheservice.extractCorporateBrochureDetails()
      .subscribe(data => {
        console.log('corporate_brochure', data);
      },
        error => {
          alert('No file found');
          this.isLoadingResults = false;
        });
  }
  downloadDistributorGuide() {
    this.isLoadingResults = true;
    const filename = this.DistributorGuideFileName;
    this.laserficheservice.downloadDistributorGuide(filename).subscribe(res => {
      if (res) {
        this.isLoadingResults = false;
      }
      if (window.navigator && window.navigator.msSaveOrOpenBlob) {
        window.navigator.msSaveOrOpenBlob(res, 'Distributor Guide.pdf');
      } else {
        const pdfObj = new Blob([res], { type: 'application/pdf' });
        const fileURL = URL.createObjectURL(pdfObj);
        window.open(fileURL, 'Distributor Guide.pdf');
      }
    },
      error => {
        alert('No file found');
        this.isLoadingResults = false;
      }
    );
  }
  downloadCorporateBrochure(filename) {
    this.isLoadingResults = true;
    // const filename = 'TLB Corporate Brochure - English Version';
    this.laserficheservice.downloadCorpBrochure(filename).subscribe(res => {
      if (res) {
        this.isLoadingResults = false;
      }
      if (window.navigator && window.navigator.msSaveOrOpenBlob) {
        window.navigator.msSaveOrOpenBlob(res, 'Corporate Brochure.pdf');
      } else {
        const pdfObj = new Blob([res], { type: 'application/pdf' });
        const fileURL = URL.createObjectURL(pdfObj);
        window.open(fileURL, 'Corporate Brochure.pdf');
      }
    },
      error => {
        alert('No file found');
        this.isLoadingResults = false;
      });
  }

}
