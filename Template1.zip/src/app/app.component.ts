import {Component, OnInit, HostListener, ElementRef, ViewChild, Renderer2 } from '@angular/core';
import {SwUpdate} from '@angular/service-worker';
import { NGXLogger } from 'ngx-logger';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  constructor(private swUpdate: SwUpdate, private logger: NGXLogger, private _http: HttpClient, private elf: ElementRef,
    private render: Renderer2) {
    // this.logger.debug('Your log message goes here');
    // this.logger.debug('Multiple', 'Argument', 'support');
    // this.logger.error('Error messageyour error are here');
    this.logger.log('Your log message goes here');
    // dummy http call for interceptor testing
    // this._http.get('http://dummy.restapiexample.com/api/v1/employees').subscribe(() => {
    //   this.logger.log('Http Call is success from App compoennt');
    // }, (error) => {
    //   this.logger.log('Http Call is failed from App component');
    // });
  }

  ngOnInit() {
    if (this.swUpdate.isEnabled) {
      this.swUpdate.available.subscribe(() => {
        if (confirm('New version available. Load New Version?')) {
          window.location.reload();
        }
      });
    }
  }


  @HostListener('document:click', ['$event'])

  clickout(event) {
      const test = this.elf.nativeElement.getElementsByClassName('openSidebarMenu');
      const targetElement = event.target as HTMLElement;
    }
}
