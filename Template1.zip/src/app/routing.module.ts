import { MyProfileComponent } from './components/my-profile/my-profile.component';
import { ModuleWithProviders } from '@angular/compiler/src/core';
import { RouterModule, Routes } from '@angular/router';


import { LoginComponent } from '../app/modules/login/login.component';
import { DashboardComponent } from './modules/dashboard/dashboard/dashboard.component';
import { AdminComponent } from './components/admin/admin.component';
import { SearchComponent } from '@app/components/search/search.component';

import { AuthGuard } from '../app/core/authentication/auth.guard';
import { Role } from './shared/models/role';

import { PolicydetailsComponent } from './components/policydetails/policydetails.component';
import { NotfoundComponent } from './components/notfound/notfound.component';
import { NoresultsfoundComponent } from './components/noresultsfound/noresultsfound.component';

import { TermsConditionComponent } from './components/terms-condition/terms-condition.component';
import { PrivacyPolicyComponent } from './components/privacy-policy/privacy-policy.component';
import { ContactUsComponent } from './components/contact-us/contact-us.component';
import { ProductComponent } from './components/product/product.component';
import { NbpolicydetailsComponent } from '../app/modules/dashboard/new-business/nbpolicydetails/nbpolicydetails.component';
import { ProductdetailComponent } from './components/productdetail/productdetail.component';
import { IfisComponent} from './components/ifis/ifis.component';
import { NewsComponent } from './components/news/news.component';
import { NewsdetailComponent } from './components/news/newsdetail/newsdetail.component';
import { NewsbulletinComponent } from './components/news/newsbulletin/newsbulletin.component';

const appRoutes: Routes = [
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'termsconditions',
    component : TermsConditionComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'ifis',
    component : IfisComponent
  },
  {
    path: 'privacypolicy',
    component : PrivacyPolicyComponent
  },
  {
    path: 'contactus',
    component : ContactUsComponent
  },
  {
    path: 'dashboard',
    loadChildren: './modules/dashboard/dashboard.module#DashboardModule'
  },
  {
   path: 'news',
   component : NewsComponent
  },
  {
    path: 'newsbulletin', component: NewsbulletinComponent
  },
  {
    path: 'newsbulletin/newsdetail/:newsid', component: NewsdetailComponent
  },
  {
   path: 'notfound',
   component: NotfoundComponent
  },
  {
    path: 'nbpolicydetails/:Policy_Number',
    component: NbpolicydetailsComponent
  },
  {
    path: 'my-profile',
    component: MyProfileComponent
   },
  {
   path: 'noresultsfound',
   component: NoresultsfoundComponent
  },
  {
    path: 'search',
    component: SearchComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'policydetails/:policyNumber',
    component: PolicydetailsComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'admin',
    component: AdminComponent,
    canActivate: [AuthGuard],
    data: {
      roles: [Role.Admin]
    }
  },
  {
   path: 'product',
   component: ProductComponent,
   canActivate: [AuthGuard]
  },
  {
   path: 'productdetail/:SubProduct_ID',
   component: ProductdetailComponent,
   canActivate: [AuthGuard]
  },
  {
    path: '**',
    redirectTo: 'notfound',
    pathMatch: 'full'
  }
];
export const routing: ModuleWithProviders = RouterModule.forRoot(appRoutes);


// @NgModule({
//   imports: [RouterModule.forRoot(appRoutes)],
//   exports: [RouterModule],
//   schemas: [CUSTOM_ELEMENTS_SCHEMA]
// })
export class AppRoutingModule {}
