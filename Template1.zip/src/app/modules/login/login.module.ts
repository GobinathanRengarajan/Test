import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  MatToolbarModule,
  MatButtonModule,
  MatCardModule,
  MatDialogModule,
  MatInputModule,
  MatTableModule,
  MatMenuModule,
  MatIconModule,
  MatProgressSpinnerModule,
  MatCheckboxModule,
  MatDatepickerModule,
  MatNativeDateModule
} from '@angular/material';
import { ForgotpasswordComponent } from './forgotpassword/forgotpassword.component';
import { LoginComponent } from './login.component';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { ThankpageComponent } from './thankpage/thankpage.component';
import { AccountLockedComponent } from './account-locked/account-locked.component';
import { MaterialModule } from '../material/material.module';
import { MatMomentDateModule } from '@angular/material-moment-adapter';
import { OtpResetComponent } from './otp-reset/otp-reset.component';
import { ResetpasswordComponent } from './resetpassword/resetpassword.component';

const loginRoutes: Routes = [
  { path: '', component: LoginComponent},
  { path: 'forgotpassword', component: ForgotpasswordComponent },
  { path: 'change-password', component: ChangePasswordComponent },
  { path: 'thankpage', component: ThankpageComponent },
  { path: 'account-locked', component: AccountLockedComponent },
  { path: 'otp-reset', component: OtpResetComponent },
  { path: 'resetpassword', component: ResetpasswordComponent }
];
@NgModule({
  imports: [
    CommonModule,
    MaterialModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatMomentDateModule,
    MatToolbarModule,
    MatButtonModule,
    MatCardModule,
    MatInputModule,
    MatDialogModule,
    MatTableModule,
    MatMenuModule,
    MatIconModule,
    MatCheckboxModule,
    MatProgressSpinnerModule,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forChild(loginRoutes)
    ],
    exports: [
    CommonModule,
     MatToolbarModule,
     MatButtonModule,
     MatCardModule,
     MatInputModule,
     MatDialogModule,
     MatTableModule,
     MatMenuModule,
     MatIconModule,
     MatCheckboxModule,
     MatProgressSpinnerModule,
     ],
// tslint:disable-next-line: max-line-length
    declarations: [ForgotpasswordComponent, ChangePasswordComponent, ThankpageComponent, AccountLockedComponent, OtpResetComponent, ResetpasswordComponent]
})
export class LoginModule { }

