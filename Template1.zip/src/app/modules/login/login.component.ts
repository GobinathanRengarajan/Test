import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../../core/authentication/auth.service';
import { first } from 'rxjs/operators';
import { AppConstants } from '@app/app.constants';
import { CookieService } from 'ngx-cookie-service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  submitted = false;
  returnUrl: string;
  errors = '';
  isLogout = false;
  loading: string;
  messages: any;

  constructor(private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private authService: AuthService,
    private app: AppConstants,
    private cookies: CookieService
  ) {
    if (this.authService.currentUserValue) {
      this.router.navigate(['/login']);
    }
  }
  hide = true;
  loginTitle = this.app.loginTitle;
  userNameRequired = this.app.usernamereq;
  passwordRequired = this.app.passwordRequired;
  register = this.app.register;
  forgetPassword = this.app.forgetPassword;
  phone = this.app.phone;
  mail = this.app.mail;
  loginBG = this.app.loginBG;
  logo_320 = this.app.logo_320;
  logo_mobile = this.app.logo_mobile;
  ctaArrowWhiteIcon = this.app.ctaArrowWhiteIcon;
  callIcon = this.app.callIcon;
  emailIcon = this.app.emailIcon;
  footerText = this.app.footerText;

  ngOnInit() {

    // clear cookies
    this.cookies.deleteAll();

    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
    const isTermsConditionAccepted = JSON.parse(localStorage.getItem('isAgreed'));
    if (isTermsConditionAccepted === true) {
      this.returnUrl = '/';
    } else {
      this.returnUrl = '/termsconditions';
    }

    this.route.queryParams.subscribe(data => {
      if (data.logout === 'logoutmsg') {
        this.isLogout = true;
      }
      console.log(data.logout);
    });
  }



  get f() { return this.loginForm.controls; }


  isFieldInvalid(field: string) {
    return (
      (!this.loginForm.get(field).valid && this.loginForm.get(field).touched) ||
      (this.loginForm.get(field).untouched && this.submitted)
    );
  }

  onSubmit() {
    this.submitted = true;

    if (this.loginForm.invalid) {
      return;
    }
    this.authService.login(this.f.username.value, this.f.password.value)
      .pipe(first())
      .subscribe(
        data => {
          this.authService.currentUser.subscribe(x => {
            console.log('currentUser', x);
            this.authService.getUserLocation(x.email).subscribe(res => {
              if (res) {
                const dataRes = [];
                dataRes.push(res);
                dataRes.map(datares => localStorage.setItem('EmailID', datares.EmailID));
                dataRes.map(datares => localStorage.setItem('FirstName', datares.FirstName));
                dataRes.map(datares => localStorage.setItem('LastName', datares.LastName));
                dataRes.map(datares => localStorage.setItem('ProducerID', datares.ProducerID));
                dataRes.map(datares => localStorage.setItem('IsInBermuda', datares.IsInBermuda));
                dataRes.map(datares => localStorage.setItem('IsInSingapore', datares.IsInSingapore));
                dataRes.map(datares => localStorage.setItem('IsInHongKong', datares.IsInHongKong));
                dataRes.map(datares => localStorage.setItem('Commission_Stmt', datares.Commission_Stmt));
                dataRes.map(datares => localStorage.setItem('Country', datares.Country));
              }
              this.router.navigate([this.returnUrl]);

            },
              err => {
                console.log(err.error);
              });
          });
        },
        error => {
          console.log('error ', error);
          this.errors = 'Login failed Invalid User Credentials';
          this.isLogout = false;
        });
  }
}
