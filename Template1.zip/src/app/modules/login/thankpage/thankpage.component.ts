import { Component, OnInit } from '@angular/core';
import { AppConstants } from '@app/app.constants';

@Component({
  selector: 'app-thankpage',
  templateUrl: './thankpage.component.html',
  styleUrls: ['./thankpage.component.scss']
})
export class ThankpageComponent {
  constructor(private app: AppConstants) {}
  resetTitle = this.app.resetTitle;
  resetPasswordText = this.app.resetPasswordText;
  loginBG = this.app.loginBG;
  logo_320 = this.app.logo_320;
  logo_mobile = this.app.logo_mobile;
  ctaArrowWhiteIcon = this.app.ctaArrowWhiteIcon;
  callIcon = this.app.callIcon;
  emailIcon = this.app.emailIcon;
  footerText = this.app.footerText;
  phone = this.app.phone;
  mail = this.app.mail;
  thankyouImage = this.app.thankyouImage;
}
