import { Component, OnInit } from '@angular/core';
import { AppConstants } from '@app/app.constants';

@Component({
  selector: 'app-account-locked',
  templateUrl: './account-locked.component.html',
  styleUrls: ['./account-locked.component.scss']
})
export class AccountLockedComponent {
  constructor(private app: AppConstants) { }
  loginTitle = this.app.loginTitle;
  loginBG = this.app.loginBG;
  logo_320 = this.app.logo_320;
  logo_mobile = this.app.logo_mobile;
  ctaArrowWhiteIcon = this.app.ctaArrowWhiteIcon;
  callIcon = this.app.callIcon;
  emailIcon = this.app.emailIcon;
  footerText = this.app.footerText;
  phone = this.app.phone;
  mail = this.app.mail;
  lockedImage = this.app.lockedImage;
  loading = true;
}
