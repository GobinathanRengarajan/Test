import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';
import { AppConstants } from '@app/app.constants';
import { AuthService } from '@app/core/authentication/auth.service';

@Component({
  selector: 'app-forgotpassword',
  templateUrl: './forgotpassword.component.html',
  styleUrls: ['./forgotpassword.component.scss']
})
export class ForgotpasswordComponent implements OnInit {
  resetForm: FormGroup;
  loading = false;
  submitted = false;
  returnUrl: string;
  errors = '';

  constructor(private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private authService: AuthService,
    private app: AppConstants
  ) {
    if (this.authService.currentUserValue) {
      this.router.navigate(['/']);
    }
  }
  hide = true;
  resetTitle = this.app.resetTitle;
  resetPasswordText = this.app.resetPasswordText;
  userNameRequired = this.app.userNameRequired;
  passwordRequired = this.app.passwordRequired;
  register = this.app.register;
  forgetPassword = this.app.forgetPassword;
  phone = this.app.phone;
  mail = this.app.mail;
  loginBG = this.app.loginBG;
  logo_320 = this.app.logo_320;
  logo_mobile = this.app.logo_mobile;
  ctaArrowWhiteIcon = this.app.ctaArrowWhiteIcon;
  callIcon = this.app.callIcon;
  emailIcon = this.app.emailIcon;
  footerText = this.app.footerText;

  ngOnInit() {
    this.resetForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });

    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';

  }



  get f() { return this.resetForm.controls; }
  get userName() { return this.resetForm.get('username'); }


  isFieldInvalid(field: string) {
    return (
      (!this.resetForm.get(field).valid && this.resetForm.get(field).touched) ||
      (this.resetForm.get(field).untouched && this.submitted)
    );
  }

  resetPassword() {
    if (this.userName.valid) {
      this.router.navigate(['/challenge-question']);
    }
  }


  onSubmit() {

    this.submitted = true;


    if (this.resetForm.invalid) {
      return;
    }

    this.loading = true;
    this.authService.login(this.f.username.value, this.f.password.value)
      .pipe(first())
      .subscribe(
        data => {
          this.router.navigate([this.returnUrl]);
        },
        error => {
          this.errors = 'Session timeout, Please login again';
          this.loading = false;
        });
  }
}
