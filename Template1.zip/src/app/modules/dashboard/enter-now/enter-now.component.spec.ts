import { HttpClient, HttpHandler } from '@angular/common/http';
import { AuthService } from '@app/core/authentication/auth.service';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { EnterNowComponent } from './enter-now.component';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { AppConstants } from '@app/app.constants';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';

describe('EnterNowComponent', () => {
  let component: EnterNowComponent;
  let fixture: ComponentFixture<EnterNowComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EnterNowComponent ],
      imports: [ BrowserAnimationsModule, BrowserDynamicTestingModule, RouterTestingModule, HttpClientTestingModule],
      providers: [AuthService, AppConstants],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EnterNowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it(`should have as title 'Commission Statement'`, () => {
    const text = component.commissionTitle;
    expect(text).toEqual('Commission Statement');
  });

  it(`should have as sub title 'Lorem Lipsum Is Simply Dummy Text'`, () => {
    const text = component.commissionSubTitle;
    expect(text).toEqual('Lorem Lipsum Is Simply Dummy Text');
  });

  it(`should have as title 'Mytransware'`, () => {
    const text = component.mytranswareTitle;
    expect(text).toEqual('Mytransware');
  });

  // it(`should have as sub title 'New Business Illustration'`, () => {
  //   const text = component.mytranswareSubTitle;
  //   expect(text).toEqual('New Business Illustration');
  // });

});
