import { Component, OnInit } from '@angular/core';
import { AppConstants } from '@app/app.constants';
import { AuthService } from 'app/core/authentication/auth.service';
import { AppConfig } from '@app/app.config';
import { Router, ActivatedRoute } from '@angular/router';
import { MwadaptorService } from '@app/core/services/mwadaptor/mwadaptor.service';

@Component({
  selector: 'app-enter-now',
  templateUrl: './enter-now.component.html',
  styleUrls: ['./enter-now.component.scss']
})
export class EnterNowComponent implements OnInit {
  mytranswareTitle = this.app.mytranswareTitle;
  mytranswareSubTitle = this.app.mytranswareSubTitle;
  myTranswarImage = this.app.myTranswarImage;
  myTranswarCaImage = this.app.myTranswarCaImage;
  enterNow = this.app.enterNow;
  commissionTitle = this.app.commissionTitle;
  commissionSubTitle = this.app.commissionSubTitle;
  commissionStatementImage = this.app.commissionStatementImage;
  myTranswareLink = this.appConfig.getConfig('myTranswareLink') + this.encryptString();
  ctaArrowWhiteIcon = this.app.ctaArrowWhiteIcon;
  ctaArrowIcon = this.app.ctaArrowIcon;
  mytranswareBG = this.app.mytranswareBG;
  commissionBG = this.app.commissionBG;


  constructor(
    private mwadaptorService: MwadaptorService,
    private router: Router,
    private app: AppConstants,
    private appConfig: AppConfig,
    private authservice: AuthService) { }

  isGeneralAdmin = false;

  encryptString(): String {

    const user = 'user=' + this.appConfig.getConfig('myTranswareUser');
    const email = '&email=' + this.appConfig.getConfig('myTranswareEmail');
    const firstName = '&firstName=' + this.appConfig.getConfig('myTranswareFirstName');
    const lastName = '&lastName=' + this.appConfig.getConfig('myTranswareLastName');
    const activeAgentID = '&activeAgentID=' + this.appConfig.getConfig('myTranswareActiveAgentID');
    const activeOfficeID = '&activeOfficeID=' + this.appConfig.getConfig('myTranswareActiveOfficeID');
    const agencyName = '&agencyName=' + this.appConfig.getConfig('myTranswareAgencyName');
    return user + email + firstName + lastName + activeAgentID + activeOfficeID + agencyName;
  }

  callMyTransware() {
    this.mwadaptorService.getMyTranswareSSO(this.encryptString()).subscribe(
      result => {
        console.log('url,', result['url']);
        window.open(result['url'], '_blank');
      },
      error => {
        console.log('error to call MyTransaware ', error);
      }
    );
  }

  ngOnInit() {
    console.log('Email:', localStorage.getItem('EmailID'));
    if (localStorage.getItem('Commission_Stmt') === '1') {
      this.isGeneralAdmin = true;
    } else {
      this.isGeneralAdmin = false;

    }
  }

}
