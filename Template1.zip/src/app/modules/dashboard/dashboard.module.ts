import { CustomPackageComponent } from './forms/formslanding/custom-package/custom-package.component';
import { DashboardViewComponent } from './dashboard-view.component';
import { AuthGuard } from './../../core/authentication/auth.guard';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardComponent } from './dashboard/dashboard.component';
import { InforceComponent } from './inforce/inforce.component';
import { NewBusinessComponent } from './new-business/new-business.component';
import { FormsComponent } from './forms/forms.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MAT_MOMENT_DATE_FORMATS, MatMomentDateModule, MomentDateAdapter } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE, SatDatepickerModule, SatNativeDateModule } from 'saturn-datepicker';
import { HeaderComponent } from '../../core/header/header.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { EnterNowComponent } from './enter-now/enter-now.component';
import { UpcomingBirthdayComponent } from './inforce/upcoming-birthday/upcoming-birthday.component';
import { SharedDataComponent } from './shared-data/shared-data.component';
import { LongPendigCasesComponent } from './new-business/long-pendig-cases/long-pendig-cases.component';
import { AcceptLettersExpiredComponent } from './new-business/accept-letters-expired/accept-letters-expired.component';
import { CaseIssuedComponent } from './new-business/case-issued/case-issued.component';
import { PendingCasesComponent } from './new-business/pending-cases/pending-cases.component';
import { CurrentPolicyComponent } from './inforce/current-policy/current-policy.component';
import { PremiumDueComponent } from './inforce/premium-due/premium-due.component';
import { FooterComponent } from '@app/core/footer/footer.component';
import { InforceLandingComponent } from './inforce/inforce-landing/inforce-landing.component';
import { RouterModule, Routes } from '@angular/router';
import { FilterDialogComponent } from './inforce/filter-dialog/filter-dialog.component';
import { NewBusinessLandingComponent } from './new-business/new-business-landing/new-business-landing.component';
import { MaterialModule } from '../material/material.module';
import { NbpolicydetailsComponent } from './new-business/nbpolicydetails/nbpolicydetails.component';
import { NbfilterDialogComponent } from './new-business/nbfilter-dialog/nbfilter-dialog.component';
import { TruncatePipe } from '@app/pipe/truncate.pipe';
import { FormslandingComponent } from './forms/formslanding/formslanding.component';
import { FormsdialogComponent } from './forms/formsdialog/formsdialog.component';
import { SearchformsComponent } from './forms/searchforms/searchforms.component';
import { SlideshowModule } from 'ng-simple-slideshow';
import { NewsComponent } from '@app/components/news/news.component';


const dashBoardRoutes: Routes = [
  {
    path: '', component: DashboardViewComponent, canActivate: [AuthGuard],
    children: [
      { path: '', component: DashboardComponent },
      { path: 'inforce/:policy/:period', component: InforceLandingComponent },
      { path: 'inforce/:policy/:periodFrom/:periodTo', component: InforceLandingComponent },
      { path: 'new-business/:policy', component: NewBusinessLandingComponent },
      { path: 'new-business/:policy/:period', component: NewBusinessLandingComponent },
      { path: 'new-business/:policy/:periodFrom/:periodTo', component: NewBusinessLandingComponent },
      { path: 'policystatus', component: NewBusinessLandingComponent },
      { path: 'forms', component: FormsComponent },
      {
        path: 'new-business', component: NewBusinessLandingComponent,
        children: [
          { path: 'nbpolicydetails/:Policy_Number', component: NbpolicydetailsComponent }
        ]
      },
      {
        path: 'formslanding', component: FormslandingComponent
      },
      {
        path: 'searchforms', component: SearchformsComponent
      }
    ]
  },
];

@NgModule({
  declarations: [
    DashboardComponent,
    InforceComponent,
    NewBusinessComponent,
    FormsComponent,
    HeaderComponent,
    NewsComponent,
    FooterComponent,
    EnterNowComponent,
    UpcomingBirthdayComponent,
    SharedDataComponent,
    PremiumDueComponent,
    CurrentPolicyComponent,
    PendingCasesComponent,
    CaseIssuedComponent,
    AcceptLettersExpiredComponent,
    LongPendigCasesComponent,
    InforceLandingComponent,
    FilterDialogComponent,
    NewBusinessLandingComponent,
    DashboardViewComponent,
    NbpolicydetailsComponent,
    NbfilterDialogComponent,
    TruncatePipe,
    FormslandingComponent,
    FormsdialogComponent,
    SearchformsComponent,
    CustomPackageComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    MatMomentDateModule,
    SatDatepickerModule,
    SatNativeDateModule,
    MaterialModule,
    SlideshowModule,
    RouterModule.forChild(dashBoardRoutes)
  ],
  exports: [
    DashboardViewComponent,
    InforceLandingComponent,
    HeaderComponent,
    NewsComponent,
    FooterComponent,
    TruncatePipe,
  ],
  entryComponents: [
    FilterDialogComponent,
    NbfilterDialogComponent,
    FormsdialogComponent,
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  providers: [
    { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] },
    { provide: MAT_DATE_FORMATS, useValue: MAT_MOMENT_DATE_FORMATS },
  ]
})
export class DashboardModule { }
