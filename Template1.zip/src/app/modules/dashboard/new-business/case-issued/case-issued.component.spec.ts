import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CaseIssuedComponent } from './case-issued.component';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { MatDatepickerModule } from '@angular/material';
import { AuthService } from '@app/core/authentication/auth.service';
import { MaterialModule } from '@app/modules/material/material.module';
import { AppConstants } from '@app/app.constants';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';

describe('CaseIssuedComponent', () => {
  let component: CaseIssuedComponent;
  let fixture: ComponentFixture<CaseIssuedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CaseIssuedComponent ],
      imports: [
        HttpClientModule,
        BrowserAnimationsModule,
        BrowserDynamicTestingModule,
        RouterTestingModule,
        MatDatepickerModule,
        FormsModule,
        ReactiveFormsModule,
        MaterialModule
      ],
      providers: [AuthService, AppConstants],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CaseIssuedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
