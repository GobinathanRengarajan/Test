import { FormGroup, FormBuilder } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { NewbusinessService } from '@services/newbusiness/newbusiness.service';
import * as moment from 'moment';
import { AppConstants } from '@app/app.constants';
import { Router } from '@angular/router';

@Component({
  selector: 'app-case-issued',
  templateUrl: './case-issued.component.html',
  styleUrls: ['./case-issued.component.scss']
})
export class CaseIssuedComponent implements OnInit {

  // case issued
  getIcon = this.app.caseIssuedIcon;
  getLabel = this.app.getLabelCaseIssued;
  dataCount: any = [];
  getDays: string;
  isDataAvailable = false;
  reslutDataCount: string;
  startDate = moment().startOf('year');
  endDate = moment();
  form: FormGroup;

  constructor(
    private newBusiness: NewbusinessService,
    private fb: FormBuilder,
    private app: AppConstants,
    private router: Router
  ) {
    this.form = fb.group({
      date: [{ begin: this.startDate, end: this.endDate }]
    });
  }

  ngOnInit() {
    if (this.dataCount.length === 0) {
      this.reslutDataCount = this.dataCount.length;
    }
    this.dateRangeChange();
  }
  leadingZero(n) {
    return (n < 10) ? ('0' + n) : n;
  }

  getSelectValue() {
    this.newBusiness.getMessage('Case Issued');
    if (this.isDataAvailable) {
      this.router.navigate(['/new-business', `${this.getLabel}`,
        `${this.startDate.format('YYYYMMDD')}`, `${this.endDate.format('YYYYMMDD')}`]);
    }
  }
  // premium due
  get getDateValue() { return this.form.get('date'); }

  dateRangeChange() {
    this.startDate = this.getDateValue.value.begin;
    this.endDate = this.getDateValue.value.end;
    this.getDays = `${this.startDate.format('DD/MMM/YY')} To ${this.endDate.format('DD/MMM/YY')}`;

    // set behaviour subject
    const passDateRange = { startDate: this.startDate, endDate: this.endDate };
    this.newBusiness.getMessageCaseIssued(passDateRange);

    this.newBusiness.getCaseIssued(localStorage.getItem('userId'), this.startDate.format('YYYYMMDD'), this.endDate.format('YYYYMMDD'))
      .subscribe(data => {
        this.dataCount = data;
        // this.reslutDataCount = ('0' + this.dataCount.length).slice(-2);
        this.reslutDataCount = this.leadingZero(this.dataCount.length);
        if (data.length >= 1) {
          this.isDataAvailable = true;
        }
      });
  }

}
