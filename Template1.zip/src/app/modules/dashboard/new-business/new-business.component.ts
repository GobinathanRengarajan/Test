import { Component, OnInit } from '@angular/core';
import { AppConstants } from '@app/app.constants';
import { NewbusinessService } from '@app/core/services/newbusiness/newbusiness.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-new-business',
  templateUrl: './new-business.component.html',
  styleUrls: ['./new-business.component.scss']
})
export class NewBusinessComponent implements OnInit {

  title = this.app.newBusinessTitle;
  viewList = this.app.viewCompleteList;

  constructor(
    private app: AppConstants,
    private newBusiness: NewbusinessService,
    private router: Router
  ) { }

  ngOnInit() {

  }

  // send dropdown value for landing page
  getSelectValue() {
    this.router.navigate(['/new-business', `${this.viewList}`, 'all']);
  }

}
