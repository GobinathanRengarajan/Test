import { FormGroup, FormBuilder } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { NewbusinessService } from '@services/newbusiness/newbusiness.service';
import * as moment from 'moment';
import { AppConstants } from '@app/app.constants';
import { Router } from '@angular/router';

@Component({
  selector: 'app-accept-letters-expired',
  templateUrl: './accept-letters-expired.component.html',
  styleUrls: ['./accept-letters-expired.component.scss']
})
export class AcceptLettersExpiredComponent implements OnInit {

  // accept letters expired
  getIcon = this.app.offerExpiredIcon;
  getLabel = this.app.getLabelAcceptLetters;
  dataCount: any = [];
  getDays: string;
  isDataAvailable = false;
  reslutDataCount: string;
  startDate = moment();
  endDate = moment().add(30, 'days');

  form: FormGroup;

  constructor(
    private newBusiness: NewbusinessService,
    private fb: FormBuilder,
    private app: AppConstants,
    private router: Router
  ) { }

  ngOnInit() {
    if (this.dataCount.length === 0) {
      this.reslutDataCount = this.dataCount.length;
    }
    this.dateRangeChange();
  }
  leadingZero(n) {
    return (n < 10) ? ('0' + n) : n;
  }
  getSelectValue() {
    this.newBusiness.getMessage('Accept.Letters Expiring');
    if (this.isDataAvailable) {
      this.router.navigate(['/new-business', `${this.getLabel}`,
        `${this.startDate.format('YYYYMMDD')}`, `${this.endDate.format('YYYYMMDD')}`]);
    }
  }
  // premium due
  get getDateValue() { return this.form.get('date'); }

  dateRangeChange() {
    const startDate = this.startDate;
    const endDate = this.endDate;
    this.getDays = `In ${endDate.diff(startDate, 'days')} days`;
    this.newBusiness.getAcceptLetterExpired(localStorage.getItem('userId'), startDate.format('YYYYMMDD'), endDate.format('YYYYMMDD'))
      .subscribe(data => {
        this.dataCount = data;
        // this.reslutDataCount = ('0' + this.dataCount.length).slice(-2);
        this.reslutDataCount = this.leadingZero(this.dataCount.length);
        if (data.length >= 1) {
          this.isDataAvailable = true;
        }
      });
  }

}
