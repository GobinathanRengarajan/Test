import { Component, OnInit } from '@angular/core';
import { NewbusinessService } from '@services/newbusiness/newbusiness.service';
import { AppConstants } from '@app/app.constants';
import { Router } from '@angular/router';

@Component({
  selector: 'app-long-pendig-cases',
  templateUrl: './long-pendig-cases.component.html',
  styleUrls: ['./long-pendig-cases.component.scss']
})
export class LongPendigCasesComponent implements OnInit {

  // long pending
  getIcon = this.app.pendingCasesLongIcon;
  getLabel = this.app.getLabelLongPending;
  dataCount: any = [];
  getDays: string;
  isDataAvailable = false;
  reslutDataCount: string;
  constructor(
    private newBusiness: NewbusinessService,
    private app: AppConstants,
    private router: Router
  ) { }

  ngOnInit() {
    if (this.dataCount.length === 0) {
      this.reslutDataCount = this.dataCount.length;
    }
    this.dateRangeChange();
  }
  leadingZero(n) {
    return (n < 10) ? ('0' + n) : n;
  }
  getSelectValue() {
    this.newBusiness.getMessage('Long Pending Cases');
    if (this.isDataAvailable) {
      this.router.navigate(['/new-business', `${this.getLabel}`]);
    }
  }

  dateRangeChange() {
    this.newBusiness.getLongPendingCases(localStorage.getItem('userId'))
      .subscribe(data => {
        this.dataCount = data;
        // this.reslutDataCount = ('0' + this.dataCount.length).slice(-2);
        this.reslutDataCount = this.leadingZero(this.dataCount.length);
        if (data.length >= 1) {
          this.isDataAvailable = true;
        }
      });
  }


}
