import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NbfilterDialogComponent } from './nbfilter-dialog.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { BrowserModule } from '@angular/platform-browser';
import {
  MatFormFieldModule,
  MatInputModule,
  MatDialogModule,
  MatButtonModule,
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
  DateAdapter,
  MAT_DATE_LOCALE,
  MAT_DATE_FORMATS,
  MatProgressSpinnerModule,
  MatDatepickerModule,
  MatNativeDateModule
} from '@angular/material';
import { HttpClientModule } from '@angular/common/http';
import { MaterialModule } from '@app/modules/material/material.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppConstants } from '@app/app.constants';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { MomentDateAdapter, MAT_MOMENT_DATE_FORMATS, MatMomentDateModule } from '@angular/material-moment-adapter';
import { SatNativeDateModule, SatDatepickerModule } from 'saturn-datepicker';

describe('NbfilterDialogComponent', () => {
  let component: NbfilterDialogComponent;
  let fixture: ComponentFixture<NbfilterDialogComponent>;
  const fakeMatDialogRef = {
    snapshot: { data: {} }
  };
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [NbfilterDialogComponent],
      imports: [BrowserAnimationsModule,
        BrowserDynamicTestingModule,
        RouterTestingModule,
        MatProgressSpinnerModule,
        MaterialModule,
        MatDatepickerModule,
        MatNativeDateModule,
        MatButtonModule,
        MatMomentDateModule,
        HttpClientModule,
        MatDialogModule,
        FormsModule,
        MatInputModule,
        ReactiveFormsModule,
        MatFormFieldModule,
        SatDatepickerModule,
        SatNativeDateModule],
      providers: [
        AppConstants,
        MatDialog,
        { provide: MatDialogRef, useValue: fakeMatDialogRef },
        {
          provide: DateAdapter, useClass: MomentDateAdapter,
          deps: [MAT_DATE_LOCALE]
        }, {
          provide: DateAdapter,
          useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE]
        }, {
          provide: MAT_DATE_FORMATS,
          useValue: MAT_MOMENT_DATE_FORMATS
        }, { provide: MAT_DIALOG_DATA, useValue: {} }
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NbfilterDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
