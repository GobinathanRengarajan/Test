import { AppConstants } from '@app/app.constants';
import { Component, OnInit, Inject, ViewEncapsulation } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FormControl, FormGroup, FormArray } from '@angular/forms';
import { MomentDateAdapter } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import * as moment from 'moment';
import { Moment } from 'moment';
import { MatDatepicker } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';
import { NewBusinessLandingComponent } from '../new-business-landing/new-business-landing.component';
export interface DialogData {
  modalStatus: string[];
  productName: string[];
}
// const moment =  _moment;

export const MY_FORMATS = {
  parse: {
    dateInput: 'MMM-YYYY',
  },
  display: {
    dateInput: 'MMM-YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};
@Component({
  selector: 'app-nbfilter-dialog',
  templateUrl: './nbfilter-dialog.component.html',
  styleUrls: ['./nbfilter-dialog.component.scss'],
  providers: [
    { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
  ],
  encapsulation: ViewEncapsulation.None
})
export class NbfilterDialogComponent implements OnInit {

  statusList: string[];
  productNameList: string[] = [];
  // icons
  closeIcon = this.app.closeIcon;

  filterForm = new FormGroup({
    policyStatus: new FormControl(),
    lastName: new FormControl(),
    firstName: new FormControl(),
    insuredName: new FormControl(),
    productName: new FormControl(),
    producerName: new FormControl()
  });



  constructor(
    public dialogRef: MatDialogRef<NewBusinessLandingComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData,
    private router: Router,
    private _route: ActivatedRoute,
    private app: AppConstants
  ) { }

  ngOnInit() {
    this.statusList = [...this.data.modalStatus];
    this.data.productName.map(data => {
      if (data !== null) {
        this.productNameList.push(data);
      }
    });

    // set form values
    this._route.queryParams.subscribe(params => {
      this.policyStatus.setValue(params.policyStatus);
      this.lastName.setValue(params.lastName);
      this.firstName.setValue(params.firstName);
      this.producerName.setValue(params.producerName);
      this.productName.setValue(params.productName);
    });
  }

  applyFilter() {
    this.router.navigate([], {
      queryParams: {
        policyStatus: this.policyStatus.value,
        lastName: this.lastName.value,
        firstName: this.firstName.value,
        insuredName: this.insuredName.value,
        productName: this.productName.value,
        producerName: this.producerName.value
      }
    });
  }
  get policyStatus() { return this.filterForm.get('policyStatus'); }
  get lastName() { return this.filterForm.get('lastName'); }
  get firstName() { return this.filterForm.get('firstName'); }
  get insuredName() { return this.filterForm.get('insuredName'); }
  get productName() { return this.filterForm.get('productName'); }
  get producerName() { return this.filterForm.get('producerName'); }

  onNoClick(): void {
    this.dialogRef.close();
  }

}
