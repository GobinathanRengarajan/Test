import { Component, OnInit, ViewChild, Renderer2, Inject, OnDestroy, ViewEncapsulation } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { MatTableDataSource, MatPaginator, MatSort, MatDialog, PageEvent } from '@angular/material';
import { AppConstants } from '@app/app.constants';
import { NewbusinessService } from '@app/core/services/newbusiness/newbusiness.service';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { NbfilterDialogComponent } from '../nbfilter-dialog/nbfilter-dialog.component';
import * as moment from 'moment';

@Component({
  selector: 'app-new-business-landing',
  templateUrl: './new-business-landing.component.html',
  styleUrls: ['./new-business-landing.component.scss']
})
export class NewBusinessLandingComponent implements OnInit, OnDestroy {
  @ViewChild(MatPaginator) paginator: MatPaginator;
  datalength = 0;
  /**
   * Set the paginator after the view init since this component will
   * be able to query its view for the initialized paginator.
   */

  states: string[] = ['View Complete List', 'Pending Cases', 'Case Issued', 'Accept. Letters Expiring', 'Long Pending Cases'];
  sortval: number[] = [5, 10];
  defaultval = 5;
  selected: string;
  filteredValues: any;
  resutlDatalength = 0;
  dataCount: any = [];
  reslutDataCount: any;
  // reslutDataCount: string;
  isDataLoaded = false;
  isClearActive = true;
  isLoadingResults: boolean;
  // icons
  sortingIcon = this.app.sortingIcon;
  searchColorIcon = this.app.searchColorIcon;
  val = '123456789';
  // table
  displayedColumns: string[] = [
    'Policy_Number',
    'Status',
    'Product_Name',
    'Insured_Name',
    'Sum_Assured',
    'Producer_Name'
  ];

  filterValues = {
    Status: '',
    Product_Name: '',
    Insured_Name: '',
    Producer_Name: ''
  };

  modalStatus: string[];
  productName: string[];
  // dataSource = new MatTableDataSource(ELEMENT_DATA);
  dataSource = new MatTableDataSource<any>();
  pageloadstart = false;
  // @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  isloading = true;
  filterData: any[] = [];
  name: string;
  startDate: string;
  endDate: string;
  month: string;
  datePeriod: string;
  startDateAccept = moment();
  endDateAccept = moment().add(30, 'days');
  dialogstatus = false;
  isNodata = false;
  dialogopen = false;

  isDataAvailable = true;
  isModalClose = false;

  searchValue = '';


  constructor(
    public dialog: MatDialog,
    private nbservice: NewbusinessService,
    private app: AppConstants, private router: Router, private route: ActivatedRoute,
    private render: Renderer2, @Inject(DOCUMENT) private document: Document
  ) { }


  onCitySelect(val) {
    this.defaultval = val;
    console.log(val);
    this.searchValue = '';
    this.nbLandingApiCall();
  }
  pageChanged(val) {
    console.log('page changed', val);
  }

  ngOnInit() {

    this.getDropdownValue();
    this.paramsDataCall();
    this.getCaseIssued();
    this.nbLandingApiCall();
    this.dataSource.sort = this.sort;
    console.log('NB', this.route.snapshot);
    if (this.resutlDatalength >= 1) {
      // this.reslutDataCount = ('0' + this.resutlDatalength).slice(-3);
      this.reslutDataCount = this.leadingZero(this.resutlDatalength);
    } else {
      this.reslutDataCount = '0';
    }

    this.pageloadstart = true;
    this.render.addClass(this.document.body, 'newbusiness-body');
  }
  leadingZero(n) {
    return (n < 10) ? ('0' + n) : n;
  }
  ngOnDestroy(): void {
    this.render.removeClass(this.document.body, 'newbusiness-body');
  }
  paramsDataCall() {
    this.selected = this.route.snapshot.paramMap.get('policy');
    this.startDate = this.route.snapshot.paramMap.get('periodFrom');
    this.endDate = this.route.snapshot.paramMap.get('periodTo');
    this.month = this.route.snapshot.paramMap.get('period');

    console.log('start date', this.startDate, 'end date', this.endDate);
    console.log('start date params',
      this.route.snapshot.paramMap.get('periodFrom'), 'end date params',
      this.route.snapshot.paramMap.get('periodTo'));
  }

  clearFilter() {
    this.searchValue = null;
    this.nbLandingApiCall();
  }


  // for dialog open
  openDialog(): void {
    this.dialogstatus = true;
    const dialogRef = this.dialog.open(NbfilterDialogComponent, {
      panelClass: 'filter-dialog-modal',
      data: { modalStatus: this.modalStatus, productName: this.productName }
    });

    dialogRef.afterClosed().subscribe(result => {
      this.isModalClose = true;
      if (result === undefined || result === '') {
        this.isLoadingResults = false;
      } else {
        this.isLoadingResults = true;
        this.nbLandingApiCall();
        this.router.navigate([], {
          queryParams: {
            policyStatus: result.policyStatus,
            lastName: result.lastName,
            firstName: result.firstName,
            insuredName: result.insuredName,
            productName: result.productName,
            producerName: result.producerName
          }
        });
      }

      setTimeout(() => {
        this.dataSource.filterPredicate = (data) => {
          this.isClearActive = false;
          this.isLoadingResults = false;
          if (result == null) {
            return true;
          } else {
            let andFilter = true;
            if ((result.policyStatus != null) && (result.policyStatus.includes(data.Status))) {
              andFilter = true;
            } else if (result.policyStatus == null) {
              andFilter = andFilter;
            } else {
              // short-cut to return false, no need to compare other fields again
              return false;
            }

            if ((result.lastName != null) && (data.Insured_Name.toLowerCase().includes(result.lastName.toLowerCase()))) {
              andFilter = true;
            } else if (result.lastName == null) {
              andFilter = andFilter;
            } else {
              return false;
            }

            if ((result.firstName != null) && (data.Insured_Name.toLowerCase().includes(result.firstName.toLowerCase()))) {
              andFilter = true;
            } else if (result.firstName == null) {
              andFilter = andFilter;
            } else {
              return false;
            }

            if ((result.productName != null) && (data.Product_Name != null) &&
              (data.Product_Name.trim().toLowerCase().includes(result.productName.trim().toLowerCase()))) {
              andFilter = true;
            } else if (result.productName == null) {
              andFilter = andFilter;
            } else {
              return false;
            }
            if ((result.producerName != null) && (data.Producer_Name != null) &&
              (data.Producer_Name.trim().toLowerCase().includes(result.producerName.trim().toLowerCase()))) {
              andFilter = true;
            } else if ((result.producerName == null) || (result.producerName === '')) {
              andFilter = andFilter;
            } else {
              return false;
            }
            return andFilter;
          }
        };
        this.dataSource.filter = '' + Math.random();
        const filteredData = this.dataSource.filteredData;
        this.resutlDatalength = filteredData.length;
        if (this.resutlDatalength >= 1) {
          // this.reslutDataCount = ('0' + this.resutlDatalength).slice(-3);
          this.reslutDataCount = this.leadingZero(this.resutlDatalength);
        } else {
          this.reslutDataCount = '0';
        }
        this.dataSource = new MatTableDataSource(filteredData);
        this.isClearActive = false;
        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;
      }, 5000);

    });
  }


  nbLandingApiCall() {
    if (this.selected === 'View Complete List') {
      this.datePeriod = '';
      this.isClearActive = true;
      this.nbservice.getcompleteNBlist(localStorage.getItem('userId')).subscribe(data => {
        // loader hide
        if (data.length === 0) {
          this.isDataAvailable = false;
        } else {
          this.isDataAvailable = true;
        }
        this.isDataLoaded = true;

        // rewrite the json data start
        const reWriteData = data.map(res => {
          if (res.LastName == null) {
            res.LastName = '';
          }
          if (res.FirstName == null) {
            res.FirstName = '';
          }
          if (res.MiddleName == null) {
            res.MiddleName = '';
          }
          return {
            Policy_Number: res.PolicyNumber,
            Status: res.Status,
            Product_Name: res.Product,
            Insured_Name: (res.LastName + ' ' + res.FirstName + ' ' + res.MiddleName).trim(),
            Sum_Assured: '$' + res.SumAssured,
            Producer_Name: res.ProducerName
          };
        }, error => {
          this.isDataAvailable = false;
          console.log(error, this.isDataAvailable);
        });
        // rewrite the json data end
        this.isloading = false;
        this.dataSource = new MatTableDataSource(reWriteData);
        console.log(this.dataSource);
        console.log(!(this.dataSource !== null && this.dataSource.data.length === 0));
        this.datalength = data.length;
        this.resutlDatalength = data.length;
        if (this.resutlDatalength >= 1) {
          // this.reslutDataCount = ('0' + this.resutlDatalength).slice(-3);
          this.reslutDataCount = this.leadingZero(this.resutlDatalength);
        } else {
          this.reslutDataCount = '0';
        }
        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;
        // for modal array status pass
        this.modalStatus = [...Array.from(new Set(data.map(res => res.Status)))];
        this.productName = [...Array.from(new Set(data.map(res => res.Product)))];
        console.log('modal array pass', data);
      }, error => {
        this.isDataAvailable = false;
        console.log(error, this.isDataAvailable);
      });
      // params
      this.router.navigate(['/new-business', `${this.selected}`, 'all']);

      console.log('NB', this.route.snapshot.paramMap.get('policy'));
      // premium due
    } else if (this.selected === 'Pending Cases') {
      this.isClearActive = true;
      this.nbservice.getPendingCases(
        localStorage.getItem('userId'))
        .subscribe(data => {
          // loader hide
          if (data.length === 0) {
            this.isDataAvailable = false;
          } else {
            this.isDataAvailable = true;
          }
          this.isDataLoaded = true;
          // rewrite the json data start
          const reWriteData = data.map(res => {
            if (res.LastName == null) {
              res.LastName = '';
            }
            if (res.FirstName == null) {
              res.FirstName = '';
            }
            if (res.MiddleName == null) {
              res.MiddleName = '';
            }
            return {
              Policy_Number: res.PolicyNumber,
              Status: res.Status,
              Product_Name: res.Product,
              Insured_Name: (res.LastName + ' ' + res.FirstName + ' ' + res.MiddleName).trim(),
              Sum_Assured: res.SumAssured,
              Producer_Name: res.ProducerName
            };
          });
          // rewrite the json data end
          this.isloading = false;
          this.dataSource = new MatTableDataSource(reWriteData);
          this.datalength = data.length;
          this.resutlDatalength = data.length;
          if (this.resutlDatalength >= 1) {
            // this.reslutDataCount = ('0' + this.resutlDatalength).slice(-3);
            this.reslutDataCount = this.leadingZero(this.resutlDatalength);
          } else {
            this.reslutDataCount = '0';
          }
          this.dataSource.sort = this.sort;
          this.dataSource.paginator = this.paginator;
          this.datePeriod = '';
          console.log(this.datalength);
          console.log(!(this.dataSource != null && this.dataSource.data.length === 0));

          // for modal array status pass
          this.modalStatus = [...Array.from(new Set(data.map(res => res.Status)))];
          this.productName = [...Array.from(new Set(data.map(res => res.Product)))];
          console.log('modal array pass', data);
        }, error => {
          this.isDataAvailable = false;
          console.log(error, this.isDataAvailable);
        });
      // params
      this.router.navigate([
        '/new-business', `${this.selected}`
      ]);
      console.log('NB', this.route.snapshot.paramMap.get('policy'));
      // Coming Birthday
    } else if (this.selected === 'Case Issued') {
      this.isClearActive = true;
      console.log('start date', this.startDate, 'end date', this.endDate);
      this.datePeriod = `from ${moment(this.startDate).format('DD MMM YYYY')} to ${moment(this.endDate).format('DD MMM YYYY')}`;
      this.nbservice.getCaseIssued(
        localStorage.getItem('userId'),
        (this.route.snapshot.paramMap.get('periodFrom')),
        (this.route.snapshot.paramMap.get('periodTo')))
        .subscribe(data => {
          // loader hide
          if (data.length === 0) {
            this.isDataAvailable = false;
          } else {
            this.isDataAvailable = true;
          }
          this.isDataLoaded = true;
          // rewrite the json data start
          const reWriteData = data.map(res => {
            if (res.LastName == null) {
              res.LastName = '';
            }
            if (res.FirstName == null) {
              res.FirstName = '';
            }
            if (res.MiddleName == null) {
              res.MiddleName = '';
            }
            return {
              Policy_Number: res.PolicyNumber,
              Status: res.Status,
              Product_Name: res.Product,
              Insured_Name: (res.LastName + ' ' + res.FirstName + ' ' + res.MiddleName).trim(),
              Sum_Assured: res.SumAssured,
              Producer_Name: res.ProducerName
            };
          });
          // rewrite the json data end
          this.isloading = false;
          this.dataSource = new MatTableDataSource(reWriteData);
          this.datalength = data.length;
          this.resutlDatalength = data.length;
          if (this.resutlDatalength >= 1) {
            // this.reslutDataCount = ('0' + this.resutlDatalength).slice(-3);
            this.reslutDataCount = this.leadingZero(this.resutlDatalength);
          } else {
            this.reslutDataCount = '0';
          }
          this.dataSource.sort = this.sort;
          this.dataSource.paginator = this.paginator;
          if (data) {
            this.isNodata = true;
          }
          // for modal array status pass
          this.modalStatus = [...Array.from(new Set(data.map(res => res.Status)))];
          this.productName = [...Array.from(new Set(data.map(res => res.Product)))];
          console.log('modal array pass', this.modalStatus);
        }, error => {
          this.isDataAvailable = false;
          console.log(error, this.isDataAvailable);
        });
      // params
      // this.eddate = sessionStorage.getItem('cenddate');
      this.router.navigate(['/new-business', `${this.selected}`,
        `${moment(this.startDate).format('YYYYMMDD')}`,
        `${moment(this.endDate).format('YYYYMMDD')}`]);
      console.log('NB', this.route.snapshot.paramMap.get('policy'));
      // Current Policy
    } else if (this.selected === 'Accept. Letters Expiring') {
      this.isClearActive = true;
      this.datePeriod = `in 30 days`;
      this.nbservice.getAcceptLetterExpired(
        localStorage.getItem('userId'),
        (this.startDateAccept.format('YYYYMMDD')),
        (this.endDateAccept.format('YYYYMMDD'))
      )
        .subscribe(data => {
          // loader hide
          if (data.length === 0) {
            this.isDataAvailable = false;
          } else {
            this.isDataAvailable = true;
          }
          this.isDataLoaded = true;

          // rewrite the json data start
          const reWriteData = data.map(res => {
            if (res.LastName == null) {
              res.LastName = '';
            }
            if (res.FirstName == null) {
              res.FirstName = '';
            }
            if (res.MiddleName == null) {
              res.MiddleName = '';
            }
            return {
              Policy_Number: res.PolicyNumber,
              Status: res.Status,
              Product_Name: res.Product,
              Insured_Name: (res.LastName + ' ' + res.FirstName + ' ' + res.MiddleName).trim(),
              Sum_Assured: res.SumAssured,
              Producer_Name: res.ProducerName
            };
          });
          // rewrite the json data end
          this.isloading = false;
          this.dataSource = new MatTableDataSource(reWriteData);
          this.datalength = data.length;
          this.resutlDatalength = data.length;
          if (this.resutlDatalength >= 1) {
            // this.reslutDataCount = ('0' + this.resutlDatalength).slice(-3);
            this.reslutDataCount = this.leadingZero(this.resutlDatalength);
          } else {
            this.reslutDataCount = '0';
          }
          this.dataSource.sort = this.sort;
          this.dataSource.paginator = this.paginator;
          console.log(this.datalength);
          // for modal array status pass
          this.modalStatus = [...Array.from(new Set(data.map(res => res.Status)))];
          this.productName = [...Array.from(new Set(data.map(res => res.Product)))];
          console.log('modal array pass', data);
        }, error => {
          this.isDataAvailable = false;
          console.log(error, this.isDataAvailable);
        });
      // params
      this.router.navigate(['/new-business',
        `${this.selected}`, `${this.startDateAccept.format('YYYYMMDD')}`,
        `${this.endDateAccept.format('YYYYMMDD')}`]);
      console.log('NB', this.route.snapshot);
    } else if (this.selected === 'Long Pending Cases') {
      this.datePeriod = `Close in 30 days`;
      this.isClearActive = true;
      this.nbservice.getLongPendingCases(
        localStorage.getItem('userId')
      )
        .subscribe(data => {
          // loader hide
          if (data.length === 0) {
            this.isDataAvailable = false;
          } else {
            this.isDataAvailable = true;
          }
          this.isDataLoaded = true;
          // rewrite the json data start
          const reWriteData = data.map(res => {
            if (res.LastName == null) {
              res.LastName = '';
            }
            if (res.FirstName == null) {
              res.FirstName = '';
            }
            if (res.MiddleName == null) {
              res.MiddleName = '';
            }
            return {
              Policy_Number: res.PolicyNumber,
              Status: res.Status,
              Product_Name: res.Product,
              Insured_Name: (res.LastName + ' ' + res.FirstName + ' ' + res.MiddleName).trim(),
              Sum_Assured: res.SumAssured,
              Producer_Name: res.ProducerName
            };
          });
          // rewrite the json data end
          this.isloading = false;
          this.dataSource = new MatTableDataSource(reWriteData);
          this.datalength = data.length;
          this.resutlDatalength = data.length;
          if (this.resutlDatalength >= 1) {
            // this.reslutDataCount = ('0' + this.resutlDatalength).slice(-3);
            this.reslutDataCount = this.leadingZero(this.resutlDatalength);
          } else {
            this.reslutDataCount = '0';
          }
          this.dataSource.sort = this.sort;
          this.dataSource.paginator = this.paginator;
          console.log(this.datalength);

          // for modal array status pass
          this.modalStatus = [...Array.from(new Set(data.map(res => res.Status)))];
          this.productName = [...Array.from(new Set(data.map(res => res.Product)))];
          console.log('modal array pass', this.modalStatus);
        }, error => {
          this.isDataAvailable = false;
          console.log(error, this.isDataAvailable);
        });
      // params
      this.router.navigate(['/new-business', `${this.selected}`]);
      console.log('NB', this.route.snapshot);
    }
  }


  syncPrimaryPaginator(event: PageEvent) {
    this.paginator.pageIndex = event.pageIndex;
    this.paginator.pageSize = event.pageSize;
    this.paginator.page.emit(event);
  }

  getDropdownValue() {
    this.nbservice.setMessage().subscribe(data => {
      this.selected = data;
    });
  }

  getCaseIssued() {
    this.nbservice.setMessageCaseIssued().subscribe(data => {
      this.startDate = data.startDate;
      this.endDate = data.endDate;
    });
  }
  applyFilter(filterValue: string) {
    this.pageloadstart = false;
    this.dataSource.filter = filterValue.trim().toLowerCase();
    this.resutlDatalength = this.dataSource.filteredData.length;
    if (this.resutlDatalength >= 1) {
      // this.reslutDataCount = ('0' + this.resutlDatalength).slice(-3);
      this.reslutDataCount = this.leadingZero(this.resutlDatalength);
    } else {
      this.reslutDataCount = '0';
    }
    this.isClearActive = false;
    console.log(this.dataSource.filteredData.length);
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }


}
