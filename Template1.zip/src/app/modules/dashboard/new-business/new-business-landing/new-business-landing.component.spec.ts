import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewBusinessLandingComponent } from './new-business-landing.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AuthService } from '@app/core/authentication/auth.service';
import { AppConstants } from '@app/app.constants';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { NewbusinessService } from '@app/core/services/newbusiness/newbusiness.service';
import { MatTableModule, MatDialogModule } from '@angular/material';
import { ActivatedRoute } from '@angular/router';

describe('NewBusinessLandingComponent', () => {
  let component: NewBusinessLandingComponent;
  let fixture: ComponentFixture<NewBusinessLandingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewBusinessLandingComponent ],
      imports: [
        BrowserAnimationsModule,
         BrowserDynamicTestingModule,
          RouterTestingModule,
           HttpClientTestingModule, MatTableModule, MatDialogModule ],
      providers: [AuthService, AppConstants, NewbusinessService, {
        provide: ActivatedRoute, useValue: {
           snapshot: { url: { path: 0 } }
        }
      }, ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewBusinessLandingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // it('should create', () => {
  //   expect(component).toBeTruthy();
  // });
});
