import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NbpolicydetailsComponent } from './nbpolicydetails.component';
import { AuthService } from '@app/core/authentication/auth.service';
import { AppConstants } from '@app/app.constants';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';

describe('NbpolicydetailsComponent', () => {
  let component: NbpolicydetailsComponent;
  let fixture: ComponentFixture<NbpolicydetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NbpolicydetailsComponent ],
      providers: [AuthService, AppConstants],
      imports: [ BrowserAnimationsModule, BrowserDynamicTestingModule, RouterTestingModule, HttpClientTestingModule],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NbpolicydetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
