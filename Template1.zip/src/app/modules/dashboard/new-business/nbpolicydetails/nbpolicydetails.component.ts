import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AppConstants } from '@app/app.constants';
import { NewbusinessService } from '@app/core/services/newbusiness/newbusiness.service';
import { NewBusinessPolicy } from '@app/shared/models/newbusiness';
import jsPDF from 'app/jspdf/jspdf.min.js';
var jsPDF = require('jspdf');
require('jspdf-autotable');
@Component({
  selector: 'app-nbpolicydetails',
  templateUrl: './nbpolicydetails.component.html',
  styleUrls: ['./nbpolicydetails.component.scss']
})
export class NbpolicydetailsComponent implements OnInit {
  downloadIcon = this.app.downloadIcon;
  emailBlackIcon = this.app.emailBlackIcon;
  printIcon = this.app.printIcon;
  downloadIcon2x = this.app.downloadIcon2x;


  applicationNumber = this.app.applicationNumber;
  status = this.app.status;
  policyinsuredName = this.app.insuredName;
  sumInsure = this.app.sumInsure;
  premiumTerm = this.app.premiumTerm;
  submissionDate = this.app.submissionDate;
  underwritingRiskClass = this.app.underwritingRiskClass;
  producerId = this.app.producerId;
  policyNumber = this.app.policyNumber;
  productName = this.app.productName;
  ownerName = this.app.ownerName;
  policypremiumAmount = this.app.premiumAmount;
  premiumPaymentFrequency = this.app.premiumPaymentFrequency;
  producerName = this.app.producerName;
  acceptLetterGenDate = this.app.acceptLetterGenDate;
  acceptLetterExpDate = this.app.acceptLetterExpDate;
  constructor(
    private app: AppConstants,
    private activatedRoute: ActivatedRoute,
    private newbusinessService: NewbusinessService,
    private route: Router
  ) { }
  panelOpenState = false;
  tabsVertical = true;
  flexboxifiedContent = false;
  additionalTabHeads: any[];
  detailslist: any = [];
  GetPolicyNumber: string;
  email: string;
  phonenum: string;
  data: NewBusinessPolicy;

  ngOnInit() {
    this.additionalTabHeads = [];
    this.GetPolicyNumber = this.activatedRoute.snapshot.paramMap.get('Policy_Number');
    this.getdetails();
  }

  getback() {
    this.route.navigate(['/new-business', 'View Complete List', 'all']);
  }

  getdetails() {
    this.newbusinessService.getnbpolicydetails((localStorage.getItem('userId')),
      this.GetPolicyNumber).subscribe((res: NewBusinessPolicy) => {
        console.log(res);
        // hard code to add fields.
        const displayObj: any = res;
        displayObj.InsuredName = res.LastName.trim() + ' ' + res.FirstName.trim() + ' ' + res.MiddleName.trim();
        displayObj.OwnerName = res.PolicyOwnerLastName.trim() + ' ' + res.PolicyOwnerFirstName.trim() + res.PolicyOwnerMiddleName.trim();

        this.detailslist.push(displayObj);

        this.data = displayObj;
      });
  }

  printMode() {
    const printContents = document.getElementById('printfn').innerHTML;
    const popupWin = window.open('', '_blank', 'width=1800,scrollbars=no,menubar=no,toolbar=no,location=no,status=no,titlebar=no,top=50');
    popupWin.window.focus();
    popupWin.document.open();
    popupWin.document.write('<!DOCTYPE html><html><head><title> Policy Summary' + this.GetPolicyNumber  + '</title>'
    + '<link rel="stylesheet" href="../assets/scss/print.css">'
    + '</head><body><div class="main_body"><div class="header"><img src="../assets/images/pdf/header.png"></div>'
    + '<div class="policynum">  <h6> Policy Summary <span>' + this.GetPolicyNumber   + '</span> </h6> </div>'
    + printContents + '<div class="footer">IMPORTANT NOTE: The data presented on this site may not be'
    + 'relied upon to verify the status of or benefits payable under any policy.'
    + 'Please contact our Customer Services Team by phone at (65) 6212 0620 or by'
    + 'e-mail at customerservicesg@transamerica.com for information relating to this policy. </div></div></body></html>');
    popupWin.document.close();
    setTimeout( () => {
      popupWin.window.print();
    }, 1000);
  }

  capture() {
    const doc1 = new jsPDF('p', 'mm', 'a4');
    const dataimg = this.app.dataimg;
    const total_pdf_pages = doc1.internal.pages;
    doc1.addImage(dataimg, 'png', 0, 0, 220, 18);
    doc1.setFillColor(217, 217, 217);
    doc1.rect(0, 25, 80, 12, 'F');
    doc1.setTextColor(4, 4, 4);
    doc1.setFontSize(12);
    doc1.text(5, 33, 'Policy Summary' + ' ' + this.GetPolicyNumber);

  // Policy Information first row  NON UL
     doc1.setFillColor(217, 217, 217);
     doc1.rect(5, 50, 190, 12, 'F');
     doc1.text('Policy Information', 7, 55);

     const poliycolumn = [
      { title: 'Policy Number', dataKey: 'PolicyNumber' },
      { title: 'Status', dataKey: 'StaTs' },
      { title: 'Policy Insured Date', dataKey: 'PolicyInsDate' },
      { title: 'Sum Insure', dataKey: 'SumIns' },
      { title: 'Premium Term', dataKey: 'PreTer' },
      { title: 'Producer Id', dataKey: 'ProId' },
      { title: 'Submission Date', dataKey: 'SubDat' },
      { title: 'Under Writing RiskClass', dataKey: 'UnWrRisk' }
    ];

    const policyrow = this.detailslist;
    const policyrowsarr = [];
    policyrow.forEach(element => {
      if (element.PolicyNumber === undefined || element.PolicyNumber === null) {
        element.PolicyNumber = ' ';
      }
      if (element.Status === undefined || element.Status === null) {
        element.Status = ' ';
      }
      if (element.InsuredName === undefined || element.InsuredName === null) {
        element.InsuredName = ' ';
      }
      if (element.SumAssured === undefined || element.SumAssured === null) {
        element.SumAssured = ' ';
      }
      if (element.PremiumTerm === undefined || element.PremiumTerm === null) {
        element.PremiumTerm = ' ';
      }
      if (element.ProducerId === undefined || element.ProducerId === null) {
        element.ProducerId = ' ';
      }
      if (element.ApplicationSignDate === undefined || element.ApplicationSignDate === null) {
        element.ApplicationSignDate = ' ';
      }
      if (element.UWClass === undefined || element.UWClass === null) {
        element.UWClass = ' ';
      }
      const policynum = { 'PolicyNumber': element.PolicyNumber };
      const stat = { 'StaTs': element.Status };
      const insname = { 'PolicyInsDate': element.InsuredName };
      const sumass = { 'SumIns': element.SumAssured };
      const preterm = { 'PreTer': element.PremiumTerm };
      const proid = { 'ProId': element.ProducerId };
      const appsigndat = { 'SubDat': element.ApplicationSignDate };
      const uwcl = { 'UnWrRisk': element.UWClass };
      const merge = Object.assign(policynum, stat, insname, sumass, preterm, proid, appsigndat, uwcl);
      policyrowsarr.push(merge);
    });

    doc1.autoTable(poliycolumn, policyrowsarr, {
      theme: 'plain',
      tableWidth: 'auto',
      margin: { top: 63, left: 5 },
      bodyStyles: { fillColor: 255, textColor: 37, valign: 'top', lineWidth: 0.1, lineColor: [247, 246, 246] },
      pagesplit: true,
      headerStyles: { fillColor: 217, textColor: 37, halign: 'left',  lineWidth: 0.1, lineColor: [247, 246, 246] },
      styles: { overflow: 'linebreak', overflowColumns: false, fontSize: 8, lineWidth: 0.1, lineColor: [247, 246, 246] },
      columnWidth: 'wrap',
      columnStyles: {
      }

    });

    const poliyseccolumn = [
      { title: 'Product Name', dataKey: 'prodnam' },
      { title: 'Owner Name', dataKey: 'owname' },
      { title: 'Policy Premium Amount', dataKey: 'popreamt' },
      { title: 'Premium Payment Frequency', dataKey: 'prepayfre' },
      { title: 'Producer Name', dataKey: 'proname' },
      { title: 'Accept Letter GenDate', dataKey: 'acclettgen' },
      { title: 'Accept Letter ExpDate', dataKey: 'accletexp' },
    ];

    const policysecrow = this.detailslist;
    const policysecrowsarr = [];

    policysecrow.forEach(element => {
      if (element.Product === undefined || element.Product === null) {
        element.Product = ' ';
      }
      if (element.OwnerName === undefined || element.OwnerName === null) {
        element.OwnerName = ' ';
      }
      if (element.PremiumAmount === undefined || element.PremiumAmount === null) {
        element.PremiumAmount = ' ';
      }
      if (element.PremiumPaymentFrequency === undefined || element.PremiumPaymentFrequency === null) {
        element.PremiumPaymentFrequency = ' ';
      }
      if (element.ProducerName === undefined || element.ProducerName === null) {
        element.ProducerName = ' ';
      }
      if (element.AcceptanceLetterGenerationDate === undefined || element.AcceptanceLetterGenerationDate === null) {
        element.AcceptanceLetterGenerationDate = ' ';
      }
      if (element.AcceptanceLetterExpirynDate === undefined || element.AcceptanceLetterExpirynDate === null) {
        element.AcceptanceLetterExpirynDate = ' ';
      }
      const policynum = { 'prodnam': element.Product };
      const stat = { 'owname': element.OwnerName };
      const insname = { 'popreamt': element.PremiumAmount };
      const sumass = { 'prepayfre': element.PremiumPaymentFrequency };
      const preterm = { 'proname': element.ProducerName };
      const proid = { 'acclettgen': element.AcceptanceLetterGenerationDate };
      const appsigndat = { 'accletexp': element.AcceptanceLetterExpirynDate };
      const merge = Object.assign(policynum, stat, insname, sumass, preterm, proid, appsigndat);
      policysecrowsarr.push(merge);
    });

    doc1.autoTable(poliyseccolumn, policysecrowsarr, {
      theme: 'plain',
      tableWidth: 'auto',
      margin: { top: 63, left: 5 },
      bodyStyles: { fillColor: 255, textColor: 37, valign: 'top', lineWidth: 0.1, lineColor: [247, 246, 246] },
      pagesplit: true,
      headerStyles: { fillColor: 217, textColor: 37, halign: 'left',  lineWidth: 0.1, lineColor: [247, 246, 246] },
      styles: { overflow: 'linebreak', overflowColumns: false, fontSize: 8, lineWidth: 0.1, lineColor: [247, 246, 246] },
      columnWidth: 'wrap',
      columnStyles: {
      }

    });

    const detailsList = JSON.parse(localStorage.getItem('policyDetails'));
    if (detailsList[0].issuestate === 'HK') {
      this.email = 'customerservicehk@transamerica.com';
      this.phonenum = '(852) 2506 0311';
    } else if (detailsList[0].issuestate === 'SG') {
      this.email = 'customerservicesg@transamerica.com';
      this.phonenum = '(65) 6212 0620';
    } else if (detailsList[0].issuestate === 'BM') {
      this.email = 'customerservicebm@transamerica.com';
      this.phonenum = '(441) 278 8557';
    }

    const myFooter = doc1.splitTextToSize(`IMPORTANT NOTE:` + `The data presented on this site may not be relied upon to verify` +
      // tslint:disable-next-line: max-line-length
      `the status of or benefits payable under any policy. Please contact our Customer Services Team (by phone at ` + this.phonenum  + ` or by e-mail at ` + this.email + `) ` +
      `for information relating to this policy`, 260);
    for (let i = 1; i < total_pdf_pages.length; i++) {
      doc1.setPage(i);
      doc1.setFontSize(9);
      doc1.setTextColor(111, 111, 111);
      const st = 'Page' + '-' + i;
      doc1.setFontSize(9);
      doc1.text(198, 278, st);
      if(i == total_pdf_pages.length - 1) {
      doc1.setFillColor(231, 233, 234);
      doc1.rect(0, 280, 320, 18, 'F');  
      doc1.text(5, 286, myFooter);
      }
    }
    doc1.save('Policy_Summary_' + this.GetPolicyNumber + '.pdf');

  }
}
