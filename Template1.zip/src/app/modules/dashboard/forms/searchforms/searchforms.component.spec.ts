import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchformsComponent } from './searchforms.component';

describe('SearchformsComponent', () => {
  let component: SearchformsComponent;
  let fixture: ComponentFixture<SearchformsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchformsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchformsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
