import { CreatepackageComponent } from './../../../../components/createpackage/createpackage.component';
import { LaserficheService } from './../../../../core/services/laserfiche/laserfiche.service';
import { EmailsuccessComponent } from '@app/components/emailsuccess/emailsuccess.component';
import { EmailformsComponent } from '@app/components/emailforms/emailforms.component';
import { Component, OnInit, ViewEncapsulation, ViewChild, Renderer2, Inject, ElementRef, OnDestroy, AfterViewChecked } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { InforceService } from '@services/inforce/inforce.service';
import { AppConstants } from '@app/app.constants';
import { SelectionModel } from '@angular/cdk/collections';
import { Router, ActivatedRoute } from '@angular/router';
import { MatPaginator, MatSort, MatTableDataSource, PageEvent, MatDialog, matTabsAnimations } from '@angular/material';
import { FormsdialogComponent } from '../formsdialog/formsdialog.component';
import { FormsutilityService } from '@services/formsutility/formsutility.service';
import { saveAs } from 'file-saver';
import { ChangeDetectorRef } from '@angular/core';
@Component({
  selector: 'app-searchforms',
  templateUrl: './searchforms.component.html',
  styleUrls: ['./searchforms.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class SearchformsComponent implements OnInit, AfterViewChecked {
  selectedoption = 'Please Select';
  search = this.app.search;
  searchResult = this.app.searchResult;
  pleaseSelect = this.app.pleaseSelect;
  policyNumber = this.app.policyNumber;
  clientName = this.app.clientName;
  InsuredDOB = this.app.InsuredDOB;
  policyStatus = this.app.policyStatus;
  dueDate = this.app.dueDate;
  premiumDueDate = this.app.premiumDueDate;
  producerId = this.app.producerId;
  sortingImg = this.app.sortingImg;
  downloadIconGrey = this.app.downloadIconGrey;
  printIconGrey = this.app.printIconGrey;
  emailIconGrey = this.app.emailIconGrey;
  saveIcon = this.app.saveIconGrey;
  packageIcon = this.app.packageIcon;
  backArrowImg = this.app.backArrowIcon;
  backArrowMobileImg = this.app.backArrowMobileIcon;
  downloadApiParams: string;
  showdefault = false;
  displayedColumns_list = ['select', 'Version'];

  isLoadingResults: boolean;


  isSaveActive = false;
  isDataAvailable = false;

  dataCount = 0;
  getCountry: string
  currentuserCountry: string;
  country: string;
  data = [];
  branchData = [];
  data_Source = new MatTableDataSource(this.data);
  selection = new SelectionModel(true, []);
  emailApiParams: string;
  constructor(
    private router: Router,
    private app: AppConstants,
    public dialog: MatDialog,
    private laserfiche: LaserficheService,
    private formsPackage: FormsutilityService,
    private render: Renderer2,
    private cdRef: ChangeDetectorRef,
    @Inject(DOCUMENT) private document: Document,
    private route: ActivatedRoute) { }
  ngAfterViewChecked() {
    this.cdRef.detectChanges();
  }
  ngOnInit() {
    this.laserfiche.setMessage().subscribe(data => {
      data.length !== 0 ? this.isDataAvailable = true : this.isDataAvailable = false;
      this.dataCount = data.length;
      this.data_Source = new MatTableDataSource(data);
    });
    this.route.queryParams.subscribe(params => {
      this.data = params.data;
      console.log('params data details', params, 'data', params.data);
    });
    console.log('is data available', this.isDataAvailable);
    this.render.addClass(this.document.body, 'searchform-body');
    // this.currentuserCountry = localStorage.getItem('Country')
    // this.getcurrentusercuntry();
  }
  // tslint:disable-next-line: use-life-cycle-interface
  ngOnDestroy(): void {
    this.render.removeClass(this.document.body, 'searchform-body');
  }
  // getcurrentusercuntry() {
  //   if (this.currentuserCountry == 'Hong Kong') {
  //     this.country = 'HK';
  //   }
  //   if (this.currentuserCountry == 'Singapore') {
  //     this.country = 'SG';
  //   }
  //   if (this.currentuserCountry == 'Bermuda') {
  //     this.country = 'BN';
  //   }
  // }

  isAllSelected() {
    const numSelected = this.selection.selected.length;
    console.log('numSelected', numSelected);
    const numRows = this.data_Source.data.length;
    // console.log('selected count', numSelected);
    if (numSelected !== 0) {
      this.isSaveActive = true;
      this.emailIconGrey = this.app.emailIconColor;
      this.downloadIconGrey = this.app.downloadIconColor;
      this.saveIcon = this.app.saveIcon;
    } else if (numSelected === 0) {
      this.isSaveActive = false;
      this.emailIconGrey = this.app.emailIconGrey;
      this.downloadIconGrey = this.app.downloadIconGrey;
      this.saveIcon = this.app.saveIconGrey;
    }
    return numSelected === numRows;
  }


  masterToggle() {
    this.isAllSelected() ?
      this.selection.clear() :
      this.data_Source.data.forEach(row => this.selection.select(row));
    console.log('test check box', this.data);
  }
  /** The label for the checkbox on the passed row */
  checkboxLabel(row?: Element): string {
    if (!row) {
      return `${this.isAllSelected() ? 'select' : 'deselect'} all`;
    }
  }

  // for dialog open
  openDialog(): void {
    const dialogRef = this.dialog.open(FormsdialogComponent, {
      panelClass: 'forms-dialog-modal',
    });

    // dialogRef.afterClosed().subscribe(result => {
    //   console.log('Search', this.data_Source);
    // });
    dialogRef.afterClosed().subscribe(result => {
      this.branchData = result;
      console.log('result details', this.branchData);
      const documentName = '';
      let country = '';
      if (result.branchOffice == 'Hong Kong') {
        country = 'HK';
        localStorage.setItem('getcountry', country);
      } else if (result.branchOffice == 'Singapore') {
        country = 'SG';
        localStorage.setItem('getcountry', country);
      } else if (result.branchOffice == 'Bermuda') {
        country = 'BM';
        localStorage.setItem('getcountry', country);
      }
      const packageFile = 'No';
      const productName = '';
      this.laserfiche.dashBoardLaserfiche(documentName, country, packageFile, productName)
        .subscribe(data => {
          data.length !== 0 ? this.isDataAvailable = true : this.isDataAvailable = false;
          this.dataCount = data.length;
          this.data_Source = new MatTableDataSource(data);
        });
    });
  }

  downloadForms() {
    this.country = localStorage.getItem('getcountry');
    this.isLoadingResults = true;
    /* Downloading as PDF IF one item is seleted */
    if (this.selection.selected.length === 1) {
      let pdfName = '';
      this.formsPackage.extractFormbyDoc(this.country, this.selection.selected[0].DocumentName).subscribe(res => {
        if (res) {
          this.isLoadingResults = false;
        }
        pdfName = this.selection.selected[0].DocumentName + '.pdf';
        saveAs(res, pdfName);
      });
    } else {
      this.downloadApiParams = '';
      let i = 0;
      this.selection.selected.forEach(element => {
        this.downloadApiParams = this.downloadApiParams + 'docNames[' + i + ']=' + element.DocumentName + '&';
        i++;
      });
      this.formsPackage.searchDownloadForms(this.country,this.downloadApiParams.slice(0, -1)).subscribe(res => {
        this.showdefault = false;
        if (res) {
          this.isLoadingResults = false;
        }
        const pdfObj = new Blob([res], { type: '	application/zip' });
        saveAs(res, 'package.zip');
      },
        err => {
          console.log(err);
        }
      );
    }
  }
  // email forms dialog
  emailForms() {
    const dialogRef = this.dialog.open(EmailformsComponent, {
      panelClass: 'email-dialog-modal',
      data: this.selection.selected.length,
    });


    dialogRef.afterClosed().subscribe(result => {
      if (result === undefined) {
        this.isLoadingResults = false;
      } else {
        this.isLoadingResults = true;
        let i = 0;
        this.emailApiParams = '';
        this.selection.selected.forEach(element => {
          this.emailApiParams = this.emailApiParams + 'docNames[' + i + ']=' + element.DocumentName + '&';
          i++;
        });
        const str =
          'recipient=' + result.emailID +
          '&Body=' + result.textMessage +
          '&Subject=' + result.subject +
          '&' + this.emailApiParams.slice(0, -1);
        this.formsPackage.emailForms(this.country, str).subscribe(res => {
          // tslint:disable-next-line: triple-equals
          if (res) {
            this.isLoadingResults = false;
          }
          if (res === 'Email sent successfully') {
            this.successDialog();
          }
        },
          err => {
            console.log(err.error);
          });
      }
    });
  }

  // for dialog open
  successDialog(): void {
    const dialogRef = this.dialog.open(EmailsuccessComponent, {
      panelClass: 'success-dialog-modal',
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('success', this.data_Source);
    });
  }


  // save package dialog
  openSaveDialog(): void {
    console.log('dialog open values', this.selection.selected);
    const dialogRef = this.dialog.open(CreatepackageComponent, {
      panelClass: 'search-dialog-modal',
      data: this.selection.selected,

    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed', result);
    });
  }

}
