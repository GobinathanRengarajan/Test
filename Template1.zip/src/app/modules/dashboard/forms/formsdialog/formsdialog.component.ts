
import { Component, OnInit, Renderer2, Inject, OnDestroy, ViewEncapsulation } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FormControl, FormGroup, FormArray, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { AppConstants } from '@app/app.constants';
import { FormslandingComponent } from '../formslanding/formslanding.component';
export interface DialogData {
  modalStatus: string[];
  productName: string[];
}

@Component({
  selector: 'app-formsdialog',
  templateUrl: './formsdialog.component.html',
  styleUrls: ['./formsdialog.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class FormsdialogComponent implements OnInit, OnDestroy {
  // icons
  closeIcon = this.app.closeIcon;
  close_model = this.app.close_model;

  locations = ['Hong Kong', 'Singapore', 'Bermuda'];
  selected = 'option1';

  // dropdown
  searchForm = new FormGroup({
    branchOffice: new FormControl('', [Validators.required]),
    productType: new FormControl({ value: 'ALL', disabled: true }),
    productName: new FormControl({ value: 'N/A', disabled: true }),
  });

  branchOffice() { return this.searchForm.get('branchOffice'); }

  constructor(
    private app: AppConstants,
    private render: Renderer2,
    public dialogRef: MatDialogRef<FormslandingComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData,
    private _route: ActivatedRoute,
    private _router: Router,
    @Inject(DOCUMENT) private document: Document
  ) { }

  ngOnInit() {
    this.render.addClass(this.document.body, 'formsdialog-body');
  }

  ngOnDestroy(): void {
    this.render.removeClass(this.document.body, 'formsdialog-body');
  }

  onNoClick(): void {
    this.dialogRef.close();
  }
}
