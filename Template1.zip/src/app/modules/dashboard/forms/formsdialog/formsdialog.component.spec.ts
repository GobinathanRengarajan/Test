import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FormsdialogComponent } from './formsdialog.component';

describe('FormsdialogComponent', () => {
  let component: FormsdialogComponent;
  let fixture: ComponentFixture<FormsdialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FormsdialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FormsdialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
