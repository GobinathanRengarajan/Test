
import { Component, OnInit, Renderer2, Inject, OnDestroy, ViewEncapsulation } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { AppConstants } from '@app/app.constants';
import { LaserficheService } from '@app/core/services/laserfiche/laserfiche.service';
import { Observable } from 'rxjs';
import { MatDialog, MatTableDataSource } from '@angular/material';
import { saveAs } from 'file-saver';
import { EmailsuccessComponent } from '@app/components/emailsuccess/emailsuccess.component';
import { EmailformsComponent } from '@app/components/emailforms/emailforms.component';
import { FormsutilityService } from '@services/formsutility/formsutility.service';

@Component({
  selector: 'app-forms',
  templateUrl: './forms.component.html',
  styleUrls: ['./forms.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class FormsComponent implements OnInit, OnDestroy {

  title = this.app.formsTitle;
  threedotIcon = this.app.threedotIcon;
  documentName: string;
  country: string;
  packagefile: string;
  productname: string;
  currentuserCountry: string;
  getLaserfiecheData: any;
  getPdfData: any;
  isLoadingResults: boolean;
  data_Source = new MatTableDataSource<any>();
  constructor(public dialog: MatDialog,
    private app: AppConstants,
    private laserficheservice: LaserficheService,
    private formsPackage: FormsutilityService,
    private render: Renderer2,
    @Inject(DOCUMENT) private document: Document,
  ) { }


  ngOnInit() {
    this.getFormDetails();
    this.render.addClass(this.document.body, 'formsmain-body');
    this.currentuserCountry = localStorage.getItem('Country')
    this.getcurrentusercuntry();
  }
  ngOnDestroy(): void {
    this.render.removeClass(this.document.body, 'formsmain-body');
  }
  getcurrentusercuntry()
  {
    if (this.currentuserCountry == 'Hong Kong') {
      this.country = 'HK';
    }
    if (this.currentuserCountry == 'Singapore') {
      this.country = 'SG';
    }
    if (this.currentuserCountry == 'Bermuda') {
      this.country = 'BN';
    }
  }

  downloadPdf(pdfFile) {
    this.isLoadingResults = true;
    this.laserficheservice.extractFormbyDoc(pdfFile, this.country).subscribe(res => {
      if (res) {
        this.isLoadingResults = false;
      }
      pdfFile = pdfFile + '.pdf';
      saveAs(res, pdfFile);
    },
      error => {
        alert('No file found');
        this.isLoadingResults = false;
      }
    );
  }

  openPdf(pdfFile) {
    this.laserficheservice.extractFormbyDoc(pdfFile, this.country).subscribe(res => {

      if (window.navigator && window.navigator.msSaveOrOpenBlob) {
        window.navigator.msSaveOrOpenBlob(res, pdfFile + '.pdf');
      } else {
        const pdfObj = new Blob([res], { type: 'application/pdf' });
        const fileURL = URL.createObjectURL(pdfObj);
        window.open(fileURL);
      }
    },
      error => {
        alert('No file found');
        this.isLoadingResults = false;
      });
  }

  emailForms(pdfFile) {
    const dialogRef = this.dialog.open(EmailformsComponent, {
      panelClass: 'email-dialog-modal',
      data: 1,
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result === undefined) {
        this.isLoadingResults = false;
      } else {
        this.isLoadingResults = true;
        const str =
          'recipient=' + result.emailID +
          '&Body=' + result.textMessage +
          '&Subject=' + result.subject +
          '&' + 'docNames[0]=' + pdfFile;

        this.formsPackage.emailForms(this.country,str).subscribe(res => {
          if (res) {
            this.isLoadingResults = false;
          }
          // tslint:disable-next-line: triple-equals
          if (res == 'Email sent successfully') {
            this.successDialog();
          }
        },
          err => {
            console.log(err.error);
          });
      }
    },
      error => {
        alert('No file found');
        this.isLoadingResults = false;
      });
  }
  // for dialog open
  successDialog(): void {
    const dialogRef = this.dialog.open(EmailsuccessComponent, {
      panelClass: 'success-dialog-modal',
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('success', this.data_Source);
    });
  }

  getFormDetails() {
    this.documentName = '';
    this.country = 'HK';
    this.packagefile = 'No';
    this.productname = '';
    this.laserficheservice.searchLaserfiche(this.documentName,
      this.country,
      this.packagefile,
      this.productname).subscribe(data => {
        this.getLaserfiecheData = [];
        this.getLaserfiecheData.push(data[0]);
        this.getLaserfiecheData.push(data[1]);
        this.getLaserfiecheData.push(data[2]);
      });
  }
}
