import { EmailsuccessComponent } from './../../../../../components/emailsuccess/emailsuccess.component';
import { saveAs } from 'file-saver';
import { AreyousureDialogueComponent } from './../../../../../components/areyousure-dialogue/areyousure-dialogue.component';
import { AppConstants } from '@app/app.constants';
import { FormsutilityService } from '@app/core/services/formsutility/formsutility.service';
import { SelectionModel, DataSource } from '@angular/cdk/collections';
import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { MatTableDataSource, MatDialog } from '@angular/material';
import { Observable, of } from 'rxjs';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { EmailformsComponent } from '@app/components/emailforms/emailforms.component';

@Component({
  selector: 'app-custom-package',
  templateUrl: './custom-package.component.html',
  styleUrls: ['./custom-package.component.scss'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0', visibility: 'hidden' })),
      state('expanded', style({ height: '*', visibility: 'visible' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
  encapsulation: ViewEncapsulation.None
})
export class CustomPackageComponent implements OnInit {

  mypackage = this.app.mypackage;
  sortingImg = this.app.sortingImg;
  // download icon
  downloadIconGrey = this.app.downloadIconGrey;
  myPackageDownloadIcon = this.app.downloadIconGrey;
  // email icon
  emailIconGrey = this.app.emailIconGrey;
  myPackageEmailIcon = this.app.emailIconGrey;
  // delete icon
  deleteIconGrey = this.app.deleteIconGrey;
  deleteIconColor = this.app.deleteIconColor;
  myPackageDeleteIcon = this.app.deleteIconGrey;

  displayedColumns: string[] = ['select', 'no_of_forms', 'Last_updated', 'View_options'];
  // tslint:disable-next-line: no-use-before-declare
  dataSource = new ExpandableDataSource();
  selection = new SelectionModel<any>(true, []);

  expandedElement: any;
  getPartialId: any;
  isSaveActive = false;
  isViewForms = true;
  checked = false;

  isAllFormsChecked = false;
  isEnableIcon = false;

  getPreselectedFormsChecked = false;

  // loading
  isLoadingResults: boolean;

  // total forms count for mail dialog modal
  packageFormsCount = 0;
  expandFormsCount = 0;


  // expand toggle get value
  expandId;
  expandFormsName;
  expandEvent;
  preSelectedForms = [];

  // delete confirmation dialogue box
  confirmationText = this.app.deleteConfirmationText;

  // view forms
  viewFormsData = [];
  selectedForms = [];
  formsList = [];
  deleteForms = [];
  partialPackage: any;
  isActive: any;

  // selectedPackageId: number;
  viewFormsPackageId: number;
  isPacakgeCheckboxID = [];
  stringToParams: any;
  mailFormParams: any;
  country: string;
  currentuserCountry: string;

  constructor(
    private formsPackage: FormsutilityService,
    private app: AppConstants,
    public dialog: MatDialog
  ) { }
  ngOnInit() {
    console.log('custom package name');
    this.getCustomPackage();
    this.currentuserCountry = localStorage.getItem('Country')
    this.getcurrentusercuntry();
  }
  getcurrentusercuntry() {
    if (this.currentuserCountry == 'Hong Kong') {
      this.country = 'HK';
    }
    if (this.currentuserCountry == 'Singapore') {
      this.country = 'SG';
    }
    if (this.currentuserCountry == 'Bermuda') {
      this.country = 'BN';
    }
  }
  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRowss = this.dataSource.data.length;
    if (numSelected !== 0 || this.isEnableIcon === true) {
      this.isSaveActive = true;
      this.emailIconGrey = this.app.emailIconColor;
      this.downloadIconGrey = this.app.downloadIconColor;
      this.deleteIconGrey = this.app.deleteIconColor;
    } else if (numSelected === 0 || this.isEnableIcon === false) {
      this.isSaveActive = false;
      this.emailIconGrey = this.app.emailIconGrey;
      this.downloadIconGrey = this.app.downloadIconGrey;
      this.deleteIconGrey = this.app.deleteIconGrey;
    }
    const packageFormsCount = this.selection.selected.map(res => res.FormCount);
    this.packageFormsCount = packageFormsCount.reduce((a, b) => a + b, 0);
    // console.log('total selected values', this.packageFormsCount);
    // console.log(this.myPackageDownloadIcon);
    return numSelected === numRowss;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
      (this.selection.clear()) :
      this.dataSource.data.forEach(row => this.selection.select(row));
  }

  /** The label for the checkbox on the passed row */
  checkboxLabel(row?): string {
    if (!row) {
      return `${this.isAllSelected() ? 'select' : 'deselect'} all`;
    }
  }

  checkIsSelected(event, id) {
    console.log('is checked', event, id);
    // this.selectedPackageId = id;
    this.isPacakgeCheckboxID.push(id);
    this.isPacakgeCheckboxID = this.isPacakgeCheckboxID.filter((v, i, a) => a.indexOf(v) === a.lastIndexOf(v));
    console.log('is checked', event, id, this.viewFormsPackageId);
    id === this.viewFormsPackageId && event.checked === true ?
      this.isAllFormsChecked = true : this.isAllFormsChecked = false, this.preSelectedForms = [];
  }

  isExpansionDetailRow = (i: number, row: Object) => row.hasOwnProperty('detailRow');


  // API CALL
  // get all form package
  getCustomPackage() {
    this.formsPackage.getAllFormsPackages(localStorage.getItem('userId')).subscribe(data => {
      // tslint:disable-next-line: no-use-before-declare
      this.dataSource = new ExpandableDataSource();
      this.dataSource.data = data;
      // console.log(data, 'test after details', this.dataSource.data);
    });
  }

  // view forms
  viewForms(element) {
    this.isViewForms = true;
    this.viewFormsData = [];
    this.viewFormsPackageId = element;
    console.log('view forms', element, this.isPacakgeCheckboxID, this.isPacakgeCheckboxID.includes(element));
    if (this.isPacakgeCheckboxID.includes(element)) {
      this.isAllFormsChecked = true;
    } else {
      this.isAllFormsChecked = false;
    }
    this.formsPackage.getCustomPackageDetails(element).subscribe(data => {
      data ? this.isViewForms = false : this.isViewForms = true;
      this.viewFormsData = data.FormsList;
      // console.log('view forms list', this.viewFormsData, 'pre selected', this.preSelectedForms);

      // re assigned the object for preselected
      const hasChecked = new Set(this.preSelectedForms.map(res => res.Form_Name));
      this.viewFormsData = this.viewFormsData.map(res => ({ ...res, isChecked: hasChecked.has(res.Form_Name) }));
      // console.log('merged array list', this.viewFormsData);
    });

    // Remove duplicate values
    this.preSelectedForms = this.preSelectedForms.filter((thing, index) => {
      return index === this.preSelectedForms.findIndex(obj => {
        return JSON.stringify(obj) === JSON.stringify(thing);
      });
    });


  }

  // get selected forms value
  expandToggle(id, formsName, event) {
    const getSelectedFormsValue = {
      id: id,
      Form_Name: formsName,
      isChecked: event.checked
    };
    this.preSelectedForms.push(getSelectedFormsValue);
    console.log('get preselected values', this.preSelectedForms);
    console.log('is checked', event.checked);
    if (event.checked === true) {
      // console.log('package id', id, 'forms name', formsName);
      const selectedForms = {
        PackageID: id,
        FormsList: [{ Form_Name: formsName }]
      };
      this.selectedForms.push(selectedForms);
      console.log('selected forms', this.selectedForms);
    }
    if (event.checked === false) {
      const removedFormName = formsName;
      const selectedForms = {
        PackageID: id,
        FormsList: [{ Form_Name: removedFormName }]
      };
      this.deleteForms.push(selectedForms);
      // console.log('remove forms', this.deleteForms);
    }

    // enable icons if view forms selected
    const getTotalSelectedForms = this.selectedForms.length - this.deleteForms.length;
    getTotalSelectedForms >= 1 ? this.isEnableIcon = true : this.isEnableIcon = false;
    this.expandFormsCount = getTotalSelectedForms;

    // console.log('total selected forms', getTotalSelectedForms);

    // merge the selected partial package forms list
    const ids = this.selectedForms.map(item => item.PackageID);
    const distinct = (value, index, self) => self.indexOf(value) === index;
    const uniqIds = ids.filter(distinct);
    this.partialPackage = uniqIds.map(resId => {
      const tmp = [];
      const arr = this.selectedForms.filter(item => item.PackageID === resId);
      arr.map(item => tmp.push(...item.FormsList));
      return { PackageID: resId, FormsList: tmp };
    });

    console.log('partial package', this.partialPackage);

    this.partialPackage.map(res => {
      const selectedValue = res.FormsList;
      console.log(selectedValue);
    });

    // Remove unselected forms from cobined array
    for (const testItem of this.selectedForms) {
      // Itearte over delete array
      for (const deleteItem of this.deleteForms) {
        // Check if id matches
        if (testItem.PackageID === deleteItem.PackageID) {
          // Itearte over delete form list
          for (const deleteItemForm of deleteItem.FormsList) {
            // Filter form list of test item
            testItem.FormsList = testItem.FormsList.filter(f => f.Form_Name !== deleteItemForm.Form_Name);
          }
        }
      }
    }

  }

  // delete custom package
  deleteCustomPackage() {
    this.isLoadingResults = true;
    // get selected id
    const getSelectedId = this.selection.selected.map(id => id.PackageID);
    const delteObj = { FullPackageIDs: getSelectedId, PartialPkg: this.partialPackage };
    // delete API send
    this.formsPackage.deleteCustomPackages(JSON.stringify(delteObj)).subscribe(data => {
    if (data) {
     this.isLoadingResults = false;
      }
        this.getCustomPackage();
    });
    this.selection.clear();
    this.partialPackage = [];
    // re call custom package
    this.getCustomPackage();
   this.isSaveActive = false;
  }

  // custom package download
  downloadPackage() {
    this.isLoadingResults = true;
    const getSelectedId = this.selection.selected.map(id => id.PackageID);
    let fullPackageParams = '';
    if (this.partialPackage !== undefined) {
      const getPartialId = this.partialPackage.map(res => res);
    }
    let partialPackageIDParams = '';
    let partialPackageNameParams = '';
    for (let i = 0; i < getSelectedId.length; i++) {
      fullPackageParams += `FullPackageIDs[${i}]=${getSelectedId[i]}&`;
    }

    if (this.getPartialId !== undefined) {
      for (let i = 0; i < this.getPartialId.length; i++) {
        const getPartialName = this.getPartialId[i].FormsList;
        partialPackageIDParams += `PartialPkg[${i}].PackageID=${this.getPartialId[i].PackageID}&`;
        for (let index = 0; index < getPartialName.length; index++) {
          partialPackageNameParams += `PartialPkg[${i}].FormsList[${index}].Form_Name=${getPartialName[index].Form_Name}&`;
        }
      }
    }
    const downloadParamsValue = fullPackageParams + partialPackageIDParams + partialPackageNameParams;
    console.log('params for partial packages', downloadParamsValue.slice(0, -1));
    this.formsPackage.downloadCustomPackage(this.country,downloadParamsValue.slice(0, -1))
      .subscribe(res => {
        saveAs(res, 'package.zip');
        if (res) {
          this.isLoadingResults = false;
        }
      });
  }


  // delete confirmation dialogue box
  openDialog(): void {
    const dialogRef = this.dialog.open(AreyousureDialogueComponent, {
      panelClass: 'confirmation-dialog-modal',
      data: this.confirmationText
    });
    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed', result);
      if (result === true) {
        this.deleteCustomPackage();

      }
    });
  }


  // Custom package send mail
  sendFormsToMail() {
    this.isLoadingResults = true;
    const getSelectedId = this.selection.selected.map(id => id.PackageID);
    let fullPackageParams = '';
    if (this.partialPackage !== undefined) {
      this.getPartialId = this.partialPackage.map(res => res);
    }
    let partialPackageIDParams = '';
    let partialPackageNameParams = '';

    for (let i = 0; i < getSelectedId.length; i++) {
      fullPackageParams += `CustomPackagesForms.FullPackageIDs[${i}]=${getSelectedId[i]}&`;
    }
    if (this.getPartialId !== undefined) {
      for (let i = 0; i < this.getPartialId.length; i++) {
        const getPartialName = this.getPartialId[i].FormsList;
// tslint:disable-next-line: max-line-length
        partialPackageIDParams += `CustomPackagesForms.PartialPkg[${i}].PackageID=${this.getPartialId[i].PackageID}&`;
        for (let index = 0; index < getPartialName.length; index++) {
          partialPackageNameParams
            += `CustomPackagesForms.PartialPkg[${i}].FormsList[${index}].Form_Name=${getPartialName[index].Form_Name}&`;
        }
      }
    }
    const sendMailParamsValue = this.mailFormParams + fullPackageParams + partialPackageIDParams + partialPackageNameParams;
    const emailString = sendMailParamsValue.slice(0, -1);
    // console.log('full packages', fullPackageParams);
    // console.log('send mail params', emailString);

    this.formsPackage.emailCustomPacakgeForms(this.country,emailString).subscribe(res => {
      console.log('email response', res);
      if (res === 'Email sent successfully') {
        this.isLoadingResults = false;
        this.successDialog();
      }
    });
  }


  // confirmation dialogue box
  openEmailDialog(): void {
    const totalFormsCount = this.packageFormsCount + this.expandFormsCount;
    console.log('total count', totalFormsCount);
    const dialogRefCustom = this.dialog.open(EmailformsComponent, {
      panelClass: 'email-dialog-modal',
      data: totalFormsCount
    });
    dialogRefCustom.afterClosed().subscribe(result => {
      console.log('The dialog was closed', result);
      if (result === undefined) {
        this.isLoadingResults = false;
      }
      this.mailFormParams = `recipient=${result.emailID}&Body=${result.textMessage}&Subject=${result.subject}&`;
      this.sendFormsToMail();
    });
  }

  // for dialog open
  successDialog(): void {
    const dialogRefCustom = this.dialog.open(EmailsuccessComponent, {
      panelClass: 'success-dialog-modal',
    });

    dialogRefCustom.afterClosed().subscribe(result => {
      console.log('success');
    });
  }
}

export class ExpandableDataSource {
  data = [];
  /** Connect function called by the table to retrieve one stream containing the data to render. */
  connect(): Observable<any> {
    const rows = [];
    this.data.map(element => rows.push(element, { detailRow: true, element }));
    console.log('connect rows', rows);
    return of(rows);
  }

  disconnect() { }
}
