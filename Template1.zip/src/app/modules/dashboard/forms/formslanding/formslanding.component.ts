import { FormsutilityService } from './../../../../core/services/formsutility/formsutility.service';
import { Component, OnInit, ViewEncapsulation, Renderer2, Inject, AfterViewChecked, OnDestroy } from '@angular/core';
import { AppConstants } from '@app/app.constants';
import { SelectionModel, DataSource } from '@angular/cdk/collections';
import { MatTableDataSource, MatDialog } from '@angular/material';
import { FormsdialogComponent } from '../formsdialog/formsdialog.component';
import { trigger, state, style, transition, animate } from '@angular/animations';
import { LaserficheService } from '@app/core/services/laserfiche/laserfiche.service';
import { EmailsuccessComponent } from '@app/components/emailsuccess/emailsuccess.component';
import { EmailformsComponent } from '@app/components/emailforms/emailforms.component';
import { saveAs } from 'file-saver';
import { Router, ActivatedRoute } from '@angular/router';
import { ChangeDetectorRef } from '@angular/core';
import { DOCUMENT } from '@angular/common';



@Component({
  selector: 'app-formslanding',
  templateUrl: './formslanding.component.html',
  styleUrls: ['./formslanding.component.scss'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0', minHeight: '0', visibility: 'hidden' })),
      state('expanded', style({ height: '*', visibility: 'visible' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
  encapsulation: ViewEncapsulation.None
})

export class FormslandingComponent implements OnInit, AfterViewChecked, OnDestroy {
  title = this.app.formsTitle;
  threedotIcon = this.app.threedotIcon;
  defaultpackage = this.app.defaultpackage;
  mypackage = this.app.mypackage;
  sortingImg = this.app.sortingImg;
  // download icon
  downloadIconGrey = this.app.downloadIconGrey;
  myPackageDownloadIcon = this.app.downloadIconGrey;
  // email icon
  emailIconGrey = this.app.emailIconGrey;
  myPackageEmailIcon = this.app.emailIconGrey;
  // delete icon
  deleteIconGrey = this.app.deleteIconGrey;
  myPackageDeleteIcon = this.app.deleteIconGrey;

  saveIcon = this.app.saveIcon;
  packageIcon = this.app.packageIcon;
  backArrowImg = this.app.backArrowIcon;
  package_name: string;
  version: string;
  notes: string;
  isSaveActive = false;
  isActive = false;
  documentArray = [];
  displayedColumns_Default = ['select', 'Version'];
  displayedColumns_Custom = ['select', 'no_of_forms', 'Last_updated', 'View_options'];
  // data = Object.assign(ELEMENT_DATA);
  Default_Package = new MatTableDataSource<any>();
  selection = new SelectionModel<any>(true, []);
  // mydata = Object.assign(MYELEMENT_DATA);
  Custom_Package = new MatTableDataSource<any>();
  myselection = new SelectionModel<any>(true, []);
  modalStatus: string[];
  modalProduct: string[];

  customPackageId: number;
  selectedIdCustomPackage = [];

  /* Variables for Laserfieche Mock services */
  documentName: string;
  country: string;
  packagefile: string;
  productname: string;
  getLaserfiecheData: any;
  concadenateString: any;
  //  forms selected
  isChecked = false;
  emailApiParams: string;

  // loading
  isLoadingResults: boolean;

  isEnableIcon = false;

  constructor(public dialog: MatDialog,
    private app: AppConstants,
    private formsPackage: FormsutilityService,
    private _route: ActivatedRoute,
    private _router: Router,
    private laserfiche: LaserficheService,
    private cdRef: ChangeDetectorRef,
// tslint:disable-next-line: deprecation
    @Inject(DOCUMENT) private document: Document,
    private renderer: Renderer2
    ) { }

  ngAfterViewChecked() {
    this.cdRef.detectChanges();
  }

  ngOnInit() {
    this.getFormDetails();
    this.getCustomPackage();
    this.renderer.addClass(this.document.body, 'formslanding');
  }

  ngOnDestroy(): void {
    this.renderer.removeClass(this.document.body, 'formslanding');
  }

  /* downloading default forms from forms landing page */
  downloadDefaultForms() {
    this.isLoadingResults = true;
    const getSelectedId = this.selection.selected.map(id => id.DocumentName);
    this.concadenateString = '';
    for (let i = 0; i < getSelectedId.length; i++) {
      this.concadenateString = this.concadenateString + 'ListPackages[' + i + '].Package_Name=' + getSelectedId[i] + '&';
    }
    this.formsPackage.downloadDefaultForms(this.concadenateString.slice(0, -1))
      .subscribe(res => {
        saveAs(res, 'package.zip');
        if (res) {
          this.isLoadingResults = false;
        }
      });
  }

  emailForms() {
    const dialogRef = this.dialog.open(EmailformsComponent, {
      panelClass: 'email-dialog-modal',
      data: this.selection.selected.length,
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result === undefined) {
        this.isLoadingResults = false;
      } else {
        this.isLoadingResults = true;
        let i = 0;
        this.emailApiParams = '';
        this.selection.selected.forEach(element => {
          this.emailApiParams = this.emailApiParams + 'DefaultPkgList[' + i + '].Package_Name=' + element.DocumentName + '&';
          i++;
        });
        const str =
          '?recipient=' + result.emailID +
          '&Body=' + result.textMessage +
          '&Subject=' + result.subject +
          '&' + this.emailApiParams.slice(0, -1);
        this.formsPackage.emailDefaultPackages(str).subscribe(res => {
          if (res === 'Email sent successfully') {
            this.isLoadingResults = false;
            this.successDialog();
          }
        },
          err => {
            console.log(err.error);
          });
      }
    });
  }

  // for dialog open
  successDialog(): void {
    const dialogRef = this.dialog.open(EmailsuccessComponent, {
      panelClass: 'success-dialog-modal',
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('success', this.Default_Package);
    });
  }

  getFormDetails() {
    this.documentName = '';
    this.country = 'HK';
    this.packagefile = 'YES';
    this.laserfiche.searchLaserfiche(this.documentName,
      this.country,
      this.packagefile,
      this.productname).subscribe(data => {
        // this.getLaserfiecheData = data;
        // data = Object.assign(ELEMENT_DATA);
        this.Default_Package = new MatTableDataSource<Element>(data);
      });
  }
  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    // console.log('current selected', numSelected);
    const numRows = this.Default_Package.data.length;
    if (numSelected !== 0) {
      this.isSaveActive = true;
      this.emailIconGrey = this.app.emailIconColor;
      this.downloadIconGrey = this.app.downloadIconColor;
    } else if (numSelected === 0) {
      this.isSaveActive = false;
      this.emailIconGrey = this.app.emailIconGrey;
      this.downloadIconGrey = this.app.downloadIconGrey;
    }
    return numSelected === numRows;
  }


  // get all form package
  getCustomPackage() {
    this.formsPackage.getAllFormsPackages(localStorage.getItem('userId')).subscribe(data => {
      this.Custom_Package = new MatTableDataSource<any>(data);
    });
  }

  packageIsChecked() {
    console.log('is check box', this.myselection.selected);
  }


  /** Selects all rows if they are not all selected; otherwise clear selection. */
  defautPackageToggle() {
    this.isAllSelected() ?
      this.selection.clear() :
      this.Default_Package.data.forEach(row => this.selection.select(row));
  }


  /** The label for the checkbox on the passed row */
  checkboxLabel(row?: Element): string {
    if (!row) {
      return `${this.isAllSelected() ? 'select' : 'deselect'} all`;
    }
  }

  // form dialog open
  openDialog(): void {

    const dialogRef = this.dialog.open(FormsdialogComponent, {
      panelClass: 'forms-dialog-modal',
      data: { modalStatus: this.modalStatus, productName: this.modalProduct }
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('result details', result, 'Search', this.Default_Package);

      const documentName = '';
      let country = '';
      if (result.branchOffice === 'Hong Kong') {
        country = 'HK';
      } else if (result.branchOffice === 'Singapore') {
        country = 'SG';
      } else if (result.branchOffice === 'Bermuda') {
        country = 'BM';
      }
      const packageFile = 'No';
      const productName = '';
      this.laserfiche.dashBoardLaserfiche(documentName, country, packageFile, productName).subscribe(data => {
        console.log('data details', data);
        this.laserfiche.getMessage(data);
        if (data) {
          this._router.navigate(['/searchforms']);
        }
      });
    });
  }




}

