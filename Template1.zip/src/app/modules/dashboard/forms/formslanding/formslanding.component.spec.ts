import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FormslandingComponent } from './formslanding.component';

describe('FormslandingComponent', () => {
  let component: FormslandingComponent;
  let fixture: ComponentFixture<FormslandingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FormslandingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FormslandingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
