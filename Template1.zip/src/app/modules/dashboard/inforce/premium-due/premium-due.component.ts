import { Component, OnInit, OnDestroy, Renderer2 } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MomentDateAdapter } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import * as moment from 'moment';
import { Moment } from 'moment';
import { MatDatepicker } from '@angular/material';
import { InforceService } from '@services/inforce/inforce.service';
import { AppConstants } from '@app/app.constants';
import { Router } from '@angular/router';

export const MY_FORMATS = {
  parse: {
    dateInput: 'MM/YYYY',
  },
  display: {
    dateInput: 'MM/YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};
@Component({
  selector: 'app-premium-due',
  templateUrl: './premium-due.component.html',
  styleUrls: ['./premium-due.component.scss'],
  providers: [
    { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
  ]
})
export class PremiumDueComponent implements OnInit, OnDestroy {


  // premium due
  getIcon = this.app.premiumDueIcon;
  getLabel = this.app.getLabelPremiumDue;
  dataCount: any = [];
  getDays: string;
  isDataAvailable = false;
  reslutDataCount: string;
  minDate = moment().add(1, 'month');
  // maxDate = moment().add(12, 'years');
  month = new FormControl(moment().add(1, 'month'));
  startDate: string;
  endDate: string;

  constructor(
    private policy: InforceService,
    private app: AppConstants,
    private router: Router,
    private renderer: Renderer2
  ) { this.renderer.addClass(document.body, 'header-z'); }

  ngOnInit() {
    if (this.dataCount.length === 0) {
      this.reslutDataCount = this.dataCount.length;
    }
    this.getMonthYear();
  }
  ngOnDestroy() {
    this.renderer.removeClass(document.body, 'header-z');
  }

  // Redirect to landing page and pass the seleted date period
  getSelectValue() {
    if (this.isDataAvailable) {
      this.router.navigate(['/inforce', `${this.getLabel}`, `${this.month.value.format('MM')}`]);
    }
  }



  // default year picker
  yearPicker(normalizedYear: Moment) {
    const ctrlValue = this.month.value;
    ctrlValue.year(normalizedYear.year());
    this.month.setValue(ctrlValue);
  }

  // calender month picker
  monthPicker(normlizedMonth: Moment, datepicker: MatDatepicker<Moment>) {
    const ctrlValue = this.month.value;
    ctrlValue.month(normlizedMonth.month());
    this.month.setValue(ctrlValue);
    datepicker.close();
    // send date range api call
    this.startDate = this.month.value.startOf('month').format('YYYYMMDD');
    this.endDate = this.month.value.endOf('month').format('YYYYMMDD');
    const passDateRange = { startDate: this.startDate, endDate: this.endDate };
    this.policy.getMessage(passDateRange);
    // this.policy.getBirthdayMonth(passMonth);
    this.policy.getPolicyPremiumDue(localStorage.getItem('userId'), this.startDate, this.endDate)
      .subscribe(data => {
        if (data != null) {
          console.log(data);
          const ownerNameList = data.filter(res => res.Relate_Code === 'PO').map(res => {
            return {
              // just to count the total list
              Policy_Number: res.Policy_Number
            };
          });
          this.dataCount = ownerNameList;
          // this.reslutDataCount = ('0' + ownerNameList.length).slice(-3);
          this.reslutDataCount = this.leadingZero(ownerNameList.length);
          console.log(this.reslutDataCount);
          if (data.length >= 1) {
            this.isDataAvailable = true;
          }
        }
      });
    console.log('premium due', this.getDays, this.startDate, this.endDate);
    this.getDays = this.month.value.format('MMM - YYYY');
  }
  leadingZero(n) {
    return (n < 10) ? ('0' + n) : n;
  }
  getMonthYear() {
    this.startDate = this.month.value.startOf('month').format('YYYYMMDD');
    this.endDate = this.month.value.endOf('month').format('YYYYMMDD');
    // send date range api call
    this.getDays = 'Next Month';
    const passDateRange = { startDate: this.startDate, endDate: this.endDate };
    this.policy.getMessage(passDateRange);
    this.policy.getPolicyPremiumDue(localStorage.getItem('userId'), this.startDate, this.endDate)
      .subscribe(data => {
        if (data != null) {
          console.log(data);
          const ownerNameList = data.filter(res => res.Relate_Code === 'PO').map(res => {
            return {
              // just to count the total list
              Policy_Number: res.Policy_Number
            };
          });
          this.dataCount = ownerNameList;
          // this.reslutDataCount = ('0' + ownerNameList.length).slice(-3);
          this.reslutDataCount = this.leadingZero(ownerNameList.length);
          console.log(this.reslutDataCount);
          if (data.length >= 1) {
            this.isDataAvailable = true;
          }
        }

      });
  }

}
