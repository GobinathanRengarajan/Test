import { InforceLandPolicy } from '@app/shared/models/inforce-landing';
import { filter } from 'rxjs/operators';
import { DOCUMENT } from '@angular/common';
import { FilterDialogComponent } from './../filter-dialog/filter-dialog.component';
import { Component, OnInit, ViewChild, Renderer2, Inject, OnDestroy, ViewEncapsulation } from '@angular/core';
import { MatPaginator, MatSort, MatTableDataSource, PageEvent } from '@angular/material';
import { MatDialog } from '@angular/material';
import { InforceService } from '@app/core/services/inforce/inforce.service';
import { AppConstants } from '@app/app.constants';
import { Router, ActivatedRoute } from '@angular/router';
import * as moment from 'moment';
// import { ConsoleReporter } from 'jasmine';

export interface InforceLandingReassigned {
  Policy_Number: string;
  Status: string;
  Insured_Name: string;
  Insured_DOB: string;
  Effective_Date: string;
  Due_Date: string;
  Grace_Period: string;
  Product_Name: string;
  Producer_Name: string;
}
@Component({
  selector: 'app-inforce-landing',
  templateUrl: './inforce-landing.component.html',
  styleUrls: ['./inforce-landing.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class InforceLandingComponent implements OnInit, OnDestroy {
  // table header
  states: string[] = [
    'View Complete List',
    'Premium Due',
    'Policy In Grace Period',
    'Coming Birthday'
  ];

  modalStatus: string[];
  modalProduct: string[];

  // params value
  selected: string;
  startDate: string;
  endDate: string;
  month: string;
  datePeriod: string;
  pageloadstart = false;
  isDataLoaded = false;
  isClearActive = true;

  searchValue = '';

  isDataAvailable = true;
  isModalClose = false;

  isLoadingResults: boolean;
  // premiumStartDate = moment().add(1, 'months').startOf('month');
  // premiumEndDate = moment().add(1, 'months').endOf('month');
  cbMonth = moment().add(1, 'month');
  cpStartDate = moment().add(-60, 'days');
  cpEndDate = moment();

  gracePeriodFromDate = moment();
  gracePeriodEndDate = moment().add(60, 'days');

  // icons
  sortingIcon = this.app.sortingIcon;
  searchColorIcon = this.app.searchColorIcon;

  // table
  dataSource = new MatTableDataSource<any>();
  datalength = 0;
  resutlDatalength = 0;
  reslutDataCount: any;
  isNodata = false;
  searchFilterValue: string;
  displayedColumns: string[] = [
    'Policy_Number',
    'Status',
    'Insured_Name',
    'Owner_Name',
    'Insured_DOB',
    'Effective_Date',
    'Due_Date',
    'Sum_Assured',
    'Grace_Period',
    'Product_Name'
  ];

  filterValues = {
    Status: [],
    Insured_DOB: '',
    From_Insured_DOB: undefined,
    To_Insured_DOB: undefined,
    Effective_Date: '',
    Due_Date: '',
    Grace_Period: '',
    Insured_Name: '',
    Owner_Name: '',
    Product_Name: '',
  };
  resultValue = [];


  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  filterData: any[] = [];
  name: string;
  insuranceDOB = [];

  constructor(
    private render: Renderer2,
    public dialog: MatDialog,
    private inforceService: InforceService,
    private app: AppConstants,
    private route: ActivatedRoute,
    private router: Router,
    @Inject(DOCUMENT) private document: Document,
  ) { }

  ngOnInit() {
    this.paramsDataCall();
    this.getPremiumDueDateRange();
    this.getComingBirthdayMonht();
    this.inforceLandingApiCall();
    this.pageloadstart = true;
    this.render.addClass(this.document.body, 'inforce-body');
    if (this.resutlDatalength >= 1) {
      // this.reslutDataCount = ('0' + this.resutlDatalength).slice(-3);
      this.reslutDataCount = this.leadingZero(this.resutlDatalength);
      // console.log('leadingZero', this.reslutDataCount);
    } else {
      this.reslutDataCount = '0';
    }
  }
  leadingZero(n) {
    return (n < 10) ? ('0' + n) : n;
  }
  ngOnDestroy(): void {
    this.render.removeClass(this.document.body, 'inforce-body');
  }

  // URL parameter data communication
  paramsDataCall() {
    this.selected = this.route.snapshot.paramMap.get('policy');
    this.startDate = this.route.snapshot.paramMap.get('periodFrom');
    this.endDate = this.route.snapshot.paramMap.get('periodTo');
    this.month = this.route.snapshot.paramMap.get('period');
  }
  // dropdown value change on select
  onSelect(event: string) {
    this.selected = event;
    // console.log('Test landing page on select', event, this.selected);
    this.inforceLandingApiCall();
  }

  // get premium date range form behaviour subject
  getPremiumDueDateRange() {
    this.inforceService.setMessage().subscribe(data => {
      this.startDate = data.startDate;
      this.endDate = data.endDate;
    });
  }

  // clear filter
  clearFilter() {
    this.inforceLandingApiCall();
    this.searchValue = null;
  }




  // get month from behaviour subject
  getComingBirthdayMonht() {
    this.inforceService.setBirthdayMonth().subscribe(month => {
      this.month = month;
    });
  }

  // for dialog open
  openDialog(): void {
    const dialogRef = this.dialog.open(FilterDialogComponent, {
      panelClass: 'filter-dialog-modal',
      data: { modalStatus: this.modalStatus, productName: this.modalProduct }
    });

    dialogRef.afterClosed().subscribe(result => {
      this.isModalClose = true;
      if (result === undefined || result === '') {
        this.isLoadingResults = false;
      } else {
        this.isLoadingResults = true;
        this.inforceLandingApiCall();
        this.router.navigate([], {
          queryParams: {
            policyStatus: result.policyStatus,
            insuredName: result.insuredName,
            lastName: result.lastName,
            firstName: result.firstName,
            ownerLastName: result.ownerLastName,
            ownerFirstName: result.ownerFirstName,
            insureFromDate: result.insuredDOB.insureFromDate,
            insureToDate: result.insuredDOB.insureToDate,
            effectiveFromDate: result.effectiveDate.effectiveFromDate,
            effectiveToDate: result.effectiveDate.effectiveToDate,
            premiumFromDate: result.premiumDueDate.premiumFromDate,
            premiumToDate: result.premiumDueDate.premiumToDate,
            gracePeriod: result.gracePeriod,
            productName: result.productName
          }
        });

        // filter data
        setTimeout(() => {
          this.dataSource.filterPredicate = (data) => {
            this.isClearActive = false;
            this.isLoadingResults = false;
            if (result == null) {
              return true;
            } else {
              let andFilter = true;
              if ((result.policyStatus != null) && (result.policyStatus.includes(data.Status))) {
                andFilter = true;
              } else if (result.policyStatus == null) {
                andFilter = andFilter;
              } else {
                // short-cut to return false, no need to compare other fields again
                return false;
              }
              // Insured name
              if ((result.lastName != null) && (data.Insured_Name.trim().toLowerCase().includes(result.lastName.toLowerCase()))) {
                andFilter = true;
              } else if (result.lastName == null) {
                andFilter = andFilter;
              } else {
                return false;
              }
              if ((result.firstName != null) && (data.Insured_Name.trim().toLowerCase().includes(result.firstName.toLowerCase()))) {
                andFilter = true;
              } else if (result.firstName == null) {
                andFilter = andFilter;
              } else {
                return false;
              }

              // owner name
              if ((result.ownerLastName != null) && (data.Owner_Name.toLowerCase().includes(result.ownerLastName.toLowerCase()))) {
                andFilter = true;
              } else if (result.ownerLastName == null) {
                andFilter = andFilter;
              } else {
                return false;
              }
              if ((result.ownerFirstName != null) && (data.Owner_Name.toLowerCase().includes(result.ownerFirstName.toLowerCase()))) {
                andFilter = true;
              } else if (result.ownerFirstName == null) {
                andFilter = andFilter;
              } else {
                return false;
              }

              // product name
              if ((result.productName != null) && (data.Product_Name.trim().toLowerCase() === result.productName.trim().toLowerCase())) {
                andFilter = true;
              } else if (result.productName == null) {
                andFilter = andFilter;
              } else {
                return false;
              }
              if ((result.gracePeriod === true) && (data.Grace_Period === 'Yes')) {
                andFilter = true;
              } else if (result.gracePeriod == null || result.gracePeriod === false) {
                andFilter = andFilter;
              } else {
                return false;
              }

              const insuredFromDOB = moment(result.insuredDOB.insureFromDate);
              const insuredToDOB = moment(result.insuredDOB.insureToDate);
              if ((insuredFromDOB.isValid()) && (insuredToDOB.isValid())) {
                if ((data.Insured_DOB >= insuredFromDOB) && (data.Insured_DOB <= insuredToDOB)) {
                  andFilter = andFilter;
                } else {
                  return false;
                }
              }

              // console.log(andFilter);

              const effectiveFromDate = moment(result.effectiveDate.effectiveFromDate);
              const effectiveToDate = moment(result.effectiveDate.effectiveToDate);
              if ((effectiveFromDate.isValid()) && (effectiveToDate.isValid())) {
                if ((data.Effective_Date >= effectiveFromDate) && (data.Effective_Date <= effectiveToDate)) {
                  andFilter = andFilter;
                } else {
                  return false;
                }
              }

              const premiumDueFromDate = moment(result.premiumDueDate.premiumFromDate);
              const premiumDueToDate = moment(result.premiumDueDate.premiumEndDate);
              if ((premiumDueFromDate.isValid()) && (premiumDueToDate.isValid())) {
                if ((data.Due_Date >= premiumDueFromDate) && (data.Due_Date <= premiumDueToDate)) {
                  andFilter = andFilter;
                } else {
                  return false;
                }
              }

              return andFilter;
            }
          };

          this.dataSource.filter = '' + Math.random();
          const filteredData = this.dataSource.filteredData;
          this.resutlDatalength = filteredData.length;
          if (this.resutlDatalength >= 1) {
            // this.reslutDataCount = ('0' + this.resutlDatalength).slice(-3);
            this.reslutDataCount = this.leadingZero(this.resutlDatalength);
          } else {
            this.reslutDataCount = '0';
          }
          this.dataSource = new MatTableDataSource(filteredData);
          this.dataSource.sort = this.sort;
          this.dataSource.paginator = this.paginator;
          // console.log('filtered data', this.dataSource.filteredData);
        }, 5000);
      }

    });
  }

  // header search filter
  applyFilter(filterValue: string) {
    this.pageloadstart = false;
    this.dataSource.filter = filterValue.trim().toLowerCase();
    this.resutlDatalength = this.dataSource.filteredData.length;
    if (this.resutlDatalength >= 1) {
      // this.reslutDataCount = ('0' + this.resutlDatalength).slice(-3);
      this.reslutDataCount = this.leadingZero(this.resutlDatalength);
    } else {
      this.reslutDataCount = '0';
    }
    this.isClearActive = false;
    // console.log('no reslut should show', this.dataSource);
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  populateListData(data: InforceLandPolicy[]): any[] {
    const ownerNameList = data.filter(res => res.Relate_Code == 'PO').map(res => {
      return {
        Policy_Number: res.Policy_Number,
        Owner_Last: res.IO_Last.trim(),
        Owner_First: res.IO_First.trim(),
        Owner_Middle: res.IO_Middle.trim(),
        Owner_Name: (res.IO_Last.trim() + ', ' + res.IO_First.trim() + ' ' + res.IO_Middle.trim()).trim(),
      };
    });
    const resultData = [];
    data.filter(res => res.Relate_Code === 'IN').map(res => {
      // tslint:disable-next-line: no-shadowed-variable
      console.log('From: ', this.gracePeriodFromDate);
      console.log('To : ', this.gracePeriodEndDate);
      console.log(res.Policy_Number);
      const ownerNameObj = ownerNameList.filter(policy => policy.Policy_Number ===
        res.Policy_Number)[0];
      console.log(ownerNameObj);
      console.log(ownerNameObj == null);
      const displayObj: any = {};

      displayObj.Policy_Number = res.Policy_Number;
      displayObj.Status = res.Contract_Code;
      displayObj.Insured_Name = (res.IO_Last.trim() + ', ' + res.IO_First.trim() + ' ' + res.IO_Middle.trim()).trim();
      displayObj.Insured_DOB = moment(res.Date_Of_Birth);
      displayObj.Effective_Date = moment(String(res.Issue_Date));
      displayObj.Due_Date = moment(String(res.Billing_Date));
      // Due_Date: moment(res.Billing_Date).format('DD/MM/YYYY'),
      displayObj.Grace_Period =
        moment(String(res.Billing_Date)).add(60, 'days') >= this.gracePeriodFromDate ? 'Yes' : 'No';
      displayObj.Product_Name = res.Market_Name;
      if (ownerNameObj == null) {
        displayObj.Owner_Name = "";
        displayObj.Owner_Last = "";
        displayObj.Owner_First = "";
        displayObj.Owner_Middle = "";
      } else {
        displayObj.Owner_Name = ownerNameObj.Owner_Name;
        displayObj.Owner_Last = ownerNameObj.Owner_Last;
        displayObj.Owner_First = ownerNameObj.Owner_First;
        displayObj.Owner_Middle = ownerNameObj.Owner_Middle;
      }
      displayObj.Sum_Assured = '$' + res.Sum_Assured.split('.')[0];
      resultData.push(displayObj);
    });
    // console.log(resultData.length);
    this.resutlDatalength = resultData.length;
    if (this.resutlDatalength >= 1) {
      // this.reslutDataCount = ('0' + this.resutlDatalength).slice(-3);
      this.reslutDataCount = this.leadingZero(this.resutlDatalength);
    } else {
      this.reslutDataCount = '0';
    }
    return resultData;
  }

  // condition API call based on the dropdown value
  inforceLandingApiCall() {
    if (this.selected === 'View Complete List') {
      this.datePeriod = '';
      this.isClearActive = true;
      this.inforceService.getPolicyInforceAll(localStorage.getItem('userId')).subscribe(data => {
        this.datalength = data.length;
        // console.log('view complete list', this.datalength);
        this.isDataLoaded = true;
        // loader hide
        if (this.datalength === 0) {
          this.isDataAvailable = false;
        }
        if (this.datalength >= 1) {
          this.isDataAvailable = true;
          // reslutDataCount = ('0' + this.resutlDatalength ).slice(-3);
        }
        // console.log(this.isDataAvailable);
        // console.log(data);
        // rewrite the json data start
        const reWriteData = this.populateListData(data);
        // rewrite the json data end
        this.dataSource = new MatTableDataSource(reWriteData);
        this.datalength = data.length;
        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;
        // for modal array status pass
        this.modalStatus = [...Array.from(new Set(data.map(res => res.Contract_Code)))];
        this.modalProduct = [...Array.from(new Set(data.map(res => res.Market_Name)))];
      }, error => {
        this.isDataAvailable = false;
        // console.log(error, this.isDataAvailable);
      });
      // params
      this.router.navigate(['/inforce', `${this.selected}`, 'all']);

      // premium due
    } else if (this.selected === 'Premium Due') {
      this.isClearActive = true;
      this.datePeriod = `in ${moment(this.startDate).format('MMM YYYY')}`;
      this.inforceService.getPolicyPremiumDue(
        localStorage.getItem('userId'),
        (this.startDate),
        (this.endDate))
        .subscribe(data => {
          this.datalength = data.length;
          this.isDataLoaded = true;
          // console.log('Premium Due', this.datalength);
          // loader hide
          if (this.datalength === 0) {
            this.isDataAvailable = false;
          }
          if (this.datalength >= 1) {
            this.isDataAvailable = true;
          }
          // rewrite the json data start
          const reWriteData = this.populateListData(data);
          // rewrite the json data end
          this.dataSource = new MatTableDataSource(reWriteData);
          this.datalength = data.length;
          this.dataSource.sort = this.sort;
          this.dataSource.paginator = this.paginator;
          // for modal array status pass
          this.modalStatus = [...Array.from(new Set(data.map(res => res.Status)))];
          this.modalProduct = [...Array.from(new Set(data.map(res => res.Market_Name)))];
          // console.log('modal array pass', data);
        }, error => {
          this.isDataAvailable = false;
          // console.log(error, this.isDataAvailable);
        });
      // params
      this.router.navigate([
        '/inforce', `${this.selected}`,
        `${this.startDate}`,
        `${this.endDate}`
      ]);
    } else if (this.selected === 'Policy In Grace Period') {
      this.isClearActive = true;
      // this.datePeriod = `in ${moment(this.cpStartDate).format('DD/MM/YYYY')} to ${moment(this.cpEndDate).format('DD/MM/YYYY')}`;
      this.inforceService.getPremiumDue(
        localStorage.getItem('userId'),
        this.cpStartDate.format('YYYYMMDD'),
        this.cpEndDate.format('YYYYMMDD')
      ).subscribe(data => {
        this.datalength = data.length;
        this.isDataLoaded = true;
        // console.log('Policy In Grace Period', this.datalength);
        // loader hide
        if (this.datalength === 0) {
          this.isDataAvailable = false;
        }
        if (this.datalength >= 1) {
          this.isDataAvailable = true;
        }
        // rewrite the json data start
        const reWriteData = this.populateListData(data);
        // rewrite the json data end
        this.dataSource = new MatTableDataSource(reWriteData);
        this.datalength = data.length;
        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;
        // console.log(this.datalength);
        // for modal array status pass
        this.modalStatus = [...Array.from(new Set(data.map(res => res.Status)))];
        this.modalProduct = [...Array.from(new Set(data.map(res => res.Market_Name)))];
        // console.log('modal array pass', this.modalStatus);
      }, error => {
        this.isDataAvailable = false;
        // console.log(error, this.isDataAvailable);
      });
      // params
      this.router.navigate([
        '/inforce', `${this.selected}`,
        `${this.cpStartDate.format('YYYYMMDD')}`,
        `${this.cpEndDate.format('YYYYMMDD')}`
      ]);
    } else if (this.selected === 'Coming Birthday') {
      this.isClearActive = true;
      this.datePeriod = `in ${moment(this.month, 'MM').format('MMM')}`;
      // console.log(this.datePeriod);
      this.inforceService.getUpcomingBirthdayData(localStorage.getItem('userId'),
        (this.month))
        .subscribe(data => {
          this.datalength = data.length;
          this.isDataLoaded = true;
          // loader hide
          if (this.datalength === 0) {
            this.isDataAvailable = false;
          }
          if (this.datalength >= 1) {
            this.isDataAvailable = true;
          }
          // rewrite the json data start
          const reWriteData = this.populateListData(data);
          // rewrite the json data end
          this.dataSource = new MatTableDataSource(reWriteData);
          this.datalength = data.length;
          this.dataSource.sort = this.sort;
          this.dataSource.paginator = this.paginator;
          if (data) {
            this.isNodata = true;
          }
          // console.log(this.isNodata);
          // for modal array status pass
          this.modalStatus = [...Array.from(new Set(data.map(res => res.Status)))];
          this.modalProduct = [...Array.from(new Set(data.map(res => res.Market_Name)))];
          // console.log('modal array pass', this.modalStatus);
        }, error => {
          this.isDataAvailable = false;
          // console.log(error, this.isDataAvailable);
        });
      // params
      this.router.navigate(['/inforce', `${this.selected}`, `${this.month}`]);
    }
  }

  // table pagination
  syncPrimaryPaginator(event: PageEvent) {
    // console.log('test');
    // console.log(this.dataSource);
    // console.log(this.paginator);
    this.paginator.pageIndex = event.pageIndex;
    this.paginator.pageSize = event.pageSize;
    this.paginator.page.emit(event);
  }




}

