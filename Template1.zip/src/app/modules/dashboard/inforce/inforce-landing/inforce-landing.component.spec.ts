import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InforceLandingComponent } from './inforce-landing.component';
import { AuthService } from '@app/core/authentication/auth.service';
import { RouterTestingModule } from '@angular/router/testing';
import { AppConstants } from '@app/app.constants';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { InforceService } from '@app/core/services/inforce/inforce.service';
import { MatTableModule, MatDialogModule } from '@angular/material';

describe('InforceLandingComponent', () => {
  let component: InforceLandingComponent;
  let fixture: ComponentFixture<InforceLandingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InforceLandingComponent ],
      imports: [ BrowserAnimationsModule,
         BrowserDynamicTestingModule,
          RouterTestingModule, HttpClientTestingModule, MatTableModule, MatDialogModule ],
      providers: [AuthService, AppConstants, InforceService],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InforceLandingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
