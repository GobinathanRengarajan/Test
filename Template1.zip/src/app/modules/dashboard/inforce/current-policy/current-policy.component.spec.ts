import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CurrentPolicyComponent } from './current-policy.component';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { MatProgressSpinnerModule, MatDatepickerModule, MatNativeDateModule} from '@angular/material';
import { AuthService } from '@app/core/authentication/auth.service';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { MatMomentDateModule, MomentDateAdapter, MAT_MOMENT_DATE_FORMATS } from '@angular/material-moment-adapter';
import { MaterialModule } from '@app/modules/material/material.module';
import { SatDatepickerModule, SatNativeDateModule, MAT_DATE_FORMATS, MAT_DATE_LOCALE, DateAdapter  } from 'saturn-datepicker';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { AppConstants } from '@app/app.constants';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import * as moment from 'moment';
import { InforceService } from '@app/core/services/inforce/inforce.service';
import { RouterModule, ROUTES } from '@angular/router';

describe('CurrentPolicyComponent', () => {
  let component: CurrentPolicyComponent;
  let fixture: ComponentFixture<CurrentPolicyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CurrentPolicyComponent ],
      imports: [
        BrowserAnimationsModule,
        BrowserDynamicTestingModule,
        RouterTestingModule,
        MatProgressSpinnerModule,
        MaterialModule,
        MatDatepickerModule,
        MatNativeDateModule,
        MatMomentDateModule,
        SatDatepickerModule,
        HttpClientModule,
        ReactiveFormsModule,
        SatDatepickerModule,
        SatNativeDateModule
      ],
      providers: [
        AuthService,
        CurrentPolicyComponent,
        AppConstants,
        InforceService,
        {provide: DateAdapter,
          useClass: MomentDateAdapter,
          deps: [MAT_DATE_LOCALE]},
          {provide: MAT_DATE_FORMATS,
            useValue: MAT_MOMENT_DATE_FORMATS}
          ],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA ]
    })
    .compileComponents();
    component = TestBed.get(CurrentPolicyComponent);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CurrentPolicyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  // const startDate = moment().add(-60, 'days');
  // const endDate = moment();


  // // current policy
  // it(`should current policy first date shoult be ${startDate.format('YYYY/MMM/DD')}`, () => {
  //   const start = component.startDate;
  //   expect(start.format('YYYYMMDD')).toEqual(startDate.format('YYYYMMDD'));
  // });
  // it(`should current policy last date shoult be ${endDate.format('YYYY/MMM/DD')}`, () => {
  //   const end = component.endDate;
  //   expect(end.format('YYYYMMDD')).toEqual(endDate.format('YYYYMMDD'));

  // });
  // it(`should have as title 'Current Policy'`, () => {
  //   const text = component.getLabel;
  //   expect(text).toEqual('Current Policy');
  // });


});
