import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import * as moment from 'moment';
import { InforceService } from '@services/inforce/inforce.service';
import { AppConstants } from '@app/app.constants';
import { AuthService } from 'app/core/authentication/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-current-policy',
  templateUrl: './current-policy.component.html',
  styleUrls: ['./current-policy.component.scss']
})
export class CurrentPolicyComponent implements OnInit {

  form: FormGroup;
  // grace period
  getIcon = this.app.currentPolicyIcon;
  getLabel = this.app.getLabelCurrentPolicy;
  dataCount: any = [];
  getDays: any;
  isGeneralAdmin = false;
  isDataAvailable = false;
  reslutDataCount: string;
  startDate = moment().add(-60, 'days');
  endDate = moment();

  constructor(
    private policy: InforceService,
    fb: FormBuilder,
    private app: AppConstants,
    private authservice: AuthService,
    private router: Router
  ) {
    this.form = fb.group({
      gracePeriod: [{ begin: this.startDate, end: this.endDate }]
    });
  }



  ngOnInit() {
    if (this.dataCount.length === 0) {
      this.reslutDataCount = this.dataCount.length;
    }
    this.dateRangeChange();
    this.authservice.currentUser.subscribe(data => {
      if (data.role === 'Admin') {
        this.isGeneralAdmin = true;
      }
    });
  }

  // send dropdown value for landing page
  getSelectValue() {
    if (this.isDataAvailable) {
      this.router.navigate([
        '/inforce', 'Policy In Grace Period',
        `${this.startDate.format('YYYYMMDD')}`,
        `${this.endDate.format('YYYYMMDD')}`
      ]);
    }
  }

  leadingZero(n) {
    return (n < 10) ? ('0' + n) : n;
  }

  // grace period change
  get getDateValue() { return this.form.get('gracePeriod'); }
  dateRangeChange() {
    let startDate = this.startDate;
    let endDate = this.endDate;
    startDate = this.getDateValue.value.begin;
    endDate = this.getDateValue.value.end;
    this.getDays = `In Grace Period`;
    this.policy.getPremiumDue(localStorage.getItem('userId'), startDate.format('YYYYMMDD'), endDate.format('YYYYMMDD'))
      .subscribe(data => {
        console.log(data);
        const ownerNameList = data.filter(res => res.Relate_Code === 'PO').map(res => {
          return {
            // just to count the total list
            Policy_Number: res.Policy_Number
          };
        });
        this.dataCount = ownerNameList;
        console.log('owner ', ownerNameList);
        // this.reslutDataCount = ('0' + ownerNameList.length).slice(-2);
        this.reslutDataCount = this.leadingZero(ownerNameList.length);
        if (ownerNameList.length >= 1) {
          this.isDataAvailable = true;
        }
      });
  }

}
