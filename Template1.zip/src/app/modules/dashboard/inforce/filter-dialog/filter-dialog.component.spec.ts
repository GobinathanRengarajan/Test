import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FilterDialogComponent } from './filter-dialog.component';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { AppConstants } from '@app/app.constants';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MaterialModule } from '@app/modules/material/material.module';
import {
  MatFormFieldModule,
  MatInputModule,
  MatDialogModule,
  MatButtonModule,
  MatDialog,
  MatDialogRef,
  MAT_DATE_FORMATS,
  MatProgressSpinnerModule,
  MatDatepickerModule,
  MatNativeDateModule,
  DateAdapter,
  MAT_DATE_LOCALE, MAT_DIALOG_DATA } from '@angular/material';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MAT_MOMENT_DATE_FORMATS, MatMomentDateModule, MomentDateAdapter } from '@angular/material-moment-adapter';
import { SatDatepickerModule, SatNativeDateModule } from 'saturn-datepicker';

describe('FilterDialogComponent', () => {
  let component: FilterDialogComponent;
  let fixture: ComponentFixture<FilterDialogComponent>;
  const fakeMatDialogRef = {
    snapshot: { data: {} }
  };
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FilterDialogComponent ],
      imports: [ BrowserAnimationsModule,
        BrowserDynamicTestingModule,
        RouterTestingModule,
        MatProgressSpinnerModule,
        MaterialModule,
        MatDatepickerModule,
        MatNativeDateModule,
        MatButtonModule,
        MatMomentDateModule,
        HttpClientModule,
        MatDialogModule,
        FormsModule,
        MatInputModule,
        ReactiveFormsModule,
        MatFormFieldModule,
        SatDatepickerModule,
        SatNativeDateModule],
        providers: [
          AppConstants,
          {provide: DateAdapter,
            useClass: MomentDateAdapter,
            deps: [MAT_DATE_LOCALE]},
            {provide: MAT_DATE_FORMATS,
              useValue: MAT_MOMENT_DATE_FORMATS},
              MatDialog, {provide: MatDialogRef,
              useValue: fakeMatDialogRef},
              { provide: MAT_DIALOG_DATA, useValue: {} }
            ],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA ]

    })
    .compileComponents();
  }));
  beforeEach(() => {
    fixture = TestBed.createComponent(FilterDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
