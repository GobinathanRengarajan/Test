import { AppConstants } from '@app/app.constants';
import { Component, OnInit, Inject,
          ViewEncapsulation, AfterViewInit,
          ChangeDetectorRef, AfterViewChecked,
          ElementRef, HostListener, ViewChild
        } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FormControl, FormGroup, FormArray } from '@angular/forms';
import { InforceLandingComponent } from './../inforce-landing/inforce-landing.component';
import { MomentDateAdapter } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import * as moment from 'moment';
import { Moment } from 'moment';
import { MatDatepicker } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';
export interface DialogData {
  modalStatus: string[];
  productName: string[];
}
// const moment =  _moment;

export const MY_FORMATS = {
  parse: {
    dateInput: 'MMM/YYYY',
  },
  display: {
    dateInput: 'MMM/YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMM YYYY',
  },
};
@Component({
  selector: 'app-filter-dialog',
  templateUrl: './filter-dialog.component.html',
  styleUrls: ['./filter-dialog.component.scss'],
  providers: [
    { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
  ],
  encapsulation: ViewEncapsulation.None
})
export class FilterDialogComponent implements OnInit, AfterViewChecked {

  // dropdown
  statusList: any[] = [];
  productNameList: any[] = [];

  isDisabled = true;
  isDateDisabled = true;

  // fromdate to set min select date range calendar
  insuraceFrom: Moment;
  insuraceTo: Moment;
  effectiveFrom: Moment;
  effectiveTo: Moment;
  premiumFrom: Moment;
  premiumTo: Moment;
  termFrom: Moment;
  termTo: Moment;

  insuredDOBErrorText: string;
  effectiveErrorText: string;
  premiumErrorText: string;

  // date field clear
  insureFromDateClear = false;
  insureToDateClear = false;
  effectiveFromDateClear = false;
  effectiveToDateClear = false;
  premiumFromDateClear = false;
  premiumToDateClear = false;

  isCloseModal: boolean;

  @ViewChild('insureFromDate') insureFromDateElement: ElementRef;
  @ViewChild('insureToDate') insureToDateElement: ElementRef;
  @ViewChild('effectiveFromDate') effectiveFromDateElement: ElementRef;
  @ViewChild('effectiveToDate') effectiveToDateElement: ElementRef;
  @ViewChild('premiumFromDate') premiumFromDateElement: ElementRef;
  @ViewChild('premiumToDate') premiumToDateElement: ElementRef;

  endDate = moment();

  checked = true;
  isDatePickerClose = false;
  // icons
  closeIcon = this.app.closeIcon;

  filterForm = new FormGroup({
    policyStatus: new FormControl(),
    insuredName: new FormControl(),
    lastName: new FormControl(),
    firstName: new FormControl(),
    ownerLastName: new FormControl(),
    ownerFirstName: new FormControl(),
    insuredDOB: new FormGroup({
      insureFromDate: new FormControl(),
      insureToDate: new FormControl()
    }),
    effectiveDate: new FormGroup({
      effectiveFromDate: new FormControl(),
      effectiveToDate: new FormControl()
    }),
    premiumDueDate: new FormGroup({
      premiumFromDate: new FormControl(),
      premiumToDate: new FormControl()
    }),
    gracePeriod: new FormControl(),
    productName: new FormControl(),
    termRejDate: new FormGroup({
      termFromDate: new FormControl(),
      termToDate: new FormControl()
    }),
  });





  constructor(
    public dialogRef: MatDialogRef<InforceLandingComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData,
    private app: AppConstants,
    private _route: ActivatedRoute,
    private _router: Router,
    private cdRef: ChangeDetectorRef,
    private el: ElementRef
  ) { }

  ngOnInit() {
    // this.getMonthYear();
    // this.statusList.push(this.data.modalStatus);
    this.statusList = [...this.data.modalStatus];
    this.data.productName.map(data => {
      if (data !== null) {
        this.productNameList.push(data);
      }
    });
    this.formDefaultValue();
  }
  ngAfterViewChecked() {
    this.cdRef.detectChanges();
  }

  // get form default value
  formDefaultValue() {
    // set form values
    this._route.queryParams.subscribe(params => {
      // this.filterForm.get('policyStatus').setValue(params.policyStatus);
      this.policyStatus.setValue(params.policyStatus);
      this.lastName.setValue(params.lastName);
      this.firstName.setValue(params.firstName);
      this.ownerLastName.setValue(params.ownerLastName);
      this.ownerFirstName.setValue(params.ownerFirstName);
      if (params.insureFromDate != null) {
        this.insureFromDate.setValue(params.insureFromDate);
      }
      if (params.insureToDate != null) {
        this.insureToDate.setValue(params.insureToDate);
      }
      if (params.effectiveFromDate != null) {
        this.effectiveFromDate.setValue(params.effectiveFromDate);
      }
      if (params.effectiveToDate != null) {
        this.effectiveToDate.setValue(params.effectiveToDate);
      }
      if (params.premiumFromDate != null) {
        this.premiumFromDate.setValue(params.premiumFromDate);
      }
      if (params.premiumToDate != null) {
        this.premiumToDate.setValue(params.premiumToDate);
      }
      // this.gracePeriod.setValue(params.gracePeriod);
      if (params.gracePeriod === 'false' || params.gracePeriod === undefined) {
        this.checked = false;
      } else {
        this.checked = true;
      }
      // this.checked = false;
      this.productName.setValue(params.productName);
    });
  }

  get policyStatus() { return this.filterForm.get('policyStatus'); }
  get insuredName() { return this.filterForm.get('insuredName'); }
  get lastName() { return this.filterForm.get('lastName'); }
  get firstName() { return this.filterForm.get('firstName'); }
  get ownerLastName() { return this.filterForm.get('ownerLastName'); }
  get ownerFirstName() { return this.filterForm.get('ownerFirstName'); }
  get insureFromDate() { return this.filterForm.get('insuredDOB.insureFromDate'); }
  get insureToDate() { return this.filterForm.get('insuredDOB.insureToDate'); }
  get effectiveFromDate() { return this.filterForm.get('effectiveDate.effectiveFromDate'); }
  get effectiveToDate() { return this.filterForm.get('effectiveDate.effectiveToDate'); }
  get premiumFromDate() { return this.filterForm.get('premiumDueDate.premiumFromDate'); }
  get premiumToDate() { return this.filterForm.get('premiumDueDate.premiumToDate'); }
  get gracePeriod() { return this.filterForm.get('gracePeriod'); }
  get productName() { return this.filterForm.get('productName'); }
  get termFromDate() { return this.filterForm.get('termRejDate.termFromDate'); }
  get termToDate() { return this.filterForm.get('termRejDate.termToDate'); }

  // clear date input fields start code
  ClearInsureFromDate() {
    this.insureFromDate.setValue(null);
    this.insureFromDateClear = false;
  }
  ClearInsureToDate() {
    this.insureToDate.setValue(null);
    this.insureToDateClear = false;
  }
  CleareffectiveFromDate() {
    this.effectiveFromDate.setValue(null);
    this.effectiveFromDateClear = false;
  }
  CleareffectiveToDate() {
    this.effectiveToDate.setValue(null);
    this.effectiveToDateClear = false;
  }

  ClearpremiumFromDate() {
    this.premiumFromDate.setValue(null);
    this.premiumFromDateClear = false;
  }
  ClearpremiumToDate() {
    this.premiumToDate.setValue(null);
    this.premiumToDateClear = false;
  }

  focus() {
    this.insureFromDateElement.nativeElement.blur();
    this.insureToDateElement.nativeElement.blur();
    this.effectiveFromDateElement.nativeElement.blur();
    this.effectiveToDateElement.nativeElement.blur();
    this.premiumFromDateElement.nativeElement.blur();
    this.premiumToDateElement.nativeElement.blur();
  }

  // cleare date input fields end code
  onNoClick(): void {
    this.dialogRef.close();
  }

  dateSelectError() {
    // insured DOB date selection
    if (this.insureFromDate.value === null && this.insureToDate.value === null) {
      this.insuredDOBErrorText = null;
    } else if (this.insureFromDate.value === null) {
      this.insuredDOBErrorText = 'Please select Insured DOB from date';
      this.isCloseModal = true;
    } else if (this.insureToDate.value === null) {
      this.insuredDOBErrorText = 'Please select Insured DOB to date';
    } else if (this.insureFromDate.value !== null && this.insureToDate.value !== null) {
      this.insuredDOBErrorText = null;
    }

    // Policy Effective Date selection
    if (this.effectiveFromDate.value === null && this.effectiveToDate.value === null) {
      this.effectiveErrorText = null;
    } else if (this.effectiveFromDate.value !== null && this.effectiveToDate.value === null) {
      this.effectiveErrorText = 'Please select Policy Effective to date';
    } else if (this.effectiveFromDate.value === null && this.effectiveToDate.value !== null) {
      this.effectiveErrorText = 'Please select Policy Effective from date';
    } else if (this.effectiveFromDate.value !== null && this.effectiveToDate.value !== null) {
      this.effectiveErrorText = null;
    }

    // Premium Due Date selection
    if (this.premiumFromDate.value === null && this.premiumToDate.value === null) {
      this.premiumErrorText = null;
    } else if (this.premiumFromDate.value !== null && this.premiumToDate.value === null) {
      this.premiumErrorText = 'Please select Premium Due to date';
    } else if (this.premiumFromDate.value === null && this.premiumToDate.value !== null) {
      this.premiumErrorText = 'Please select Premium Due from date';
    } else if (this.effectiveFromDate.value !== null && this.effectiveToDate.value !== null) {
      this.premiumErrorText = null;
    }
  }

  applyfilter() {
    this.dateSelectError();
    // console.log('form values', this.filterForm.value);
    this._router.navigate([], {
      queryParams: {
        policyStatus: this.policyStatus.value,
        insuredName: this.insuredName.value,
        lastName: this.lastName.value,
        firstName: this.firstName.value,
        ownerLastName: this.ownerLastName.value,
        ownerFirstName: this.ownerFirstName.value,
        insureFromDate: this.insureFromDate.value,
        insureToDate: this.insureToDate.value,
        effectiveFromDate: this.effectiveFromDate.value,
        effectiveToDate: this.effectiveToDate.value,
        premiumFromDate: this.premiumFromDate.value,
        premiumToDate: this.premiumToDate.value,
        gracePeriod: this.gracePeriod.value,
        productName: this.productName.value
      }
    });

    setTimeout(() => {
      if ( this.insuredDOBErrorText !== null || this.effectiveErrorText !== null || this.premiumErrorText !== null) {
        return;
    } else {
      this.dialogRef.close(this.filterForm.value);
    }
    }, 1000);

  }

  // Insurance from date
  yearPickerInsureFromDate(normalizedYear: Moment) {
    const ctrlValue = moment().startOf('month');
    ctrlValue.year(normalizedYear.year());
    this.insureFromDate.setValue(ctrlValue);
  }
  monthPickerInsureFromDate(normlizedMonth: Moment, datepicker: MatDatepicker<Moment>) {
    this.isDatePickerClose = true;
    const ctrlValue = this.insureFromDate.value;
    this.insuraceFrom = this.insureFromDate.value;
    ctrlValue.month(normlizedMonth.month());
    this.insureFromDate.setValue(ctrlValue.format('YYYYMMDD'));
    this.isDateDisabled = false;
    this.insureFromDateClear = true;
    datepicker.close();
  }

  // Insurance to date
  yearPickerInsureToDate(normalizedYear: Moment) {
    const ctrlValue = moment().endOf('month');
    ctrlValue.year(normalizedYear.year());
    this.insureToDate.setValue(ctrlValue);
  }
  monthPickerInsureToDate(normlizedMonth: Moment, datepicker: MatDatepicker<Moment>) {
    this.isDatePickerClose = true;
    const ctrlValue = this.insureToDate.value;
    this.insuraceTo = this.insureToDate.value;
    ctrlValue.month(normlizedMonth.month());
    this.insureToDate.setValue(ctrlValue.format('YYYYMMDD'));
    this.insureToDateClear = true;
    datepicker.close();
  }

  // Effective from date
  yearPickerEffectiveFromDate(normalizedYear: Moment) {
    const ctrlValue = moment().startOf('month');
    ctrlValue.year(normalizedYear.year());
    this.effectiveFromDate.setValue(ctrlValue);
  }
  monthPickerEffectiveFromDate(normlizedMonth: Moment, datepicker: MatDatepicker<Moment>) {
    const ctrlValue = this.effectiveFromDate.value;
    this.effectiveFrom = this.effectiveFromDate.value;
    ctrlValue.month(normlizedMonth.month());
    this.effectiveFromDate.setValue(ctrlValue.format('YYYYMMDD'));
    this.isDisabled = false;
    this.effectiveFromDateClear = true;
    datepicker.close();
  }

  // Effective to date
  yearPickerEffectiveToDate(normalizedYear: Moment) {
    const ctrlValue = moment().endOf('month');
    ctrlValue.year(normalizedYear.year());
    this.effectiveToDate.setValue(ctrlValue);
  }
  monthPickerEffectiveToDate(normlizedMonth: Moment, datepicker: MatDatepicker<Moment>) {
    const ctrlValue = this.effectiveToDate.value;
    this.effectiveTo = this.effectiveToDate.value;
    ctrlValue.month(normlizedMonth.month());
    this.effectiveToDate.setValue(ctrlValue.format('YYYYMMDD'));
    this.isDisabled = true;
    this.effectiveToDateClear = true;
    datepicker.close();
  }

  // Premium Due from date
  yearPickerPremiumFromDate(normalizedYear: Moment) {
    const ctrlValue = moment().startOf('month');
    ctrlValue.year(normalizedYear.year());
    this.premiumFromDate.setValue(ctrlValue);
  }
  monthPickerPremiumFromDate(normlizedMonth: Moment, datepicker: MatDatepicker<Moment>) {
    const ctrlValue = this.premiumFromDate.value;
    this.premiumFrom = this.premiumFromDate.value;
    ctrlValue.month(normlizedMonth.month());
    this.premiumFromDate.setValue(ctrlValue.format('YYYYMMDD'));
    this.isDisabled = false;
    this.premiumFromDateClear = true;
    datepicker.close();
  }

  // Premium Due to date
  yearPickerPremiumToDate(normalizedYear: Moment) {
    const ctrlValue = moment().endOf('month');
    ctrlValue.year(normalizedYear.year());
    this.premiumToDate.setValue(ctrlValue);
  }
  monthPickerPremiumToDate(normlizedMonth: Moment, datepicker: MatDatepicker<Moment>) {
    const ctrlValue = this.premiumToDate.value;
    this.premiumTo = this.premiumToDate.value;
    ctrlValue.month(normlizedMonth.month());
    this.premiumToDate.setValue(ctrlValue.format('YYYYMMDD'));
    this.isDisabled = true;
    this.premiumToDateClear = true;
    datepicker.close();
  }



}
