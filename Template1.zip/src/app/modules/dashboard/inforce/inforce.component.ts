import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { AppConstants } from '@app/app.constants';
import { Router } from '@angular/router';
import { InforceService } from '@app/core/services/inforce/inforce.service';

@Component({
  selector: 'app-inforce',
  templateUrl: './inforce.component.html',
  styleUrls: ['./inforce.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class InforceComponent implements OnInit {

  title = this.app.inforceTitle;
  viewList = this.app.viewCompleteList;
  illustrationText = this.app.illustrationText;
  ctaArrowIcon = this.app.ctaArrowIcon;

  constructor(
    private app: AppConstants,
    private router: Router,
    private policy: InforceService
  ) { }

  ngOnInit() {
  }
  getSelectValue() {
    this.router.navigate(['/inforce', `${this.viewList}`, 'all']);
  }

}
