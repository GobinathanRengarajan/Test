import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MomentDateAdapter } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import * as moment from 'moment';
import { Moment } from 'moment';
import { MatDatepicker } from '@angular/material';
import { InforceService } from '@services/inforce/inforce.service';
import { AppConstants } from '@app/app.constants';
import { Router } from '@angular/router';

// const moment =  _moment;

export const MY_FORMATS = {
  parse: {
    dateInput: 'MM/YYYY',
  },
  display: {
    dateInput: 'MM/YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

@Component({
  selector: 'app-upcoming-birthday',
  templateUrl: './upcoming-birthday.component.html',
  styleUrls: ['./upcoming-birthday.component.scss'],
  providers: [
    { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
  ]
})
export class UpcomingBirthdayComponent implements OnInit {

  // upcoming birthday
  getIcon = this.app.upcomingBirthdayIcon;
  getLabel = this.app.getLabelUpcomingBirthday;
  dataCount: any = [];
  getDays: any;
  isDataAvailable = false;
  reslutDataCount: string;
  // minDate = moment().add(1, 'month');
  date = new FormControl(moment().add(1, 'month'));

  constructor(
    private policy: InforceService,
    private app: AppConstants,
    private router: Router
  ) { }

  ngOnInit() {
    if (this.dataCount.length === 0) {
      this.reslutDataCount = this.dataCount.length;
    }
    this.getMonthYear();
  }

  // Redirect to landing page and pass the seleted date period
  getSelectValue() {
    if (this.isDataAvailable) {
      this.router.navigate(['/inforce', `${this.getLabel}`, `${this.date.value.format('MM')}`]);
    }
  }



  // default year picker
  yearPicker(normalizedYear: Moment) {
    const ctrlValue = this.date.value;
    ctrlValue.year(normalizedYear.year());
    this.date.setValue(ctrlValue);
  }
  leadingZero(n) {
    return (n < 10) ? ('0' + n) : n;
  }
  // calender month picker
  monthPicker(normlizedMonth: Moment, datepicker: MatDatepicker<Moment>) {
    const ctrlValue = this.date.value;
    ctrlValue.month(normlizedMonth.month());
    this.date.setValue(ctrlValue);
    datepicker.close();
    // send date range api call
    const passMonth = this.date.value.format('MM');
    this.policy.getBirthdayMonth(passMonth);
    console.log('Upcoming birthday month and year', passMonth);
    this.getDays = this.date.value.format('MMM');
    this.policy.getUpcomingBirthdayData(localStorage.getItem('userId'), this.date.value.format('MM'))
      .subscribe(data => {
        this.dataCount = data.filter(res => res.Relate_Code === 'IN').map(res => {
        });
        console.log(data);
        if (data.length >= 1) {
          // this.reslutDataCount = ('0' + this.dataCount.length).slice(-2);
          this.reslutDataCount = this.leadingZero(this.dataCount.length);
        } else {
          this.reslutDataCount = '0';
        }
        // this.dataCount = data;
        if (data.length >= 1) {
          this.isDataAvailable = true;
        }
      });
  }

  getMonthYear() {
    // send date range api call
    this.getDays = 'Next Month';
    this.policy.getBirthdayMonth(this.date.value.format('MM'));
    this.policy.getUpcomingBirthdayData(localStorage.getItem('userId'), this.date.value.format('MM'))
      .subscribe(data => {
        this.dataCount = data.filter(res => res.Relate_Code === 'IN').map(res => {
        });
        // this.dataCount = data;
        if (data.length >= 1) {
          // this.reslutDataCount = ('0' + this.dataCount.length).slice(-2);
          this.reslutDataCount = this.leadingZero(this.dataCount.length);
        } else {
          this.reslutDataCount = '0';
        }
        if (data.length >= 1) {
          this.isDataAvailable = true;
        }
      });
  }

}
