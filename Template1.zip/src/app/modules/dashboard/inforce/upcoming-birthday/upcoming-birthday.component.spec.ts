import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { UpcomingBirthdayComponent } from './upcoming-birthday.component';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AuthService } from '@app/core/authentication/auth.service';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { MatDatepickerModule } from '@angular/material';
import { MaterialModule } from '@app/modules/material/material.module';
import { ReactiveFormsModule, FormsModule, FormControl } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppConstants } from '@app/app.constants';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import * as moment from 'moment';

describe('MonthPickerComponent', () => {
  let component: UpcomingBirthdayComponent;
  let fixture: ComponentFixture<UpcomingBirthdayComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpcomingBirthdayComponent ],
      imports: [
        HttpClientModule,
        BrowserAnimationsModule,
        BrowserDynamicTestingModule,
        RouterTestingModule,
        MatDatepickerModule,
        FormsModule,
        ReactiveFormsModule,
        MaterialModule
      ],
      providers: [AuthService, AppConstants, UpcomingBirthdayComponent],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA ]

    })
    .compileComponents();
    component = TestBed.get(UpcomingBirthdayComponent);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpcomingBirthdayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  const nextMonth = moment().add(1, 'month');

  // current policy
  it(`should coming birthday first date shoult be ${nextMonth.format('MMMM')}`, () => {
    const month = component.date;
    expect(month.value.format('MMMM')).toEqual(nextMonth.format('MMMM'));
  });
  it(`should have as title 'Coming Birthday'`, () => {
    const text = component.getLabel;
    expect(text).toEqual('Coming Birthday');
  });

});
