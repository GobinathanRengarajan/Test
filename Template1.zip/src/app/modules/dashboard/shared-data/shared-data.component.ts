import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-shared-data',
  templateUrl: './shared-data.component.html',
  styleUrls: ['./shared-data.component.scss']
})
export class SharedDataComponent implements OnInit {

  dataCountValue = 0;

  @Input()
  get dataCount(): number {
    return this.dataCountValue;
  }

  @Output() dataCountChange = new EventEmitter();

  set dataCount(val) {
    this.dataCountValue = val;
    this.dataCountChange.emit(this.dataCountValue);
  }

  @Input('getLabel') getLabel: number;
  @Input('getDays') getDays: number;
  @Input('getIcon') getIcon: number;

  constructor() { }

  ngOnInit() {
  }

}
