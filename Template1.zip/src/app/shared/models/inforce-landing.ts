export interface InforceLandPolicy {
    Policy_Number: string;
    Producer_ID: string;
    Client_Name: string;
    Contract_Code: string;
    IO_Last: string;
    IO_First: string;
    IO_Middle: string;
    Owner_Last: string;
    Owner_First: string;
    Owner_Middle: string;
    Market_Name: string;
    Contract_Date: string;
    Pn_Last: string;
    Pn_First: string;
    Pn_Middle: string;
    Date_Of_Birth: string;
    Insured_DOB: string;
    Billing_Date: string;
    Issue_Date: string;
    Due_Date: string;
    Default_Grace_Period: string;
    Status: string;
    Agent_Num: string;
    Relate_Code: string;
    Sum_Assured: string;
}
