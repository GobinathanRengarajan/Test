export class MoreNewsDetails {
    ID: string;
    Title: string;
    Description: string;
    Author: string;
    CreatedBy: string;
    RecordCreated_Date: string;
    RecordChanged_Date: string;
    RecordChange_Type: string;
    IsActive: string;
    publishStatus: number;
    defaultImage: string;
    defaultImageURL: string;
    }
