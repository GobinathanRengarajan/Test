export interface NBLandPolicy {
    PolicyNumber: string;
    Status: string;
    Product: string;
    LastName: string;
    FirstName: string;
    MiddleName: string;
    SumAssured: string;
    BrokerName: string;
    DateofBirth: string;
    PremimumDueDate: string;
    ProducerId: string;
    ProducerName: string;
}
