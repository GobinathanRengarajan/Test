export class NewsDetail {
    ID: string;
    Description: string;
    Author: string;
    CreatedBy: string;
    RecordCreated_Date: string;
    RecordChanged_Date: string;
    RecordChange_Type: string;
    IsActive: string;
    publishStatus: string;
    Images: string;
    }
