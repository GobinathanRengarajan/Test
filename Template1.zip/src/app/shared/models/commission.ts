export class Commission {
}
