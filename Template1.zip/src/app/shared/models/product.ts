export interface Product {
    Product_ID: string;
    Heading: string;
    Description: string;
    IsActive: string;
    IsInBermuda: string;
    IsInHongKong: string;
    IsInSingapore: string;
    RecordChanged_Date: string;
    RecordCreated_Date: string;
    publishStatus: number;
    SPList: any;
}
