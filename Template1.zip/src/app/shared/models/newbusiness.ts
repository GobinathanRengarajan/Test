
export class NewBusinessPolicy {

    PolicyNumber: string;
    LastName: string;
    FirstName: string;
    MiddleName: string;
    DateofBirth: string;
    Status: string;
    PremimumDueDate: string;
    ApplicationNumber: string;
    SumAssured: string;
    PremiumTerm: string;
    ProducerId: string;
    ApplicationSignDate: string;
    UWClass: string;
    Product: string;
    PolicyOwnerLastName: string;
    PolicyOwnerFirstName: string;
    PolicyOwnerMiddleName: string;
    PremiumAmount: string;
    PremiumPaymentFrequency: string;
    ProducerName: string;
    AcceptanceLetterGenerationDate: string;
    AcceptanceLetterExpirynDate: string;
}


