export interface Policydetails {
  // Policy_Number: string;
  // // Surname:string;
  // Clientname:string;
  // Policystatus:string;
  // Duedate:string;
  // Servicingagent:string;

  Insured_Birthday: string;
  Issue_Date: string;
  Owner_Birthday: string;
  Payment_Date: string;
  Policy_Code: string;
  Policy_Number: string;
  Product_Code: string;


  /*  PolicyDetailList should have same DB schema as Policydetail and it is just a list of PolicyDetail only.
  Following are the fields copied from PolicyDeatailList, add back to PolicyDetail when needed.
  Information_as_off:string;
    Insured:string;
    Gender:string;
    Insured_dob:string;
    Insured_SSN:string;
    Company:string;
    Policy_Number: string;
    Policy_Type:string;
    Product_Name:string;
    Plan:string;
    Raised_Policy:string;
    Underwriting_class:string;
    Issue_Date:string;
    Kind_Code:string;
    Policy_Effective_Date:string;
    Status:string;
    Servicing_Agent:string;
    Servicing_Office:string;
    OWGA:string; */
}
