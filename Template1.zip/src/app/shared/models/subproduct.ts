export interface Subproduct {
    POLICY_CURRENCY: string;
    INSURER_AGE: string;
    MATURITY_DATE: string;
    UNSCH_PREM: string;
    MIN_SUM_ASSU: string;
    DEATH_BEN: string;
    GUA_MIN_CRD_INT_RATE: string;
    LOCKIN_CRD_INT_RATE: string;
    CRD_INT_RATE: string;
    DISCLAIMER: string;
    PREM_PAYMODE_FREQ: string;
    SubProduct_ID: string;
    publishStatus: number;
    Product_ID: string;
    HEADING: string;
    INSURER: string;
}
