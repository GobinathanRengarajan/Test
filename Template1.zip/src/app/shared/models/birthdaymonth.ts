export interface BirthdayMonth {
  value: string;
  viewValue: string;
}
