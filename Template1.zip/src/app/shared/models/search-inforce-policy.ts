import {jsonObject, jsonMember} from 'typedjson';
import {DatePipe} from '@angular/common';

@jsonObject
export class SearchInforceLanding {

    @jsonMember
    PolicyNumber: String;

    @jsonMember
    IO_Last: String;

    @jsonMember
    IO_First: String;

    @jsonMember
    IO_Middle: String;

    @jsonMember
    Date_Of_Birth: String;

    @jsonMember
    Contract_Code: String;

    @jsonMember
    Billing_Date: String;

    @jsonMember
    Agent_Num: String;


    get ClientName(): String {
        return this.IO_Last + ' ' + this.IO_First + ' ' + this.IO_Middle;
    }

    get Date_Of_Birth_in_Date(): Date {
        if (this.Date_Of_Birth != null) {
            return new Date(this.Date_Of_Birth.replace(/(\d{4})(\d{2})(\d{2})/, '$1-$2-$3'));
        } else {
            return null;
        }
    }

    get Billing_Date_in_Date(): Date {
        if (this.Billing_Date != null) {
            return new Date(this.Billing_Date.replace(/(\d{4})(\d{2})(\d{2})/, '$1-$2-$3'));
        } else {
            return null;
        }
    }
}
