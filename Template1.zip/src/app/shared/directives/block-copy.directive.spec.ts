import { BlockCopyDirective } from './block-copy.directive';

describe('BlockCopyDirective', () => {
  it('should create an instance', () => {
    const directive = new BlockCopyDirective();
    expect(directive).toBeTruthy();
  });
});
