import { Directive, ElementRef, OnInit, Renderer2 } from '@angular/core';


const eyeCrossed = 'assets/images/icons/password-in-active.png';
const eye = 'assets/images/icons/password.png';

@Directive({
  selector: '[appPasswordToggle]'
})
export class PasswordToggleDirective implements OnInit {

  visible = false;



  constructor(public elem: ElementRef, public renderer: Renderer2) { }

  ngOnInit() {
    const inputElem = this.elem.nativeElement;
    const parentElem = inputElem.parentElement;
    this.renderer.setStyle(parentElem, 'position', 'relative');

    const inputElemHeight = inputElem.offsetHeight;
    const inputElemTop = inputElem.offsetTop;
    this.renderer.setStyle(inputElem, 'padding-right', (inputElemHeight + 5) + 'px');

    // create toggle button
    const toggleElem = this.renderer.createElement('div');
    this.renderer.addClass(toggleElem, 'view_pwd');
    this.renderer.setStyle(toggleElem, 'position', 'absolute');
    this.renderer.setStyle(toggleElem, 'top', '15px');
    this.renderer.setStyle(toggleElem, 'right', '90px');
    this.renderer.setStyle(toggleElem, 'width', '20px');
    this.renderer.setStyle(toggleElem, 'height', '24px');
    this.renderer.setStyle(toggleElem, 'cursor', 'pointer');
    this.renderer.setStyle(toggleElem, 'opacity', '0.6');
    this.renderer.setStyle(toggleElem, 'background-color', 'transparent');
    this.renderer.setStyle(toggleElem, 'background-repeat', 'no-repeat');
    this.renderer.setStyle(toggleElem, 'background-position', 'center center');
    this.renderer.setStyle(toggleElem, 'background-image', `url(${eyeCrossed})`);

    // append toggle element to input element holder
    this.renderer.appendChild(parentElem, toggleElem);

    // listen to click event on toggle button
    this.renderer.listen(toggleElem, 'click', (event) => {
      this.visible = !this.visible;
      this.renderer.setStyle(toggleElem, 'background-image', `url(${this.visible ? eye : eyeCrossed})`);

      this.renderer.setAttribute(inputElem, 'type', this.visible ? 'text' : 'password');
    });
  }

}

