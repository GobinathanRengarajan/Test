import { environment } from '../environments/environment';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientJsonpModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { NgModule, NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ServiceWorkerModule } from '@angular/service-worker';
// import { JwtInterceptor, ErrorInterceptor } from './core/helpers/';

// modules--include--here
import { LoginModule } from './modules/login/login.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule, routing } from './routing.module';
import { RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { LoginComponent } from './modules/login/login.component';
import { AdminComponent } from './components/admin/admin.component';
import { SearchComponent } from './components/search/search.component';
import { PolicydetailsComponent } from './components/policydetails/policydetails.component';
import { ProductComponent } from './components/product/product.component';
import { NotfoundComponent } from './components/notfound/notfound.component';
import { CreatepackageComponent } from './components/createpackage/createpackage.component';
import { ProductdetailComponent } from './components/productdetail/productdetail.component';
// import { NewsComponent } from './components/news/news.component';
import { NewsdetailComponent } from './components/news/newsdetail/newsdetail.component';
import { NewsbulletinComponent } from './components/news/newsbulletin/newsbulletin.component';

// custom-directive-include--here
import { BlockCopyDirective } from './shared/directives/block-copy.directive';
import { PasswordToggleDirective } from './shared/directives/password-toggle.directive';

import { NgHttpLoaderModule } from 'ng-http-loader';
import { LoggerModule, NgxLoggerLevel } from 'ngx-logger';

// custom module
import { MaterialModule } from './modules/material/material.module';
import { DashboardModule } from './modules/dashboard/dashboard.module';
import { Interceptor } from './core/interceptors/interceptor.service';

// Service--included--here
import { AuthService } from './core/authentication/auth.service';
import { AuthGuard } from './core/authentication/auth.guard';
// import {MockService} from '../app/core/services/mock.service';
// import {MockNbService} from '../app/core/services/mocknb.service';
import { AppConstants } from './app.constants';
import { CookieService } from 'ngx-cookie-service';

import { NoresultsfoundComponent } from './components/noresultsfound/noresultsfound.component';
import { ContactUsComponent } from './components/contact-us/contact-us.component';
import { TermsConditionComponent } from './components/terms-condition/terms-condition.component';
import { PrivacyPolicyComponent } from './components/privacy-policy/privacy-policy.component';
import { MyProfileComponent } from './components/my-profile/my-profile.component';
import { IfisComponent } from './components/ifis/ifis.component';
import { MatDialogModule } from '@angular/material';

import { fakeBackendProvider } from './core/helpers/fake-backend';

import { FilterPipe } from '@app/pipe/filterPipe';
import { APP_INITIALIZER } from '@angular/core';
import { AppConfig } from '@app/app.config';

import { EmailformsComponent } from '@app/components/emailforms/emailforms.component';
import { EmailsuccessComponent } from '@app/components/emailsuccess/emailsuccess.component';
import { AreyousureDialogueComponent } from './components/areyousure-dialogue/areyousure-dialogue.component';
import { FiltersearchPipe } from '@app/pipe/filtersearch.pipe';
import { SlideshowModule } from 'ng-simple-slideshow';

export function initConfig(config: AppConfig) {
  return () => config.load();
}

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    AdminComponent,
    PolicydetailsComponent,
    BlockCopyDirective,
    PasswordToggleDirective,
    SearchComponent,
    NotfoundComponent,
    NoresultsfoundComponent,
    CreatepackageComponent,
    ContactUsComponent,
    TermsConditionComponent,
    PrivacyPolicyComponent,
    MyProfileComponent,
    ProductComponent,
    ProductdetailComponent,
    FilterPipe,
    FiltersearchPipe,
    IfisComponent,
    EmailformsComponent,
    EmailsuccessComponent,
    NewsbulletinComponent,
    NewsdetailComponent,
    AreyousureDialogueComponent
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    HttpClientJsonpModule,
    routing,
    FormsModule,
    // custom module
    MaterialModule,
    MatDialogModule,
    DashboardModule,
    BrowserAnimationsModule,
    RouterModule,
    LoginModule,
    SlideshowModule,
    // service worker
    ServiceWorkerModule.register('/ngsw-worker.js', { enabled: environment.production }),
    NgHttpLoaderModule,
    // LoggerModule.forRoot({serverLoggingUrl: '/api/logs', level: NgxLoggerLevel.DEBUG, serverLogLevel: NgxLoggerLevel.ERROR,
    // Logger config based on environment
    LoggerModule.forRoot({
      level: !environment.production ? NgxLoggerLevel.LOG : NgxLoggerLevel.OFF,
      // serverLogLevel
      serverLogLevel: NgxLoggerLevel.OFF
    })
  ],
  entryComponents: [
    CreatepackageComponent,
    EmailformsComponent,
    EmailsuccessComponent,
    AreyousureDialogueComponent
  ],
  providers: [
    // MockService,
    AuthService,
    AuthGuard,
    fakeBackendProvider,
    CookieService,
    // { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true },
    // { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },
    // MockNbService,
    { provide: HTTP_INTERCEPTORS, useClass: Interceptor, multi: true },
    AppConfig,
    {
      provide: APP_INITIALIZER,
      useFactory: initConfig,
      deps: [AppConfig],
      multi: true
    },
    AppConstants
  ],
  bootstrap: [AppComponent],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA,
    NO_ERRORS_SCHEMA
  ],
})
export class AppModule {
}
