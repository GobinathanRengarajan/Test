import { FiltersearchPipe } from './filtersearch.pipe';

describe('FiltersearchPipe', () => {
  it('create an instance', () => {
    const pipe = new FiltersearchPipe();
    expect(pipe).toBeTruthy();
  });
});
