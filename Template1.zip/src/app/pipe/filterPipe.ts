import { Pipe, PipeTransform } from '@angular/core';
@Pipe({
  name: 'filter'
})

export class FilterPipe implements PipeTransform {
        transform(value: string): any {
          if (value != null) {
            return value.replace(/<.*?>/g, '');
          } else {
            return '';
          }

        }
}
