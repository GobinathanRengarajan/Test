import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filtersearch'
})
export class FiltersearchPipe implements PipeTransform {

  transform(value, term) {
    console.log(term + ' ' + value);
    if (term == null) {
        return null;
    }
    return value.filter((item) => {
        return item.Email.includes(term) || item.FirstName.includes(term) || item.LastName.includes(term);
    });
}

}
