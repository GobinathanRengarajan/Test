import { AppConstants } from './../../app.constants';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent implements OnInit {

  footerText = this.app.footerText;

  constructor(private app: AppConstants) { }

  ngOnInit() {
  }

}
