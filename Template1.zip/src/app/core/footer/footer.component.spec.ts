import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FooterComponent } from './footer.component';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { AuthService } from '../authentication/auth.service';
import { AppConstants } from '@app/app.constants';

describe('FooterComponent', () => {
  let component: FooterComponent;
  let fixture: ComponentFixture<FooterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
    declarations: [ FooterComponent ],
    imports: [BrowserDynamicTestingModule, RouterTestingModule],
    providers: [AuthService, AppConstants],
    schemas: [ CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FooterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it(`Checking the footer text`, async(() => {
    const fixtures = TestBed.createComponent(FooterComponent);
    const app = fixtures.debugElement.componentInstance;
    expect(app.footerText).toEqual('2019 Transamerica Corporation, All Rights Reserved.');
  }));
});
