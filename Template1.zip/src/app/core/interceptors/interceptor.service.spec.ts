import { AuthService } from './../authentication/auth.service';
import { RouterTestingModule } from '@angular/router/testing';
import {TestBed, inject} from '@angular/core/testing';
import {HttpClientTestingModule} from '@angular/common/http/testing';

import {Interceptor} from '@core/interceptors/interceptor.service';

import { NGXLogger } from 'ngx-logger';
import { MatDialog } from '@angular/material';
import { NO_ERRORS_SCHEMA } from '@angular/core';
describe('Interceptor', () => {
    beforeEach(() => {
      TestBed.configureTestingModule({
        schemas: [NO_ERRORS_SCHEMA],
        imports: [ RouterTestingModule, HttpClientTestingModule],
        providers: [Interceptor, AuthService,

            { provide: NGXLogger, useClass: class {} },
            { provide: MatDialog, useClass: class {} }]
      });
    });

    it('should be created', inject([Interceptor], (service: Interceptor) => {
      expect(service).toBeTruthy();
    }));
  });

