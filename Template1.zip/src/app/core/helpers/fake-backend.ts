import { Injectable } from '@angular/core';
import { HttpRequest, HttpResponse, HttpHandler, HttpEvent, HttpInterceptor, HTTP_INTERCEPTORS } from '@angular/common/http';
import { Observable, of, throwError } from 'rxjs';
import { delay, mergeMap, materialize, dematerialize } from 'rxjs/operators';
import { User } from '../authentication/user';
import { Role } from '../../shared/models/role';

@Injectable()
export class FakeBackendInterceptor implements HttpInterceptor {
    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        const users: User[] = [
            {
                id: 1, email: 'VijayBM@hcl.com', username: 'admin', password: 'admin', firstName: 'Admin',
                lastName: 'User', role: Role.Admin, email2: 'admin@tlb-test.com', username2: 'Admin testuser'
            },
            {
                id: 2, email: 'VijayBM@hcl.com', username: 'user', password: 'user', firstName: 'Normal',
                lastName: 'User', role: Role.User, email2: 'user@tlb-test.com', username2: 'User testuser'
            },
            {
                id: 3, email: 'stanley.li@transamerica.com', username: 'stanley.li@transamerica.com', password: '123456789', firstName: 'Distributor',
                lastName: 'Distributor', role: Role.User, email2: 'distributor@tlb-test.com', username2: 'Distributor testuser'
            },
            {
                id: 4, email: 'esther.chan@transamerica.com', username: 'esther.chan@transamerica.com', password: '123456789', firstName: 'Producer',
                lastName: 'Producer', role: Role.User, email2: 'producer@tlb-test.com', username2: 'Producer testuser'
            },
            {
                id: 5, email: 'carrie.ng@transamerica.com', username: 'carrie.ng@transamerica.com', password: '123456789', firstName: 'Case Manager',
                lastName: 'Case Manager', role: Role.User, email2: 'esther@chan.com', username2: 'Esther Chan'
            },
            {
                id: 6, email: 'stephen.mo@transamerica.com', username: 'stephen.mo@transamerica.com', password: '123456789', firstName: 'Staff',
                lastName: 'Staff', role: Role.Admin, email2: 'esther@chan.com', username2: 'Esther Chan'
            }
        ];

        const authHeader = request.headers.get('Authorization');
        const isLoggedIn = authHeader && authHeader.startsWith('Bearer fake-jwt-token');
        const roleString = isLoggedIn && authHeader.split('.')[1];
        const role = roleString ? Role[roleString] : null;


        return of(null).pipe(mergeMap(() => {


            if (request.url.endsWith('/users/authenticate') && request.method === 'POST') {
                const user = users.find(x => x.username === request.body.username && x.password === request.body.password);
                if (!user) { return error('Username or password is incorrect'); }
                return ok({
                    id: user.id,
                    email: user.email,
                    username: user.username,
                    firstName: user.firstName,
                    lastName: user.lastName,
                    role: user.role,
                    username2: user.username2,
                    email2: user.email2,
                    token: `fake-jwt-token.${user.role}`
                });
            }


            if (request.url.match(/\/users\/\d+$/) && request.method === 'GET') {
                if (!isLoggedIn) { return unauthorised(); }


                const urlParts = request.url.split('/');
                const id = parseInt(urlParts[urlParts.length - 1], 0);


                const currentUser = users.find(x => x.role === role);
                if (id !== currentUser.id && role !== Role.Admin) { return unauthorised(); }

                const user = users.find(x => x.id === id);
                return ok(user);
            }


            if (request.url.endsWith('/users') && request.method === 'GET') {
                if (role !== Role.Admin) { return unauthorised(); }
                return ok(users);
            }


            return next.handle(request);
        }))

            .pipe(materialize())
            .pipe(delay(500))
            .pipe(dematerialize());



        function ok(body) {
            return of(new HttpResponse({ status: 200, body }));
        }

        function unauthorised() {
            return throwError({ status: 401, error: { message: 'Unauthorised' } });
        }

        function error(message) {
            return throwError({ status: 400, error: { message } });
        }
    }
}

export let fakeBackendProvider = {

    provide: HTTP_INTERCEPTORS,
    useClass: FakeBackendInterceptor,
    multi: true
};
