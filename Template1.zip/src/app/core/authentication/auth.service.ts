import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import { map } from 'rxjs/operators';
import { User } from './user';
import { MwadaptorService } from '@services/mwadaptor/mwadaptor.service';

@Injectable()
export class AuthService {

  private currentUserSubject: BehaviorSubject<User>;
  public currentUser: Observable<User>;

  private loggedIn: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);

  get isLoggedIn() {
    return this.loggedIn.asObservable();
  }


  constructor(private http: HttpClient, private mwService: MwadaptorService) {
    this.currentUserSubject = new BehaviorSubject<User>(JSON.parse(localStorage.getItem('currentUser')));
    this.currentUser = this.currentUserSubject.asObservable();
  }


  public get currentUserValue(): User {
    return this.currentUserSubject.value;
  }


  getUserLocation(userLocation) {
    const params: string = '?emailID=' + userLocation;

    return this.mwService.getPamUserLocation('GetUsertoPortal', params);
  }

  login(username: string, password: string) {
    return this.http.post<any>(`/users/authenticate`, { username, password })
      .pipe(map(user => {
        if (user && user.token) {
          localStorage.setItem('currentUser', JSON.stringify(user));
          console.log('user detail', user);
          // Hard coded login ID
          if ((user.username == 'admin') || (user.username == 'tlbstaff')) {
            localStorage.setItem('userId', 'stephen.mo@transamerica.com'); // Sample userId value but not the correct.

          } else if (user.firstName == 'Distributor') {
            localStorage.setItem('userId', 'stanley.li@transamerica.com'); // Sample userId value but not the correct.
          } else if (user.firstName == 'Case Manager') {
            //For Case Manager, we will pass the email to Policy API
            localStorage.setItem('userId', 'carrie.ng@transamerica.com'); // Sample userId value but not the correct.
          } else if (user.firstName == 'Producer') {
            localStorage.setItem('userId', 'esther.chan@transamerica.com'); // Sample userId value but not the correct.
          } else {
            //just place admin value here only, production don't do it.
            localStorage.setItem('userId', 'stephen.mo@transamerica.com');
          }
          this.currentUserSubject.next(user);
        }

        return user;
      }));
  }

  logout() {
    localStorage.removeItem('currentUser');
    // localStorage.removeItem('userId');
    this.currentUserSubject.next(null);
  }

}
