import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';


import { AuthService } from './auth.service';

@Injectable()

export class AuthGuard implements CanActivate {


    constructor(private authService: AuthService, private router: Router) { }
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
        const currentUser = this.authService.currentUserValue;

        if (currentUser) {
            this.authService.getUserLocation(currentUser.email).subscribe(res => {
                if (res) {
                    const dataRes = [];
                    dataRes.push(res);
                    dataRes.map(data => localStorage.setItem('EmailID', data.EmailID));
                    dataRes.map(data => localStorage.setItem('FirstName', data.FirstName));
                    dataRes.map(data => localStorage.setItem('LastName', data.LastName));
                    dataRes.map(data => localStorage.setItem('ProducerID', data.ProducerID));
                    dataRes.map(data => localStorage.setItem('IsInBermuda', data.IsInBermuda));
                    dataRes.map(data => localStorage.setItem('IsInSingapore', data.IsInSingapore));
                    dataRes.map(data => localStorage.setItem('IsInHongKong', data.IsInHongKong));
                    dataRes.map(data => localStorage.setItem('Commission_Stmt', data.Commission_Stmt));

                }
            },
                err => {
                    console.log(err.error);
                });

            if (route.data.roles && route.data.roles.indexOf(currentUser.role) === -1) {
                this.router.navigate(['/']);
                return false;
            }
            return true;
        }
        this.router.navigate(['/login']);
        return false;
    }
}
