import { Injectable } from '@angular/core';
import { MwadaptorService } from '../mwadaptor/mwadaptor.service';
import { Observable, BehaviorSubject } from 'rxjs';
import { NewBusinessPolicy } from '@app/shared/models/newbusiness';
import { NBLandPolicy } from '@app/shared/models/newbusiness-landing';
import * as moment from 'moment';
@Injectable({
  providedIn: 'root'
})
export class NewbusinessService {

  nbLandingPreSelect = new BehaviorSubject('View Complete List');

  startDate = moment().startOf('year');
  endDate = moment();

  caseIssuedDateRange = {
    startDate: this.startDate.format('YYYYMMDD'),
    endDate: this.endDate.format('YYYYMMDD')
  };
  nbCaseIssued = new BehaviorSubject(this.caseIssuedDateRange);

  constructor(private mwService: MwadaptorService) { }

  // Behavior subject
  getMessage(message: any) {
    this.nbLandingPreSelect.next(message);
  }
  setMessage() {
    return this.nbLandingPreSelect.asObservable();
  }

  // Behavior subject
  getMessageCaseIssued(message: any) {
    this.nbCaseIssued.next(message);
  }
  setMessageCaseIssued() {
    return this.nbCaseIssued.asObservable();
  }

  // case issued /policy/nb/caseissued/<userID>/<fromIssueDate>/<toIssueDate>
  getCaseIssued(userId: string, dateFrom: string, dateTo: string): Observable<NBLandPolicy[]> {

    return this.mwService.get('policy/nb/caseissued', userId, dateFrom, dateTo);
  }

  // accept letter expired /policy/nb/acceptlettersexpireddate/<userID>/<fromAcceptLetterExpiredDate>/<toAcceptLetterExpiredDate>
  getAcceptLetterExpired(userId: string, dateFrom: string, dateTo: string): Observable<NBLandPolicy[]> {

    return this.mwService.get('policy/nb/acceptlettersexpired', userId, dateFrom, dateTo);
  }

  // long pending cases /longpendingcases/<userId>
  getLongPendingCases(userId: string): Observable<NBLandPolicy[]> {

    return this.mwService.get('policy/nb', userId, 'longpendingcases');
  }
  // Pending cases /policy/nb/pendingcases/<userID>
  getPendingCases(userId: string): Observable<NBLandPolicy[]> {

    return this.mwService.get('policy/nb', userId, 'pendingcases');
  }
  // completenblist /policy/nb/all/<userID>
  getcompleteNBlist(userID: string): Observable<NBLandPolicy[]> {
    return this.mwService.get('policy/nb', userID, 'all');
  }
  // getcompleteNBlist(): Observable<NBLandPolicy[]> {
  //   return this.mwService.get('policy/nb/all');
  // }
  // nbpolicydetails /policy/nb/<policyno>
  getnbpolicydetails(userId, policyno: string): Observable<NewBusinessPolicy> {
    return this.mwService.get('policy/nb', userId, policyno);
  }
  // nbpolicydetails /policy/nb/<policyno>
  getnbclientname(userId: string, surName: string, givenName: string): Observable<NBLandPolicy[]> {
    const params = userId + '/clientname?surname=' + surName + '&givenName=' + givenName;

    return this.mwService.getByQueryString('policy/nb', params);
  }

}
