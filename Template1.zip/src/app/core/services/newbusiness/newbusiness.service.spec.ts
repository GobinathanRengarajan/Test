import { TestBed, inject } from '@angular/core/testing';
import { NewbusinessService } from './newbusiness.service';
import { AppConstants } from '@app/app.constants';
import { AuthService } from '@app/core/authentication/auth.service';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { RouterTestingModule } from '@angular/router/testing';

describe('NewbusinessService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [NewbusinessService, AppConstants, AuthService],
      imports: [BrowserDynamicTestingModule, RouterTestingModule, HttpClientTestingModule],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA]
    });
  });

  it('should be created', inject([NewbusinessService], (service: NewbusinessService) => {
    expect(service).toBeTruthy();
  }));
});
