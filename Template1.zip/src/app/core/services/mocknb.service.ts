import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { NewBusinessPolicy } from '../../shared/models/newbusiness';
import { map, filter } from 'rxjs/operators';

@Injectable()
export class MockNbService {
    API_URL = 'http://localhost:3000/newbusiness';
    constructor(private httpClient: HttpClient) { }

    getNbPolicies() {
        return this.httpClient.get(`${this.API_URL}/newbusiness`);
    }

    getNBByPolicyNumber(policyNumber: string) {
        return this.httpClient.get(`${this.API_URL}?Policy_Number=` + policyNumber);
    }

    getPDNBsBySubmissionDate(fromSubmissionDate: string, toSubmissionDate: string): Observable<NewBusinessPolicy> {
        return this.httpClient.get<NewBusinessPolicy>(`${this.API_URL}`).pipe(
            map((data: any) => data
                // tslint:disable-next-line:max-line-length
                .filter(m => new Date(m.Submission_Date) >= new Date(fromSubmissionDate) && new Date(m.Submission_Date) <= new Date(toSubmissionDate))
            ));
    }

    getOfferExpiredNBsBySubmissionDate(fromSubmissionDate: string, toSubmissionDate: string): Observable<NewBusinessPolicy> {
        return this.httpClient.get<NewBusinessPolicy>(`${this.API_URL}`).pipe(
            map((data: any) => data
                // tslint:disable-next-line:max-line-length
                .filter(m => new Date(m.Submission_Date) >= new Date(fromSubmissionDate) && new Date(m.Submission_Date) <= new Date(toSubmissionDate))
            ));
    }

}
