import { TestBed, inject } from '@angular/core/testing';

import { FormsutilityService } from './formsutility.service';

describe('FormsutilityService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [FormsutilityService]
    });
  });

  it('should be created', inject([FormsutilityService], (service: FormsutilityService) => {
    expect(service).toBeTruthy();
  }));
});
