import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { MwadaptorService } from '../mwadaptor/mwadaptor.service';
import { Observable, Subject, BehaviorSubject } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class FormsutilityService {

  constructor(
    private mwService: MwadaptorService,
    private https: HttpClient
  ) { }

  // get custom form packages
  getAllFormsPackages(useremail: string) {
    const userId = localStorage.getItem('userId') + '/';
    return this.mwService.getFormsAPI('GetAllPackages', userId);
    //  return this.mwService.getFormsAPI('GetAllPackages', useremail);
  }

  // add custom packages
  addCustomPackages(formdata) {
    const url = this.mwService.postFormsAPI('AddCustomPackage');
    const httpHeaders = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.https.post<any>(url, formdata, { headers: httpHeaders });
  }

  // update custom packages
  updateCustomPackages(formdata, id: number) {
    const url = this.mwService.putFormsAPI('UpdateCustomPackage', id);
    const httpHeaders = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.https.put<any>(url, formdata, { headers: httpHeaders });
  }
  deleteCustomPackages(formdata) {
    const url = this.mwService.deleteFormsAPI('DeleteCustomPackage');
    const httpHeaders = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.https.put<any>(url, formdata, { headers: httpHeaders });
  }

  // get custom package details
  getCustomPackageDetails(id) {
    return this.mwService.getFormsAPI('GetCustomPackageDetail', id);
  }

  /* Downloading forms from search page */
  searchDownloadForms(country, downloadApiParams): Observable<any> {
    const params: string = country + '?' + downloadApiParams;
    return this.mwService.getDownloadFormsPackagesAPI('DownloadForms/', params);
  }

  /* downloading default forms from forms landing page */
  downloadDefaultForms(defaultFormsParams) {
    return this.mwService.getDownloadFormsPackagesAPI('DownloadDefaultPackage?', defaultFormsParams);
  }

  /* downloading default forms from forms landing page */
  downloadCustomPackage(country, customFormsParams) {
    const params: string = country + '?' + customFormsParams;
    return this.mwService.getDownloadFormsPackagesAPI('DownloadCustomPackage/', params);
  }
  // email custom package forms
  emailCustomPacakgeForms(country, emailApiParams) {
    const params: string = country + '?' + emailApiParams;
    return this.mwService.sendEmailForms('SendEmailCustomPackagesForms/' + params);
  }

  emailDefaultPackages(emailDefaultApiParams) {
    return this.mwService.sendEmailForms('SendEmailDefaultPackages' + emailDefaultApiParams);
  }

  emailForms(country, emailApiParams) {
    const params: string = country + '?' + emailApiParams;
    return this.mwService.sendEmailForms('SendEmailForms/' + params);
  }

  extractFormbyDoc(country, docName: string): Observable<any> {
    const params: string = docName + '/' + country;
    return this.mwService.getFormDownloadAPI('DownloadForm', params);

  }

}
