import { TestBed } from '@angular/core/testing';

import { LaserficheService } from './laserfiche.service';

describe('LaserficheService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: LaserficheService = TestBed.get(LaserficheService);
    expect(service).toBeTruthy();
  });
});
