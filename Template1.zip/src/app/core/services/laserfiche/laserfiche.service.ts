import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of, BehaviorSubject } from 'rxjs';
import { MwadaptorService } from '../mwadaptor/mwadaptor.service';
import { AppConfig } from '@app/app.config';

@Injectable({
  providedIn: 'root'
})
export class LaserficheService {
  Repositorydetails: string;
  DistributorGuidePath: string;
  CorporateBrochurePath: string;
  constructor(private http: HttpClient, private mwService: MwadaptorService, private config: AppConfig) { }

  searchFormsResult = new BehaviorSubject<Array<any>>([]);
  // Behavior subject
  getMessage(data: any) {
    this.searchFormsResult.next(data);
  }
  setMessage() {
    return this.searchFormsResult.asObservable();
  }

  testsave(): Observable<any> {
    const result = this.http.get<Blob>('/assets/sample/sample.pdf',
      { headers: new HttpHeaders({ 'Content-type': 'application/json' }), responseType: 'blob' as 'json' });
    return result;
  }

  extractCorporateBrochureDetails() {
    this.Repositorydetails = this.config.getConfig('LASERFICHE_REPOSITORY');
    this.CorporateBrochurePath = this.config.getConfig('LASERFICHE_CORPORATE_BROCHURE_PATH');
    const params: string = '?Path=' + this.CorporateBrochurePath + '&Repository=' + this.Repositorydetails;
    return this.mwService.getLaserFicheByQueryString('ExtractfilenameByPath', params);
  }

  extractDistributorGuideDetails() {
    this.Repositorydetails = this.config.getConfig('LASERFICHE_REPOSITORY');
    this.DistributorGuidePath = this.config.getConfig('LASERFICHE_DISTRIBUTOR_GIDE_PATH');
    const params: string = '?Path=' + this.DistributorGuidePath + '&Repository=' + this.Repositorydetails;
    return this.mwService.getLaserFicheByQueryString('ExtractfilenameByPath', params);
  }
  downloadDistributorGuide(fileName: string) {
    const params: string = fileName;
    return this.mwService.getDistributor_Corporate_Annual_DownloadAPI('DownloadMktMaterial', params);
  }
  downloadCorpBrochure(fileName: string) {
    const params: string = fileName;
    return this.mwService.getDistributor_Corporate_Annual_DownloadAPI('DownloadCorpBrochure', params);
  }
  extractFormbyPackage(formsName: string): Observable<any> {
    return this.mwService.getFormDownloadAPI('DownloadForm', formsName);
  }

  extractFormbyDoc(docName: string, country: string): Observable<any> {
    const params: string = docName + '/' + country;
    return this.mwService.getFormDownloadAPI('DownloadForm', params);
  }

  searchLaserfiche(documentName: string, country: string, packagefile: string, productName: string): Observable<any> {
    if ((documentName === null) || (documentName.length === 0)) {
      documentName = '%';
    } else {
      documentName = '%' + documentName + '%';
    }

    let params: string = '?DocumentName=' + documentName;

    if ((country != null) && (country.length > 0)) {
      params = params + '&Country=' + country;
    }

    if ((packagefile != null) && (packagefile.length > 0)) {
      params = params + '&PackageFile=' + packagefile;
    }
    console.log(productName);
    if ((productName != null) && (productName.length > 0)) {
      params = params + '&ProductName=' + productName;
    }

    return this.mwService.getLaserFicheByQueryString('Search', params);
  }

  dashBoardLaserfiche(documentName: string, country: string, packageFile: string, productName: string): Observable<any> {
    return this.searchLaserfiche(documentName, country, packageFile, productName);
  }

}
