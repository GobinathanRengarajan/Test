import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AppConfig } from '@app/app.config';

@Injectable({
  providedIn: 'root'
})
export class MwadaptorService {
  ROOT_API: string;
  ROOT_API_CMS: string;
  constructor(private http: HttpClient, private config: AppConfig) { }

  get(apiName: string, ...parameters: any[]): Observable<any> {
    this.ROOT_API = this.config.getConfig('API_URL');
    const url = `${this.ROOT_API}/${apiName}/` + parameters.join('/');
    const result = this.http.get(url);
    return result;
  }


  getcms(apiName1: string, ...parameters1: any[]): Observable<any> {
    this.ROOT_API_CMS = this.config.getConfig('API_URL_CMS');
    const cmsurl = `${this.ROOT_API_CMS}/${apiName1}/` + parameters1.join('/');
    const resultapi = this.http.get(cmsurl);
    console.log(resultapi);
    return resultapi;

  }
  getpam(apiName1: string, ...parameters1: any[]): Observable<any> {
    this.ROOT_API_CMS = this.config.getConfig('API_URL_PAM');
    const cmsurl = `${this.ROOT_API_CMS}/${apiName1}/` + parameters1.join('/');
    const resultapi = this.http.get(cmsurl);
    return resultapi;
  }

  getByQueryString(apiName: string, parameters: string): Observable<any> {
    this.ROOT_API = this.config.getConfig('API_URL');
    const url = `${this.ROOT_API}/${apiName}/` + encodeURI(parameters);
    const result = this.http.get(url);
    console.log(result);
    return result;
  }

  getLaserFicheByQueryString(apiName: string, parameters: string): Observable<any> {
    this.ROOT_API = this.config.getConfig('API_URL_LASERFICHE');
    const url = `${this.ROOT_API}/${apiName}` + encodeURI(parameters);
    console.log(url);
    const result = this.http.get(url);
    console.log(result);
    return result;
  }

  getMyTranswareSSO(parameters: String): Observable<any> {
    this.ROOT_API = this.config.getConfig('myTranswareSSO');
    const url = this.ROOT_API + parameters;
    console.log(url);
    const result = this.http.get(url);
    console.log(result);
    return result;
  }

  getFormsAPI(apiName: string, ...parameters: any[]): Observable<any> {
    this.ROOT_API = this.config.getConfig('API_URL_FORMS');
    const url = `${this.ROOT_API}/${apiName}/` + parameters.join('/');
    const result = this.http.get(url);
    return result;
  }

  getFormDownloadAPI(apiName: string, parameter: string): Observable<any> {
    this.ROOT_API = this.config.getConfig('API_URL_FORMS');
    const url = `${this.ROOT_API}/${apiName}/` + encodeURI(parameter);
    const result = this.http.get<Blob>(url,
      { headers: new HttpHeaders({ 'Content-type': 'application/json' }), responseType: 'blob' as 'json' });
    return result;
  }

  /* downloading default packages and search forms API */
  getDownloadFormsPackagesAPI(apiName: string, parameter: string): Observable<any> {
    this.ROOT_API = this.config.getConfig('API_URL_FORMS');
    const url = `${this.ROOT_API}/${apiName}` + parameter;
    const result = this.http.get<Blob>(url, {
      headers: new HttpHeaders({ 'Content-type': 'application/json' }), responseType: 'blob' as 'json'
    });
    return result;
  }
  getDistributor_Corporate_Annual_DownloadAPI(apiName: string, parameter: string): Observable<any> {
    this.ROOT_API = this.config.getConfig('API_URL_FORMS');
    const url = `${this.ROOT_API}/${apiName}/` + encodeURI(parameter);
    const result = this.http.get<Blob>(url, {
      headers: new HttpHeaders({ 'Content-type': 'application/json' }), responseType: 'blob' as 'json'
    });
    return result;
  }
  postFormsAPI(apiName: string) {
    this.ROOT_API = this.config.getConfig('API_URL_FORMS');
    return `${this.ROOT_API}/${apiName}`;
  }
  putFormsAPI(apiName: string, id: number) {
    this.ROOT_API = this.config.getConfig('API_URL_FORMS');
    return `${this.ROOT_API}/${apiName}/${id}`;
  }

  deleteFormsAPI(apiName: string) {
    this.ROOT_API = this.config.getConfig('API_URL_FORMS');
    return `${this.ROOT_API}/${apiName}`;
  }

  sendEmailForms(parameter: string): Observable<any> {
    this.ROOT_API = this.config.getConfig('API_URL_FORMS');
    const url = `${this.ROOT_API}/` + parameter;
    const result = this.http.get(url);
    console.log(result);
    return result;
  }
  getPamUserLocation(apiName: string, ...parameters: any[]): Observable<any> {
    this.ROOT_API = this.config.getConfig('API_URL_PAM');
    const url = `${this.ROOT_API}/${apiName}` + parameters;
    const result = this.http.get(url);
    return result;

  }

}
