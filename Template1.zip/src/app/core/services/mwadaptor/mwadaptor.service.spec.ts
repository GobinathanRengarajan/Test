import { Policy } from './../../../shared/models/policy';
import { TestBed, inject } from '@angular/core/testing';
import { MwadaptorService } from './mwadaptor.service';
import { HttpClientModule } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

describe('MwadaptorService', () => {
  let service: MwadaptorService;
  let httpMock: HttpTestingController;
  const apiName: string = localStorage.getItem('userId');
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [MwadaptorService],
      imports: [
        HttpClientModule,
        HttpClientTestingModule
      ]
    });

    service = TestBed.get(MwadaptorService);
    httpMock = TestBed.get(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  // const dummyPosts: Policy[] = [
  //   {
  //     Policy_Number: '1',
  //     Policy_Code: '1',
  //     Product_Code: '1',
  //     Issue_Date: '22022019',
  //     Payment_Date: '22022019',
  //     Insured_Birthday: '22022019',
  //     Owner_Birthday: '22022019',
  //     Sur_Name: 'Jayabal',
  //     Given_Name: 'Malaichamy',
  //   },
  //   {
  //     Policy_Number: '2',
  //     Policy_Code: '2',
  //     Product_Code: '2',
  //     Issue_Date: '23022019',
  //     Payment_Date: '23022019',
  //     Insured_Birthday: '23022019',
  //     Owner_Birthday: '23022019',
  //     Sur_Name: 'Prathyush',
  //     Given_Name: 'Jayan',
  //   }
  // ];

  // // premium due
  // it('should data posts from the API via ROOT API', () => {
  //   service.get(apiName).subscribe( posts => {
  //     expect(posts.length).toBe(2);
  //     expect(posts).toEqual(dummyPosts);
  //   });

  //   const request = httpMock.expectOne(`${service.ROOT_API}/${apiName}/`);
  //   expect(request.request.method).toBe('GET');
  //   request.flush(dummyPosts);

  // });



});
