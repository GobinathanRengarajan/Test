import { Injectable } from '@angular/core';
import { NewsDetail } from '@app/shared/models/newsdetail';
import { MoreNewsDetails } from '@app/shared/models/morenewsdetails';
import { MwadaptorService } from '../mwadaptor/mwadaptor.service';
import { Observable, Subject, BehaviorSubject } from 'rxjs';
@Injectable({
  providedIn: 'root'
})

export class NewserviceService  {

  constructor(private mwService: MwadaptorService) { }


  getnewsdetail(newsID: string): Observable<NewsDetail> {
   return this.mwService.getcms('GetCMSNews', newsID);
  }

  getmorenewsdetails(newsID: string): Observable<MoreNewsDetails[]> {
   return this.mwService.getcms('GetOtherCMSNews', newsID);
  }
}
