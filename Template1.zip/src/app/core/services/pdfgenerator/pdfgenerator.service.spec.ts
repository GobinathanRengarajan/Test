import { TestBed, inject } from '@angular/core/testing';

import { PdfgeneratorService } from './pdfgenerator.service';

describe('PdfgeneratorService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PdfgeneratorService]
    });
  });

  it('should be created', inject([PdfgeneratorService], (service: PdfgeneratorService) => {
    expect(service).toBeTruthy();
  }));
});
