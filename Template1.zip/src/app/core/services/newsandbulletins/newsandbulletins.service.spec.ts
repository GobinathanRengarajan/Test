import { TestBed } from '@angular/core/testing';

import { NewsandbulletinsService } from './newsandbulletins.service';

describe('NewsandbulletinsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: NewsandbulletinsService = TestBed.get(NewsandbulletinsService);
    expect(service).toBeTruthy();
  });
});
