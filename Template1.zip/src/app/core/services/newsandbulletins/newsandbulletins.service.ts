import { Injectable } from '@angular/core';
import { MwadaptorService } from '../mwadaptor/mwadaptor.service';
import { Observable, Subject, BehaviorSubject } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class NewsandbulletinsService {

  constructor(private mwService: MwadaptorService, private https: HttpClient) { }


  /* function for getting news and bulletins list */
  getNewsAndBulletins(): Observable<any[]> {
    return this.mwService.getcms('/GetAllCMSNews');
  }

}
