import { Injectable } from '@angular/core';
import { MwadaptorService } from '../mwadaptor/mwadaptor.service';
import { Observable, Subject, BehaviorSubject } from 'rxjs';
import { filter, map } from 'rxjs/operators';
import { CompleteListPolicy } from '@app/shared/models/policy';
import { TypedJSON } from 'typedjson';
import { InforceLandPolicy } from '@app/shared/models/inforce-landing';
import * as moment from 'moment';
import { AppConfig } from '@app/app.config';

@Injectable({
  providedIn: 'root'
})
export class InforceService {

  // premiumdue default date range
  startDate = moment().add(1, 'months').startOf('month');
  endDate = moment().add(1, 'months').endOf('month');
  premiumDueDefaultDateRange = {
    startDate: this.startDate.format('YYYYMMDD'),
    endDate: this.endDate.format('YYYYMMDD')
  };
  inforcePremiumDueDateRange = new BehaviorSubject(this.premiumDueDefaultDateRange);

  // coming birthday default month
  date = moment().add(1, 'month');
  month = this.date.format('MM');
  inforceComingBirthdayMonth = new BehaviorSubject(this.month);
  Repositorydetails: string;

  constructor(private mwService: MwadaptorService, private config: AppConfig) { }

  // Behavior subject
  getMessage(message: any) {
    this.inforcePremiumDueDateRange.next(message);
  }
  setMessage() {
    return this.inforcePremiumDueDateRange.asObservable();
  }
  getBirthdayMonth(month: any) {
    this.inforceComingBirthdayMonth.next(month);
  }
  setBirthdayMonth() {
    return this.inforceComingBirthdayMonth.asObservable();
  }


  // premium due api call /getPoliciesByIssueDate/<userId>/<fromIssueDate>/<toIssueDate>
  getPolicyPremiumDue(userId: string, dateFrom: string, dateTo: string): Observable<CompleteListPolicy[]> {
    return this.mwService.get('policy/inforce/premiumdue', userId, dateFrom, dateTo);
  }


  getPolicyInforceAll(userId: string): Observable<InforceLandPolicy[]> {
    return this.mwService.get('policy/inforce', userId, 'all');
  }
  getPolicyNbAll(userId: string): Observable<any> {
    return this.mwService.get('policy/nb', userId, 'all');
  }



  // grace period api call /getPoliciesByIssueDate/<userId>/<fromIssueDate>/<toIssueDate>
  getPremiumDue(userId: string, dateFrom: string, dateTo: string): Observable<CompleteListPolicy[]> {
    return this.mwService.get('policy/inforce/premiumdue', userId, dateFrom, dateTo);
  }

  // upcoming birthday api call /getPoliciesByBirthday/<userId>/<month>
  getUpcomingBirthdayData(userId: string, month: string): Observable<CompleteListPolicy[]> {
    return this.mwService.get('policy/inforce/birthday', userId, month);
  }
  // Get Inforce policy search /policy/inforce/<userId>/<policyno>
  getInforcePolicysearch(userId: string, policyno: string): Observable<InforceLandPolicy[]> {
    // console.log('getPolicyByPolicyNumber', policyno);
    return this.mwService.get('policy/inforce', userId, policyno);
  }
  // inforcepolicy /policy/inforce/<userId>/<surName>/<givenName>
  getInforcePolicybyclientname(userId: string, surName: string, givenName: string): Observable<CompleteListPolicy[]> {
    const params = userId + '/clientname?surname=' + surName + '&givenName=' + givenName;
    return this.mwService.getByQueryString('policy/inforce', params);
  }
  getpolicyByClientname(userId: string): Observable<any> {
    return this.mwService.get('policy/nb/', userId, 'clientname');
  }

  getpolicyByMonth(userId: string, month: string): Observable<InforceLandPolicy[]> {
    return this.mwService.get('policy/inforce/birthday', userId, month);
  }

  getpolicyByPremiumduemonth(userId: string, fromDueDate: string, touedate: string): Observable<CompleteListPolicy[]> {
    return this.mwService.get('policy/inforce/premiumdue', userId, fromDueDate, touedate);
  }

  getinforcepolicydetails(userId: string, policyno: string): Observable<any> {
    return this.mwService.get('policy/inforce/policydetail/info', userId, policyno);
  }

  // financial details
  getfinance(UserID: string, policyNo: string): Observable<any> {
    return this.mwService.get('policy/inforce/policydetail/finance', UserID, policyNo);
  }
  // relationship details
  getrelationship(UserID: string, policyNo: string): Observable<any> {
    return this.mwService.get('policy/inforce/policydetail/relationship', UserID, policyNo);
  }

  // premiumbilling
  getpremiumbilling(userId: string, policyNo: string): Observable<any> {
    return this.mwService.get('policy/inforce/policydetail/premiumbilling', userId, policyNo);
  }

  // premiumbilling
  getInfo(userId: string, policyNo: string) {
    return this.mwService.get('policy/inforce/policydetail/info', userId, policyNo);
  }
  // extract Annual file details
  extractAnnualfileDetails(policyNo: string) {
    this.Repositorydetails = this.config.getConfig('LASERFICHE_REPOSITORY');
    const params: string = '?PolicyNum=' + policyNo + '&Repository=' + this.Repositorydetails;
    return this.mwService.getLaserFicheByQueryString('ExtractAnnualfileDetailsbyPolicynum', params);
  }
  // download annual statement
  downloadAnnualstatement(fileName: string, policyNo: string) {
    const params: string = fileName + '/' + policyNo;
    return this.mwService.getDistributor_Corporate_Annual_DownloadAPI('DownloadAnnualStmt', params);
  }

}
