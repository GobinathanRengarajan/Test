import { Policy } from '@app/shared/models/policy';
import { TestBed, inject } from '@angular/core/testing';
import { InforceService } from './inforce.service';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AuthService } from '@app/core/authentication/auth.service';
import { AppConstants } from '@app/app.constants';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import { MwadaptorService } from '../mwadaptor/mwadaptor.service';

describe('IfadaptorService', () => {
  let service: InforceService;
  let httpMock: HttpTestingController;
  let rootAPI: MwadaptorService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [InforceService, AppConstants, AuthService, MwadaptorService],
      imports: [BrowserDynamicTestingModule,
      RouterTestingModule,
      HttpClientTestingModule

    ],
    schemas: [ CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA]
    });
    service = TestBed.get(InforceService);
    httpMock = TestBed.get(HttpTestingController);
    rootAPI = TestBed.get(MwadaptorService);
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
  // const dummyPosts: Policy[] = [
  //   {
  //     Policy_Number: '1',
  //     Policy_Code: '1',
  //     Product_Code: '1',
  //     Issue_Date: '22022019',
  //     Payment_Date: '22022019',
  //     Insured_Birthday: '22022019',
  //     Owner_Birthday: '22022019',
  //     Sur_Name: 'Jayabal',
  //     Given_Name: 'Malaichamy',
  //   },
  //   {
  //     Policy_Number: '2',
  //     Policy_Code: '2',
  //     Product_Code: '2',
  //     Issue_Date: '23022019',
  //     Payment_Date: '23022019',
  //     Insured_Birthday: '23022019',
  //     Owner_Birthday: '23022019',
  //     Sur_Name: 'Prathyush',
  //     Given_Name: 'Jayan',
  //   }
  // ];

  // function
  // const userId = localStorage.getItem('userId');
  // const dateFrom = '20190301';
  // const dateTo = '20190331';
  // const month = '03';
  // const policyno = '1234567';

  // premium due
  // it('should data posts from the API via GET for inforce premium due date', () => {
  //   service.getPolicyPremiumDue(userId, dateFrom, dateTo).subscribe( posts => {
  //     expect(posts.length).toBe(2);
  //     expect(posts).toEqual(dummyPosts);
  //   });

  //   const request = httpMock.expectOne(`${rootAPI.ROOT_API}/policy/inforce/premiumdue//`);
  //   expect(request.request.method).toBe('GET');
  //   request.flush(dummyPosts);

  // });

  // current policy
  // it('should data posts from the API via GET for inforce current policy', () => {
  //   service.getCurrentPolicy(userId, dateFrom, dateTo).subscribe( posts => {
  //     expect(posts.length).toBe(2);
  //     expect(posts).toEqual(dummyPosts);
  //   });

  //   const requestOne = httpMock.expectOne(`${rootAPI.ROOT_API}/policy/inforce/premiumdue//`);
  //   expect(requestOne.request.method).toBe('GET');
  //   requestOne.flush(dummyPosts);
  // });

  // coming birthday
  // it('should data posts from the API via GET for inforce coming birthday', () => {
  //   service.getUpcomingBirthdayData(userId, month).subscribe( posts => {
  //     expect(posts.length).toBe(2);
  //     expect(posts).toEqual(dummyPosts);
  //   });

  //   const requestTwo = httpMock.expectOne(`${rootAPI.ROOT_API}/policy/inforce/birthday/`, month);
  //   expect(requestTwo.request.method).toBe('GET');
  //   requestTwo.flush(dummyPosts);

  // });

  // get policy search
  // it('should data posts from the API via GET for get policy search', () => {
  //   service.getpolicysearch(policyno).subscribe( posts => {
  //     expect(posts.length).toBe(2);
  //     expect(posts).toEqual(dummyPosts);
  //   });

  //   const requestThree = httpMock.expectOne(`${rootAPI.ROOT_API}/api/getPolicyByPolicyNumber/`, policyno);
  //   expect(requestThree.request.method).toBe('GET');
  //   requestThree.flush(dummyPosts);
  // });

  // get policy by client name
  // it('should data posts from the API via GET for get policy by client name', () => {
  //   service.getpolicyByClientname(policyno).subscribe( posts => {
  //     expect(posts.length).toBe(2);
  //     expect(posts).toEqual(dummyPosts);
  //   });

  //   const requestFour = httpMock.expectOne(`${rootAPI.ROOT_API}/api/getPolicyByPolicyNumber/`, policyno);
  //   expect(requestFour.request.method).toBe('GET');
  //   requestFour.flush(dummyPosts);
  // });

  // get policy by month
  // it('should data posts from the API via GET for get policy by month', () => {
  //   service.getpolicyByMonth(policyno).subscribe( posts => {
  //     expect(posts.length).toBe(2);
  //     expect(posts).toEqual(dummyPosts);
  //   });

  //   const request = httpMock.expectOne(`${rootAPI.ROOT_API}/api/getPolicyByPolicyNumber/`, policyno);
  //   expect(request.request.method).toBe('GET');
  //   request.flush(dummyPosts);
  // });

  // // get policy by premium due month
  // it('should data posts from the API via GET for get policy by premium due month', () => {
  //   service.getpolicyByPremiumduemonth(policyno).subscribe( posts => {
  //     expect(posts.length).toBe(2);
  //     expect(posts).toEqual(dummyPosts);
  //   });

  //   const request = httpMock.expectOne(`${rootAPI.ROOT_API}/api/getPolicyByPolicyNumber/`, policyno);
  //   expect(request.request.method).toBe('GET');
  //   request.flush(dummyPosts);
  // });



});
