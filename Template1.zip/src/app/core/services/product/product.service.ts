import { Injectable } from '@angular/core';
import { MwadaptorService } from '../mwadaptor/mwadaptor.service';
import { Subproduct } from '@app/shared/models/subproduct';
import { Product } from '@app/shared/models/product';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor(private mwService: MwadaptorService) { }

  getproductdetails(SubProductID: string): Observable<Subproduct[]> {
    return this.mwService.getcms('GetCMSSubProduct', SubProductID);
  }
  getOtherCMSProducts(SubProductID: string): Observable<Subproduct[]> {
    return this.mwService.getcms('GetOtherCMSProducts', SubProductID);
  }

  getlocationdetails(location: string): Observable<Product[]> {
    return this.mwService.getcms('GetLocBasedCMSProducts', location);
  }

}
