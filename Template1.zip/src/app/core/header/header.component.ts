import {
  Component,
  OnInit,
  ViewEncapsulation,
  Renderer2,
  Inject,
  HostListener,
  OnDestroy
} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthService } from '../authentication/auth.service';
import { AppConstants } from '@app/app.constants';
import { DOCUMENT } from '@angular/common';
import { MwadaptorService } from '@app/core/services/mwadaptor/mwadaptor.service';
import { AppConfig } from '@app/app.config';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class HeaderComponent implements OnInit, OnDestroy {
  tlbLogo = this.app.tlbLogo;
  tlbLogoHeader = this.app.tlbLogoHeader;
  tlbLogoConnect = this.app.tlbLogoConnect;
  tlbmobileLogo = this.app.tlbmobileLogo;
  homeIcon = this.app.homeIcon;
  homeWhiteIcon = this.app.homeWhiteIcon;
  myTranswareIcon = this.app.myTranswareIcon;
  myTranswareWhiteIcon = this.app.myTranswareWhiteIcon;
  productsIcon = this.app.productsIcon;
  formsIcon = this.app.formsIcon;
  formsIconWhite = this.app.formsIconWhite;
  productsWhiteIcon = this.app.productsWhiteIcon;
  inforceIcon = this.app.inforceIcon;
  inforceWhiteIcon = this.app.inforceWhiteIcon;
  dropDownWhiteIcon = this.app.dropDownWhiteIcon;
  producerInfoIcon = this.app.producerInfoIcon;
  producerInfoWhite = this.app.producerInfoWhite;
  othersIcon = this.app.othersIcon;
  othersWhiteIcon = this.app.othersWhiteIcon;
  dropDownIcon = this.app.dropDownIcon;
  contactus = this.app.contactus;
  newsbulletin = this.app.newsbulletin;
  logoutIcon = this.app.logoutIcon;
  searchIcon = this.app.searchIcon;
  searchIconMobile = this.app.searchIconMobile;
  linedivider = this.app.linedivider;
  moreIcon = this.app.moreIcon;
  logoutMobile = this.app.logoutMobile;
  newsBulletin = this.app.newsBulletin;
  contactIcon = this.app.contactIcon;
  myTranswareLink = this.appConfig.getConfig('myTranswareLink') + this.encryptString();


  currentUser: any = [];
  isAdmin = false;
  myprofile = this.app.myprofile;
  privacypolicy = this.app.privacypolicy;
  changeArrowIcon = false;
  isOpenMenu = false;

  constructor(
    private router: Router,
    private authenticationService: AuthService,
    private app: AppConstants, @Inject(DOCUMENT)
    private document: Document,
    private renderer: Renderer2,
    private route: ActivatedRoute,
    private appConfig: AppConfig,
    private mwadaptorService: MwadaptorService
  ) { }


  ngOnInit() {
    this.authenticationService.currentUser.subscribe(x => {
      this.currentUser.push(x.firstName);
      if (this.currentUser[0] === 'Admin' ||
        this.currentUser[0] === 'Staff' ||
        this.currentUser[0] === 'Distributor' ||
        this.currentUser[0] === 'Producer' ||
        this.currentUser[0] === 'Case Manager') {
        this.isAdmin = true;
      }
    });

    this.renderer.addClass(this.document.body, 'header-body-section');
  }
  ngOnDestroy(): void {
    this.renderer.removeClass(this.document.body, 'header-body-section');
  }

  logout() {
    this.authenticationService.logout();
    this.router.navigate(['/login'],
      { queryParams: { logout: 'logoutmsg' } });
  }

  navigate() {
    this.router.navigate(['/search']);
  }

  // inforce
  getInforceAll() {
    this.router.navigate(['/inforce', 'View Complete List', 'all']);
  }
  // nb
  getNbAll() {
    this.router.navigate(['/new-business', 'View Complete List', 'all']);
  }

  changeArrowIcons() {
    this.changeArrowIcon = true;
  }
  changeArrow() {
    this.changeArrowIcon = false;
  }

  // hamburger menu click open/close function
  @HostListener('document:click', ['$event']) clickout() {
    if (this.isOpenMenu === true) {
      this.isOpenMenu = !this.isOpenMenu;
    }

  }
  encryptString(): String {

    const user = 'user=' + this.appConfig.getConfig('myTranswareUser');
    const email = '&email=' + this.appConfig.getConfig('myTranswareEmail');
    const firstName = '&firstName=' + this.appConfig.getConfig('myTranswareFirstName');
    const lastName = '&lastName=' + this.appConfig.getConfig('myTranswareLastName');
    const activeAgentID = '&activeAgentID=' + this.appConfig.getConfig('myTranswareActiveAgentID');
    const activeOfficeID = '&activeOfficeID=' + this.appConfig.getConfig('myTranswareActiveOfficeID');
    const agencyName = '&agencyName=' + this.appConfig.getConfig('myTranswareAgencyName');
    return user + email + firstName + lastName + activeAgentID + activeOfficeID + agencyName;
  }
  callMyTransware() {
    this.mwadaptorService.getMyTranswareSSO(this.encryptString()).subscribe(
      result => {
        console.log('url,', result['url']);
        window.open(result['url'], '_blank');
      },
      error => {
        console.log('error to call MyTransaware ', error);
      }
    );
  }
  menuOpen(event: Event) {
    event.stopPropagation();
    this.isOpenMenu = !this.isOpenMenu;
  }
  menuClose() {
    event.stopPropagation();
    this.isOpenMenu = !this.isOpenMenu;
  }
  otherMenu() {
    event.stopPropagation();
  }
  redirect() {
    this.router.navigate(['/newsbulletin']);
  }
}
