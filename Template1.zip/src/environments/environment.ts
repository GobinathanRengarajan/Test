
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build ---prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  version: '1.0',
  vapid_public_key: 'PUT_HERE_YOUR_PUBLIC_KEY',

  // for tlb
  // API_URL: 'http://10.251.2.229:8080',
  // MOCK_API_URL: 'http://10.251.2.229:8080'
  // for hcl
  API_URL: 'http://10.146.170.10/mock-server',
  MOCK_API_URL: 'http://10.146.170.10/mock-server',
  // cms_API_URL
  API_URL_CMS: 'http://10.146.170.10/CMSAPI',
  MOCK_API_URL_CMS: 'http://10.146.170.10/CMSAPI'
};
