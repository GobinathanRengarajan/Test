var params ={"UserId" : 'TA019823',
 "UserName" : 'TA019823',
"AgentCodes": '999999',
"UserType": 'G',
"Role": 'TRANSACT_HONGKONG'
};