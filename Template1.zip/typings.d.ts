declare var $: any;
declare var jQuery: any;
